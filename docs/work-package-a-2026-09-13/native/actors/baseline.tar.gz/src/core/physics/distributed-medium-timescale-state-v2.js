import { advanceArousalV1, assertMemoryTimescaleLawV1, effectiveRecoveryRateV1, encodingGainV1, memoryTimescaleLawConfigV1, } from '../learning/memory-timescales.js';
function requireTime(value, label) {
    if (!Number.isFinite(value) || value < 0)
        throw new RangeError(`${label} must be finite and nonnegative`);
}
function requireStructureId(value) {
    if (typeof value !== 'string' || value.length === 0)
        throw new RangeError('structureId must be non-empty');
}
/**
 * Medium-owned time state.  Surprise is accepted only as a measured flux at
 * an explicitly ordered observation time; there is no setter for salience,
 * recovery rate or arousal.
 */
export class DistributedMediumTimescaleStateV2 {
    #law;
    #arousal = { version: 'MediumArousalStateV1', arousal: 0, logicalTime: 0 };
    #rehearsalCounts = new Map();
    #measuredStructures = new Map();
    constructor(law = memoryTimescaleLawConfigV1()) {
        assertMemoryTimescaleLawV1(law);
        this.#law = Object.freeze({ ...law });
    }
    get arousal() { return this.#arousal.arousal; }
    get logicalTime() { return this.#arousal.logicalTime; }
    /** Advance experience time and decay the medium-owned arousal state. */
    advanceTo(logicalTime) {
        requireTime(logicalTime, 'logicalTime');
        if (logicalTime < this.logicalTime)
            throw new Error('timescale-logical-time-reversed');
        this.#arousal = advanceArousalV1(this.#arousal, 0, logicalTime - this.logicalTime, this.#law);
    }
    /** Deposit a measured surprise flux; unknown changes must pass zero. */
    depositSurpriseFlux(observedAt, surpriseFlux) {
        requireTime(observedAt, 'observedAt');
        if (observedAt < this.logicalTime)
            throw new Error('surprise-observation-time-reversed');
        this.#arousal = advanceArousalV1(this.#arousal, surpriseFlux, observedAt - this.logicalTime, this.#law);
    }
    rehearsalCount(structureId) {
        requireStructureId(structureId);
        return this.#rehearsalCounts.get(structureId) ?? 0;
    }
    recordRehearsal(structureId) {
        requireStructureId(structureId);
        const next = this.rehearsalCount(structureId) + 1;
        this.#rehearsalCounts.set(structureId, next);
        return next;
    }
    rememberMeasuredObservation(value) {
        requireStructureId(value.structureId);
        requireTime(value.observedAt, 'measured structure observedAt');
        requireTime(value.surpriseMagnitude, 'measured structure surpriseMagnitude');
        requireTime(value.goalRelevance, 'measured structure goalRelevance');
        requireTime(value.supportMass, 'measured structure supportMass');
        const previous = this.#measuredStructures.get(value.structureId);
        if (previous !== undefined && value.observedAt < previous.observedAt)
            throw new Error('measured structure observation time reversed');
        this.#measuredStructures.set(value.structureId, { ...value });
    }
    measuredObservation(structureId) {
        requireStructureId(structureId);
        const value = this.#measuredStructures.get(structureId);
        return value === undefined ? null : { ...value };
    }
    get hasMeasuredObservations() { return this.#measuredStructures.size > 0; }
    /** Derive rate from measurements and this state's own rehearsal count. */
    effectiveRecoveryRate(structureId, measurement) {
        const count = this.rehearsalCount(structureId);
        return effectiveRecoveryRateV1({ ...measurement, version: 'MeasuredSalienceV1', rehearsalCount: count }, this.#law);
    }
    encodingGain() { return encodingGainV1(this.arousal, this.#law); }
    snapshot() {
        return {
            version: 'DistributedMediumTimescaleSnapshotV2', protocol: 'memory-timescales-v2',
            arousal: this.#arousal.arousal, logicalTime: this.#arousal.logicalTime,
            rehearsalCounts: [...this.#rehearsalCounts.entries()]
                .sort(([left], [right]) => left.localeCompare(right, 'en'))
                .map(([structureId, count]) => ({ structureId, count })),
            measuredStructures: [...this.#measuredStructures.values()]
                .sort((left, right) => left.structureId.localeCompare(right.structureId, 'en'))
                .map(value => ({ ...value })),
        };
    }
    static restore(snapshot, law = memoryTimescaleLawConfigV1()) {
        if (snapshot.version !== 'DistributedMediumTimescaleSnapshotV2'
            || snapshot.protocol !== 'memory-timescales-v2')
            throw new Error('unsupported-timescale-v2-snapshot');
        requireTime(snapshot.arousal, 'snapshot arousal');
        if (snapshot.arousal > 1)
            throw new RangeError('snapshot arousal must be bounded');
        requireTime(snapshot.logicalTime, 'snapshot logicalTime');
        const state = new DistributedMediumTimescaleStateV2(law);
        state.#arousal = { version: 'MediumArousalStateV1', arousal: snapshot.arousal,
            logicalTime: snapshot.logicalTime };
        let previous = '';
        for (const item of snapshot.rehearsalCounts) {
            requireStructureId(item.structureId);
            if (item.structureId <= previous)
                throw new Error('timescale rehearsal ids must be sorted and unique');
            if (!Number.isSafeInteger(item.count) || item.count < 0)
                throw new RangeError('rehearsal count must be nonnegative integer');
            previous = item.structureId;
            state.#rehearsalCounts.set(item.structureId, item.count);
        }
        let previousMeasured = '';
        for (const item of snapshot.measuredStructures ?? []) {
            requireStructureId(item.structureId);
            if (item.structureId <= previousMeasured)
                throw new Error('timescale measured structure ids must be sorted and unique');
            if (item.observedAt > snapshot.logicalTime)
                throw new Error('measured structure observation is ahead of timescale state');
            state.rememberMeasuredObservation(item);
            previousMeasured = item.structureId;
        }
        return state;
    }
}
//# sourceMappingURL=distributed-medium-timescale-state-v2.js.map