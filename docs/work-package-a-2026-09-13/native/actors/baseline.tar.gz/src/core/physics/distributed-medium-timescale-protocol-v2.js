import { sha } from '../../util.js';
import { assertMemoryTimescaleLawV1, memoryTimescaleLawConfigV1, } from '../learning/memory-timescales.js';
import { DistributedMediumTimescaleStateV2, } from './distributed-medium-timescale-state-v2.js';
function requireFiniteNonnegative(value, label) {
    if (!Number.isFinite(value) || value < 0)
        throw new RangeError(`${label} must be finite and nonnegative`);
}
function requireStructureId(value) {
    if (typeof value !== 'string' || value.length === 0)
        throw new RangeError('structureId must be non-empty');
}
function validateMeasurement(value) {
    if (value.version !== 'RuntimeMeasuredSalienceV2'
        || value.source !== 'trusted-runtime-observation')
        throw new Error('invalid runtime salience measurement');
    requireStructureId(value.structureId);
    requireFiniteNonnegative(value.observedAt, 'observedAt');
    requireFiniteNonnegative(value.surpriseMagnitude, 'surpriseMagnitude');
    requireFiniteNonnegative(value.goalRelevance, 'goalRelevance');
    requireFiniteNonnegative(value.supportMass, 'supportMass');
}
/** Validate an ordered batch without deriving a caller-provided salience. */
export function validateTimescaleMeasurementBatchV2(batch) {
    if (batch.version !== 'TimescaleMeasurementBatchV2')
        throw new Error('unsupported timescale measurement batch');
    let previousTime = -Infinity;
    for (const measurement of batch.observations) {
        validateMeasurement(measurement);
        if (measurement.observedAt < previousTime)
            throw new Error('timescale measurements are out of order');
        previousTime = measurement.observedAt;
    }
}
/** Convert only measured components into the frozen recovery law. */
export function measuredRecoveryRateV2(state, measurement, law = memoryTimescaleLawConfigV1()) {
    validateMeasurement(measurement);
    assertMemoryTimescaleLawV1(law);
    return state.effectiveRecoveryRate(measurement.structureId, {
        version: 'MeasuredSalienceV1',
        surpriseMagnitude: measurement.surpriseMagnitude,
        goalRelevance: measurement.goalRelevance,
        supportMass: measurement.supportMass,
    });
}
/**
 * Compose a strict V2 envelope.  No physical state is mutated and the V1
 * medium snapshot is cloned so a caller cannot alter the envelope afterwards.
 */
export function composeDistributedMediumProtocolSnapshotV2(medium, timescale, law = memoryTimescaleLawConfigV1()) {
    if (medium.version !== 'DistributedMediumSnapshotV1')
        throw new Error('unsupported medium snapshot for timescale-v2');
    if (timescale.version !== 'DistributedMediumTimescaleSnapshotV2')
        throw new Error('unsupported timescale snapshot');
    assertMemoryTimescaleLawV1(law);
    const clonedMedium = structuredClone(medium);
    const clonedTimescale = structuredClone(timescale);
    const restored = DistributedMediumTimescaleStateV2.restore(clonedTimescale, law);
    if (restored.logicalTime !== clonedMedium.logicalTime)
        throw new Error('timescale and medium logical time must match');
    return {
        version: 'DistributedMediumProtocolSnapshotV2',
        protocol: 'distributed-medium-timescales-v2',
        lawIdentitySha256: sha(law),
        medium: clonedMedium,
        timescale: clonedTimescale,
    };
}
/** Strictly restore the two independently-owned states without writing either. */
export function restoreDistributedMediumProtocolSnapshotV2(snapshot, law = memoryTimescaleLawConfigV1()) {
    if (snapshot.version !== 'DistributedMediumProtocolSnapshotV2'
        || snapshot.protocol !== 'distributed-medium-timescales-v2')
        throw new Error('unsupported medium protocol snapshot');
    assertMemoryTimescaleLawV1(law);
    if (snapshot.lawIdentitySha256 !== sha(law))
        throw new Error('timescale law identity mismatch');
    const medium = structuredClone(snapshot.medium);
    const timescale = structuredClone(snapshot.timescale);
    if (medium.version !== 'DistributedMediumSnapshotV1')
        throw new Error('embedded medium snapshot is not V1');
    const restored = DistributedMediumTimescaleStateV2.restore(timescale, law);
    if (restored.logicalTime !== medium.logicalTime)
        throw new Error('timescale and medium logical time must match');
    return { medium, timescale };
}
/** Read-only check that a measured structure is present in the captured medium. */
export function measuredStructureExistsV2(medium, measurement) {
    validateMeasurement(measurement);
    if (measurement.structureId.startsWith('site:')) {
        const siteId = Number(measurement.structureId.slice('site:'.length));
        return Number.isSafeInteger(siteId) && medium.sites.some((site) => site.siteId === siteId);
    }
    if (measurement.structureId.startsWith('assembly:')) {
        const assemblyId = measurement.structureId.slice('assembly:'.length);
        return medium.coactivationAssemblies?.some(assembly => assembly.assemblyId === assemblyId) ?? false;
    }
    return medium.footprints.some(footprint => `trace:${footprint.traceId}` === measurement.structureId)
        || medium.learnedBonds.some(bond => `bond:${bond.fromSiteId}>${bond.toSiteId}:${bond.kind}` === measurement.structureId);
}
//# sourceMappingURL=distributed-medium-timescale-protocol-v2.js.map