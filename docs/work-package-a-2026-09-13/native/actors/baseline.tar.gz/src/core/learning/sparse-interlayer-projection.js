import { assert } from '../../util.js';
import { SplitMix64 } from '../random.js';
const PROJECTION_SALT = 0xd1b54a32d192ed03n;
const SOURCE_ID_SALT = 0x94d049bb133111ebn;
function parseSeed(value) {
    assert(/^0x[0-9a-f]+$/i.test(value), 'sparse-interlayer-invalid-seed');
    return BigInt(value);
}
function assertPositiveInteger(value, label) {
    if (!Number.isInteger(value) || value < 1)
        throw new RangeError(`${label} must be a positive integer`);
}
/**
 * Fixed sparse fibres from source lattice sites into an independent target
 * lattice.  A source coordinate never computes a target coordinate: the
 * target medium draws a local unbound candidate population, runs its own local
 * competition, and permanently binds the winners to that source identity.
 */
export class SparseInterlayerProjectionV1 {
    #medium;
    #projectionId;
    #seed;
    #candidateCount;
    #winnerCount;
    #allocationSequence = 0;
    #bindings = new Map();
    constructor(medium, config, state) {
        if (config.projectionId.length === 0)
            throw new RangeError('projectionId must be non-empty');
        const candidateCount = config.candidateCount ?? 32, winnerCount = config.winnerCount ?? 8;
        assertPositiveInteger(candidateCount, 'candidateCount');
        assertPositiveInteger(winnerCount, 'winnerCount');
        if (winnerCount > candidateCount)
            throw new RangeError('winnerCount must not exceed candidateCount');
        this.#medium = medium;
        this.#projectionId = config.projectionId;
        this.#seed = config.seed;
        this.#candidateCount = candidateCount;
        this.#winnerCount = winnerCount;
        if (!state)
            return;
        assert(state.version === 'SparseInterlayerProjectionStateV1'
            && state.projectionId === this.#projectionId && parseSeed(state.seedHex) === this.#seed
            && state.candidateCount === candidateCount && state.winnerCount === winnerCount, 'sparse-interlayer-state-identity-mismatch');
        this.#allocationSequence = state.allocationSequence;
        for (const value of state.bindings) {
            assert(Number.isInteger(value.sourceSiteId) && value.sourceSiteId >= 0, 'sparse-interlayer-invalid-source-site');
            assert(value.targetSiteIds.length === winnerCount
                && new Set(value.targetSiteIds).size === value.targetSiteIds.length, 'sparse-interlayer-invalid-target-fibre');
            assert(!this.#bindings.has(value.sourceSiteId), 'sparse-interlayer-duplicate-source-site');
            const binding = { ...value, targetSiteIds: [...value.targetSiteIds] };
            this.#medium.bindSites(this.#mediumBindingId(value.sourceSiteId), binding.targetSiteIds);
            this.#bindings.set(value.sourceSiteId, binding);
        }
    }
    #mediumBindingId(sourceSiteId) {
        return `interlayer:${this.#projectionId}:source-site:${sourceSiteId}`;
    }
    #ensureBinding(sourceSiteId, sourceNeighborSiteIds) {
        if (!Number.isInteger(sourceSiteId) || sourceSiteId < 0)
            throw new RangeError('source site id must be a nonnegative integer');
        const existing = this.#bindings.get(sourceSiteId);
        if (existing) {
            const updated = { ...existing, observationCount: existing.observationCount + 1 };
            this.#bindings.set(sourceSiteId, updated);
            return updated;
        }
        const random = new SplitMix64(this.#seed
            ^ (BigInt(this.#allocationSequence + 1) * PROJECTION_SALT)
            ^ (BigInt(sourceSiteId + 1) * SOURCE_ID_SALT));
        const draw = () => random.uniform();
        const targetAnchors = [...new Set(sourceNeighborSiteIds
                .flatMap(neighbor => this.#bindings.get(neighbor)?.targetSiteIds ?? []))].sort((left, right) => left - right);
        const candidates = targetAnchors.length > 0
            ? this.#medium.allocateSitesNear(targetAnchors, this.#candidateCount, draw)
            : this.#medium.allocateSites(this.#candidateCount, draw);
        // Already bound fibres of measured source neighbours are coactive input
        // to the same target competition. Treating them only as occupied sites
        // made the generic anti-crowding term repel every adjacent source pair.
        const targetSiteIds = this.#medium.competeForSites(candidates, this.#winnerCount, draw, targetAnchors);
        this.#medium.bindSites(this.#mediumBindingId(sourceSiteId), targetSiteIds);
        const value = {
            sourceSiteId, targetSiteIds: [...targetSiteIds], observationCount: 1,
        };
        this.#bindings.set(sourceSiteId, value);
        this.#allocationSequence += 1;
        return value;
    }
    #mappedDrives(sourceDrives, allocate, sourceNeighborhoods = []) {
        const unique = new Map();
        for (const drive of sourceDrives) {
            if (!Number.isInteger(drive.siteId) || drive.siteId < 0 || !Number.isFinite(drive.intensity)
                || drive.intensity <= 0 || drive.intensity > 1)
                throw new Error('invalid sparse interlayer source drive');
            unique.set(drive.siteId, Math.max(unique.get(drive.siteId) ?? 0, drive.intensity));
        }
        const neighborhoodBySite = new Map();
        for (const neighborhood of sourceNeighborhoods) {
            if (!Number.isInteger(neighborhood.sourceSiteId) || neighborhood.sourceSiteId < 0
                || neighborhood.neighborSiteIds.some(value => !Number.isInteger(value) || value < 0))
                throw new Error('invalid sparse interlayer source neighborhood');
            if (new Set(neighborhood.neighborSiteIds).size !== neighborhood.neighborSiteIds.length)
                throw new Error('sparse interlayer source neighbors must be unique');
            neighborhoodBySite.set(neighborhood.sourceSiteId, [...neighborhood.neighborSiteIds]);
        }
        // Simultaneous source drives are one measured pulse and are represented by
        // the pulse's local/coactive bonds after projection.  They are not spatial
        // neighbours merely because they arrived in the same pulse.  Only an
        // explicitly observed source-lattice neighbourhood may anchor a new target
        // fibre near an already bound source.  This keeps the layer boundary
        // topology honest and prevents unrelated coactivation from merging target
        // basins.
        const result = [];
        const pending = [...unique].sort(([left], [right]) => left - right);
        while (pending.length > 0) {
            // Numeric source order is not a traversal of its lattice. Allocate an
            // already reachable neighbour before opening another unanchored root;
            // otherwise one connected observed population can be scattered into
            // unrelated target basins. This uses measured edges only, never a
            // semantic label or a source coordinate. Existing fibres never move.
            const frontierIndex = allocate ? pending.findIndex(([siteId]) => this.#bindings.has(siteId) || (neighborhoodBySite.get(siteId) ?? [])
                .some(neighbor => this.#bindings.has(neighbor))) : -1;
            const [sourceSiteId, intensity] = pending.splice(Math.max(0, frontierIndex), 1)[0];
            const binding = allocate
                ? this.#ensureBinding(sourceSiteId, neighborhoodBySite.get(sourceSiteId) ?? [])
                : this.#bindings.get(sourceSiteId);
            if (!binding)
                continue;
            const fibreIntensity = intensity / Math.sqrt(binding.targetSiteIds.length);
            for (const siteId of binding.targetSiteIds)
                result.push({ siteId, intensity: fibreIntensity });
        }
        return result.sort((left, right) => left.siteId - right.siteId);
    }
    projectPulse(pulse) {
        if (pulse.pulseId.length === 0 || !Number.isFinite(pulse.offset) || pulse.offset < 0)
            throw new Error('invalid sparse interlayer pulse');
        if (pulse.dwellSeconds !== undefined && (!Number.isFinite(pulse.dwellSeconds) || pulse.dwellSeconds <= 0))
            throw new Error('invalid sparse interlayer pulse dwell');
        return { version: 'SparseFieldPulseV1', pulseId: pulse.pulseId, offset: pulse.offset,
            ...(pulse.dwellSeconds === undefined ? {} : { dwellSeconds: pulse.dwellSeconds }),
            drives: this.#mappedDrives(pulse.drives, true, pulse.sourceNeighborhoods) };
    }
    projectEpisode(pulses) {
        return pulses.map(value => this.projectPulse(value));
    }
    /** Existing fibre lookup for a read-only open-prefix query; never allocates. */
    lookupPulse(sourceDrives) {
        return this.#mappedDrives(sourceDrives, false);
    }
    /** Adjoint of the already formed, disjoint 1/sqrt(n) fibres. This reads
     * actually activated target sites; it cannot invent an unvisited source. */
    readSourcePulse(targetDrives) {
        const activation = new Map(targetDrives.map(drive => [drive.siteId, drive.intensity]));
        const result = [];
        for (const binding of this.#bindings.values()) {
            const intensity = binding.targetSiteIds.reduce((sum, siteId) => sum + (activation.get(siteId) ?? 0), 0)
                / Math.sqrt(binding.targetSiteIds.length);
            if (intensity > 0)
                result.push({ siteId: binding.sourceSiteId, intensity });
        }
        return result.sort((a, b) => a.siteId - b.siteId);
    }
    snapshot() {
        return { version: 'SparseInterlayerProjectionStateV1', projectionId: this.#projectionId,
            seedHex: `0x${this.#seed.toString(16)}`, allocationSequence: this.#allocationSequence,
            candidateCount: this.#candidateCount, winnerCount: this.#winnerCount,
            bindings: [...this.#bindings.values()].sort((left, right) => left.sourceSiteId - right.sourceSiteId)
                .map(value => ({ ...value, targetSiteIds: [...value.targetSiteIds] })) };
    }
}
//# sourceMappingURL=sparse-interlayer-projection.js.map