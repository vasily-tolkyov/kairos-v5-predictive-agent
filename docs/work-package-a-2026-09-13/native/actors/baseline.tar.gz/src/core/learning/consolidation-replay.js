import { SplitMix64 } from '../random.js';
import { memoryTimescaleLawConfigV1 } from './memory-timescales.js';
/** Adapter that exposes only the approved replay whitelist of a live medium. */
export class DistributedMediumReplayWriterV1 {
    #medium;
    #onRehearsal;
    constructor(medium, onRehearsal) {
        this.#medium = medium;
        this.#onRehearsal = onRehearsal;
    }
    hasSite(siteId) { return this.#medium.replayHasSite(siteId); }
    hasBond(reference) { return this.#medium.replayHasBond(reference); }
    refreshPotentialDepth(siteId, amount) {
        this.#medium.replayRefreshPotentialDepth(siteId, amount);
    }
    strengthenExistingBond(reference, amount) {
        this.#medium.replayStrengthenExistingBond(reference, amount);
    }
    recordRehearsal(traceId) {
        if (!this.#medium.replayHasTrace(traceId))
            throw new Error('replay trace is not present');
        this.#onRehearsal(traceId);
    }
    homeostaticDownscale(factor) { this.#medium.replayHomeostaticDownscale(factor); }
}
function positiveInteger(value, label) {
    if (!Number.isInteger(value) || value < 1)
        throw new RangeError(`${label} must be a positive integer`);
}
function finiteUnit(value, label) {
    if (!Number.isFinite(value) || value < 0 || value > 1)
        throw new RangeError(`${label} must be in [0,1]`);
}
/** Replay is allowed only when the controller reports a genuinely idle state. */
export function idleForConsolidationReplayV1(signals) {
    finiteUnit(signals.novelty, 'novelty');
    finiteUnit(signals.unknown, 'unknown');
    return !signals.goalActive && !signals.pendingAttention && signals.novelty <= 0.1 && signals.unknown <= 0.1;
}
function seedToBigInt(seed) {
    if (typeof seed === 'bigint')
        return seed;
    if (!/^(?:0x)?[0-9a-f]+$/iu.test(seed))
        throw new RangeError('replay seed must be hexadecimal');
    return BigInt(seed.startsWith('0x') || seed.startsWith('0X') ? seed : `0x${seed}`);
}
/**
 * Select only already-active complete footprints. No result labels, salience,
 * support edits or new physical structures are constructed by this function.
 */
export function buildConsolidationReplayPlanV1(snapshot, seed, maxTraces = 8) {
    if (snapshot.version !== 'DistributedMediumSnapshotV1')
        throw new Error('unsupported replay source snapshot');
    positiveInteger(maxTraces, 'maxTraces');
    const eligible = snapshot.footprints.filter(footprint => footprint.supportMass > 0
        && footprint.siteIds.length > 0
        && footprint.siteIds.every(siteId => snapshot.sites[siteId]?.potentialDepth !== undefined
            && snapshot.sites[siteId].potentialDepth > 0)
        && footprint.bondReferences.every(reference => snapshot.learnedBonds.some(bond => bond.kind === reference.kind && bond.fromSiteId === reference.fromSiteId
            && bond.toSiteId === reference.toSiteId && bond.supportMass > 0
            && (reference.kind === 'local' ? bond.symmetricCoupling : bond.directedConductance) > 0)))
        .map(footprint => ({ traceId: footprint.traceId, siteIds: [...footprint.siteIds],
        bondReferences: footprint.bondReferences.map(reference => ({ ...reference })) }));
    const random = new SplitMix64(seedToBigInt(seed));
    const shuffled = [...eligible];
    for (let index = shuffled.length - 1; index > 0; index -= 1) {
        const swap = Math.floor(random.uniform() * (index + 1));
        [shuffled[index], shuffled[swap]] = [shuffled[swap], shuffled[index]];
    }
    const selected = shuffled.slice(0, Math.min(maxTraces, shuffled.length))
        .sort((left, right) => left.traceId.localeCompare(right.traceId, 'en'));
    return { version: 'ConsolidationReplayPlanV1', provenance: 'replay', selected,
        seed: `0x${seedToBigInt(seed).toString(16)}` };
}
/** Validate all replay writes before mutating a live medium. */
export function validateConsolidationReplayPlanV1(plan, writer) {
    if (plan.version !== 'ConsolidationReplayPlanV1' || plan.provenance !== 'replay')
        throw new Error('invalid consolidation replay plan');
    for (const entry of plan.selected) {
        for (const siteId of entry.siteIds)
            if (!writer.hasSite(siteId))
                throw new Error(`replay site is not present: ${siteId}`);
        for (const reference of entry.bondReferences)
            if (!writer.hasBond(reference))
                throw new Error('replay bond is not present');
    }
}
/** Execute only the replay whitelist; no trusted-real-event writer is called. */
export function executeConsolidationReplayV1(plan, writer) {
    validateConsolidationReplayPlanV1(plan, writer);
    const law = memoryTimescaleLawConfigV1();
    const potentialRefresh = 0.01;
    const bondRefresh = 0.01;
    const homeostaticFactor = law.homeostaticDownscaleFactor;
    for (const entry of plan.selected) {
        for (const siteId of entry.siteIds) {
            writer.refreshPotentialDepth(siteId, potentialRefresh);
        }
        for (const reference of entry.bondReferences) {
            writer.strengthenExistingBond(reference, bondRefresh);
        }
        writer.recordRehearsal(entry.traceId);
    }
    writer.homeostaticDownscale(homeostaticFactor);
    return { version: 'ConsolidationReplayReceiptV1', provenance: 'replay',
        selectedTraceIds: plan.selected.map(entry => entry.traceId),
        rehearsalTraceIds: plan.selected.map(entry => entry.traceId), homeostaticFactor };
}
//# sourceMappingURL=consolidation-replay.js.map