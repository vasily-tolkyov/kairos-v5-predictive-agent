import { assert, canonical, sha } from '../../util.js';
import { DistributedPhysicalMedium3DV1 } from '../physics/distributed-physical-medium.js';
import { SparseInterlayerProjectionV1 } from './sparse-interlayer-projection.js';
const DEFAULT_R2_PROJECTION_SEED = 0x5232444953543031n;
/** The runtime's passive observation marker is not a body command. */
export const PASSIVE_EXPERIENCE_IDENTITY_V1 = sha({ kind: 'passive', parameters: {}, targetRole: null });
function parseSeed(value) {
    assert(/^0x[0-9a-f]+$/i.test(value), 'distributed-R2-invalid-seed');
    return BigInt(value);
}
const PUBLIC_SIGNAL_SEPARATOR = '.';
function encodedPublicSignalV1(channel, value) {
    return `${sha({ version: 'DistributedPublicChannelV1', channel })}${PUBLIC_SIGNAL_SEPARATOR}`
        + sha({ version: 'DistributedPublicValueWithinChannelV1', channel, value });
}
/** Recover only an opaque observation-channel identity.  It is used to tell
 * "a different value was observed" from "this factor was not visible"; it
 * is never decoded into a semantic condition or a physical coordinate. */
export function distributedPublicSignalChannelIdV1(signalId) {
    if (/^[0-9a-f]{64}\.[0-9a-f]{64}$/i.test(signalId))
        return signalId.slice(0, 64);
    // Neutral tests use q:on/q:off rather than hashed public signals.  Treat the
    // prefix as their opaque sensor channel without teaching the learner what q
    // means.  A signal with no explicit value delimiter is its own channel.
    const delimiter = signalId.lastIndexOf(':');
    return delimiter > 0 ? signalId.slice(0, delimiter) : signalId;
}
/** Public-value identity used only as an opaque afferent lookup key. */
export function distributedPublicSignalOccurrencesV1(values, pulseOrdinal = 0) {
    const resolution = (property) => {
        if (property === 'self/pitch')
            return Math.PI / 12;
        if (property.endsWith('/relativeDistance') || property.includes('/egocentric/')
            || property.startsWith('crosshair/egocentric/'))
            return .25;
        if (/velocity(?:[XYZ]|\.(?:forward|right|up))$/.test(property))
            return .05;
        return null;
    };
    const result = [];
    const channels = Object.entries(values)
        .sort(([left], [right]) => left.localeCompare(right, 'en'));
    for (const [channelOrdinal, [channelProperty, channelValue]] of channels.entries()) {
        const step = resolution(channelProperty);
        if (step === null) {
            const channel = channelProperty.includes('=')
                ? channelProperty.slice(0, channelProperty.indexOf('=')) : channelProperty;
            result.push({ signalId: encodedPublicSignalV1(channel, { property: channelProperty,
                    categoricalValue: Number(channelValue.toFixed(12)) }), pulseOrdinal, channelOrdinal,
                receptorOrdinal: 0 });
            continue;
        }
        const position = channelValue / step, base = Math.floor(position);
        let receptorOrdinal = 0;
        for (let bin = base - 1; bin <= base + 2; bin++) {
            if (Math.exp(-.5 * (position - bin) ** 2) < .1)
                continue;
            result.push({ signalId: encodedPublicSignalV1(channelProperty, { populationBin: bin }),
                pulseOrdinal, channelOrdinal, receptorOrdinal });
            receptorOrdinal++;
        }
    }
    const seen = new Set();
    return result.filter(value => !seen.has(value.signalId) && !!seen.add(value.signalId));
}
/** Public-value identity used only as an opaque afferent lookup key. */
export function distributedPublicSignalIdsV1(values) {
    return distributedPublicSignalOccurrencesV1(values).map(value => value.signalId);
}
/** A lossless public-value variant used by neutral fixtures and future R3 input. */
export function distributedOpaquePublicSignalV1(subject, property, value) {
    return encodedPublicSignalV1(`${subject}/${property}`, canonical(value));
}
function dependencyConnected(left, right) {
    const leftIds = new Set(left.dependencies.map(value => value.dependencyId));
    if (right.dependencies.some(value => leftIds.has(value.dependencyId)))
        return true;
    const leftFacts = new Set(left.dependencies.map(value => `${value.subject}/${value.property}`));
    return right.dependencies.some(value => leftFacts.has(`${value.subject}/${value.property}`));
}
export function assessDistributedR2ContinuityV1(left, right) {
    if (left.sessionId !== right.sessionId)
        return { continuous: false, reason: 'session-changed' };
    if (left.continuityEpochId !== right.continuityEpochId)
        return { continuous: false, reason: 'continuity-epoch-changed' };
    if (right.startedAt < left.endedAt || right.startFrameSequence < left.endFrameSequence)
        return { continuous: false, reason: 'real-order-overlapped-or-reversed' };
    if (!dependencyConnected(left, right))
        return { continuous: false, reason: 'public-dependency-disconnected' };
    return { continuous: true, reason: 'public-continuity-evidence' };
}
/**
 * R2 owns a second, independent distributed medium.  It receives complete R1
 * population footprints as opaque physical assemblies and writes only after
 * a real multi-atom process closes.
 */
export class DistributedR2ContinuityStoreV1 {
    medium;
    #projection;
    #pending = [];
    #events = [];
    #r1Active;
    #encodingGainProvider;
    constructor(medium, seed = DEFAULT_R2_PROJECTION_SEED, state, r1Active = footprint => footprint.siteIds.length > 0 && footprint.supportMass > 0, encodingGainProvider = () => 1) {
        this.medium = medium ?? new DistributedPhysicalMedium3DV1({ name: 'R2', seedHex: '5232' });
        this.#r1Active = r1Active;
        this.#encodingGainProvider = encodingGainProvider;
        if (state) {
            assert(state.version === 'DistributedR2ContinuityStateV2'
                && parseSeed(state.projection.seedHex) === seed, 'distributed-R2-state-version-or-seed-mismatch');
            assert(state.mediumSnapshotSha256 === sha(this.medium.snapshot()), 'distributed-R2-medium-state-mismatch');
        }
        this.#projection = new SparseInterlayerProjectionV1(this.medium, 
        // A source is already one physical site, not a new sensory component.
        // Preserve the whole distributed population without expanding it again.
        { projectionId: 'R1-site-to-R2-neighbour-anchored-site-v3', seed, winnerCount: 1 }, state?.projection);
        if (state) {
            this.#pending = [...structuredClone(state.pending)];
            this.#events.push(...structuredClone(state.events));
        }
    }
    static restore(mediumSnapshot, state, r1Active, encodingGainProvider = () => 1) {
        const medium = DistributedPhysicalMedium3DV1.fromSnapshot(mediumSnapshot);
        return new DistributedR2ContinuityStoreV1(medium, parseSeed(state.projection.seedHex), state, r1Active, encodingGainProvider);
    }
    get pendingAtomCount() { return this.#pending.length; }
    get committedEventCount() { return this.#events.length; }
    lookupR1Pulse(drives) {
        return this.#projection.lookupPulse(drives);
    }
    readR1Pulse(drives) {
        return this.#projection.readSourcePulse(drives);
    }
    prescribedActionSiteIds() {
        return [...new Set(this.#events.flatMap(event => event.atomPulseRanges.flatMap((range, ordinal) => event.orderedExperienceIdentities[ordinal] === PASSIVE_EXPERIENCE_IDENTITY_V1 ? []
                : event.physicalPulseSiteIds[range.startPulseIndex + 1] ?? [])))].sort((a, b) => a - b);
    }
    #sourceNeighborhoods(atom) {
        const graph = new Map();
        for (const reference of atom.r1Footprint.bondReferences) {
            // A directed reference records temporal order, not spatial proximity.
            // Only the symmetric local bond from the R1 footprint may seed the
            // source-neighbourhood projection into R2.  Feeding a directed edge
            // here would make a later successor look like a same-time neighbour and
            // collapse otherwise distinct event populations.
            if (reference.kind !== 'local')
                continue;
            const from = graph.get(reference.fromSiteId) ?? new Set();
            const to = graph.get(reference.toSiteId) ?? new Set();
            from.add(reference.toSiteId);
            to.add(reference.fromSiteId);
            graph.set(reference.fromSiteId, from);
            graph.set(reference.toSiteId, to);
        }
        return [...graph].sort(([left], [right]) => left - right).map(([sourceSiteId, neighbors]) => ({
            sourceSiteId, neighborSiteIds: [...neighbors].sort((left, right) => left - right),
        }));
    }
    #physicalEpisode(atoms, traceId) {
        const pulses = [];
        const atomPulseRanges = [];
        const eventStartedAt = atoms[0].startedAt;
        atoms.forEach((atom, atomIndex) => {
            assert(atom.r1Topology.pulses.length > 0, 'R2-cannot-project-empty-R1-topology');
            const startPulseIndex = pulses.length;
            const duration = Math.max(0, atom.endedAt - atom.startedAt);
            const sourceNeighborhoods = this.#sourceNeighborhoods(atom);
            atom.r1Topology.pulses.forEach((sourceDrives, pulseIndex) => {
                // Exact intra-atom dwell was not retained by the R1 topology contract;
                // only the observed atom interval and original pulse order are used.
                const withinAtom = duration * pulseIndex / Math.max(1, atom.r1Topology.pulses.length);
                pulses.push(this.#projection.projectPulse({
                    pulseId: `${traceId}:atom:${atomIndex}:pulse:${pulseIndex}`,
                    offset: atom.startedAt - eventStartedAt + withinAtom,
                    drives: sourceDrives,
                    sourceNeighborhoods,
                }));
            });
            atomPulseRanges.push({ atomId: atom.atomId, startPulseIndex,
                endPulseIndexExclusive: pulses.length });
        });
        // Closing a process observes its current state, not just the last atom's
        // change list. A no-change verification must not replace all earlier
        // physical results with its generic no-change receptor. Read only the
        // final real frame, restricted to the latest measured result channels.
        // Earlier preparation is already on the ordered road: accumulating it
        // into the last basin would make every result share the same background.
        // A no-change verification carries no new result channel and therefore
        // does not erase the result being verified. Unseen objects remain unknown.
        const realSourceSites = new Set(atoms.flatMap(atom => atom.r1Topology.pulses
            .flatMap(pulse => pulse.map(drive => drive.siteId))));
        const resultScope = atoms.every(atom => atom.resultChannelR1SiteIds !== undefined)
            ? new Set(atoms.findLast(atom => atom.resultChannelR1SiteIds.length > 0)?.resultChannelR1SiteIds ?? [])
            : realSourceSites; // Explicit read-only compatibility for old atom records.
        const actualTerminal = (atoms.at(-1).observedTerminalR1Drives ?? [])
            .filter(drive => realSourceSites.has(drive.siteId) && resultScope.has(drive.siteId));
        const terminalDrives = this.#projection.lookupPulse(actualTerminal);
        if (terminalDrives.length > 0) {
            pulses.push({ version: 'SparseFieldPulseV1', pulseId: `${traceId}:observed-process-terminal`,
                offset: atoms.at(-1).endedAt - eventStartedAt, drives: terminalDrives });
            const last = atomPulseRanges.at(-1);
            atomPulseRanges[atomPulseRanges.length - 1] = { ...last, endPulseIndexExclusive: pulses.length };
        }
        return { episode: { version: 'DistributedEpisodeV1', traceId,
                provenance: 'trusted-real-event', pulses }, atomPulseRanges };
    }
    ingest(atom, boundaryBefore) {
        assert(atom.version === 'DistributedR2AtomV1', 'invalid-distributed-R2-atom');
        let closedBefore = null;
        if (boundaryBefore !== 'continuous' && this.#pending.length > 0)
            closedBefore = this.interrupt(boundaryBefore === 'gap' ? 'continuity-gap'
                : boundaryBefore === 'external-takeover' ? 'external-takeover' : 'continuity-reset');
        if (this.#pending.length > 0) {
            const assessment = assessDistributedR2ContinuityV1(this.#pending.at(-1), atom);
            if (!assessment.continuous) {
                closedBefore = assessment.reason === 'public-dependency-disconnected'
                    ? this.close('public-dependency-ended')
                    : this.interrupt(assessment.reason === 'session-changed' ? 'session-ended' : 'continuity-reset');
            }
        }
        this.#pending.push(structuredClone(atom));
        return { version: 'DistributedR2IngestReceiptV1', pendingAtomCount: this.#pending.length, closedBefore };
    }
    close(reason) {
        return this.#close('complete', reason);
    }
    interrupt(reason) {
        return this.#close('censored', reason);
    }
    #close(completion, reason) {
        if (this.#pending.length === 0)
            return { version: 'DistributedR2CloseReceiptV1', status: 'none' };
        const atoms = this.#pending;
        this.#pending = [];
        if (atoms.length < 2)
            return { version: 'DistributedR2CloseReceiptV1', status: 'singleton-rejected',
                atomId: atoms[0].atomId, completion, boundaryReason: reason };
        const eventId = sha({ version: 'DistributedR2ContinuousEventIdentityV1',
            atoms: atoms.map(value => value.atomId), completion, reason });
        const patternSha256 = sha({ version: 'DistributedR2OrderedPatternV1',
            orderedEpisodePatternIds: atoms.map(value => value.episodePatternSha256) });
        const learningEligible = completion === 'complete';
        if (learningEligible)
            assert(atoms.every(atom => this.#r1Active(atom.r1Footprint)), 'R2-continuous-event-cannot-launder-inactive-R1-physical-support');
        const projected = learningEligible ? this.#physicalEpisode(atoms, `r2-${eventId}`) : null;
        const encodingGain = this.#encodingGainProvider();
        if (!Number.isFinite(encodingGain) || encodingGain < 0.75 || encodingGain > 1.5)
            throw new RangeError('distributed-R2-encoding-gain-out-of-law-bounds');
        const footprint = projected
            ? this.medium.applyEpisodeWithEncodingGain === undefined
                ? this.medium.applyEpisode(projected.episode, 1)
                : this.medium.applyEpisodeWithEncodingGain(projected.episode, 1, encodingGain)
            : null;
        const event = { version: 'DistributedR2ContinuousEventV1', eventId,
            atomIds: atoms.map(value => value.atomId), sourceEventIds: atoms.map(value => value.sourceEventId),
            sourceR1Footprints: atoms.map(value => structuredClone(value.r1Footprint)),
            orderedExperienceIdentities: atoms.map(value => value.exactExperienceIdentity),
            orderedEpisodePatternIds: atoms.map(value => value.episodePatternSha256),
            dependencyIds: [...new Set(atoms.flatMap(value => value.dependencies.map(item => item.dependencyId)))].sort(),
            contextIds: [...new Set(atoms.map(value => value.contextId))].sort(), completion,
            boundaryReason: reason, learningEligible, physicalFootprint: footprint,
            processChanges: structuredClone(atoms.flatMap(value => value.publicChanges)),
            terminalChanges: structuredClone(atoms.at(-1).publicChanges),
            beforePublicSignals: [...atoms[0].beforePublicSignals],
            beforeSignalTimeline: atoms.map(value => [...value.beforePublicSignals]),
            beforePublicSignalOccurrences: atoms[0].beforePublicSignalOccurrences.map(value => ({ ...value,
                pulseOrdinal: 0 })),
            beforeSignalTimelineOccurrences: atoms.map((value, pulseOrdinal) => value.beforePublicSignalOccurrences.map(occurrence => ({ ...occurrence, pulseOrdinal }))),
            physicalPulseSiteIds: projected?.episode.pulses.map(pulse => pulse.drives
                .map(value => value.siteId)) ?? [],
            // Preserve the actual inter-layer amplitudes.  The site-id projection
            // above is retained as a compact compatibility readout, while R2A and
            // restored events consume this weighted stream whenever present.
            physicalPulseDrives: projected?.episode.pulses.map(pulse => pulse.drives
                .map((value) => ({ ...value }))) ?? [],
            atomPulseRanges: projected?.atomPulseRanges ?? [],
            patternSha256 };
        this.#events.push(event);
        return { version: 'DistributedR2CloseReceiptV1', status: 'committed', event: structuredClone(event) };
    }
    events(options = {}) {
        return this.#events.filter(value => !options.learningEligibleOnly || value.learningEligible)
            .map(value => structuredClone(value));
    }
    event(eventId) {
        const event = this.#events.find(value => value.eventId === eventId);
        return event ? structuredClone(event) : undefined;
    }
    eventContextIds(eventId) {
        const event = this.#events.find(value => value.eventId === eventId);
        return event ? [...event.contextIds] : undefined;
    }
    isEventActive(eventId) {
        const event = this.#events.find(value => value.eventId === eventId);
        return !!event?.physicalFootprint && !!event.sourceR1Footprints?.length
            && event.sourceR1Footprints.every(value => this.#r1Active(value))
            && this.medium.isFootprintActive(event.physicalFootprint);
    }
    /** Existing afferent sites for the open real prefix. This query never allocates. */
    currentPrefixSeedSites() {
        return [...new Set(this.currentPrefixSeedDrives().map(value => value.siteId))]
            .sort((left, right) => left - right);
    }
    /**
     * Weighted counterpart of the legacy site-id readout.  R2A prediction can
     * retain the actual R1→R2 fibre amplitudes until it reaches the protected
     * Clone boundary; callers that only need membership may continue using the
     * compact `currentPrefixSeedSites()` view above.
     */
    currentPrefixSeedDrives() {
        const atom = this.#pending.at(-1);
        if (!atom)
            return [];
        const terminal = atom.r1Topology.pulses.at(-1) ?? [];
        return this.#projection.lookupPulse(terminal).map(value => ({ ...value }));
    }
    recover(elapsed) { this.medium.recover(elapsed); }
    snapshot() {
        return { version: 'DistributedR2ContinuityStateV2', projection: this.#projection.snapshot(),
            pending: structuredClone(this.#pending),
            events: structuredClone(this.#events), mediumSnapshotSha256: sha(this.medium.snapshot()) };
    }
}
//# sourceMappingURL=distributed-r2.js.map