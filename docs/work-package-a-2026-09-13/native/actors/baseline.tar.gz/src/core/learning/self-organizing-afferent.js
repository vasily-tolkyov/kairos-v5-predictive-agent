import { eventLocalCurrentPublicStateV1, eventRows } from '../../events.js';
import { assert, canonical, sha } from '../../util.js';
import { SplitMix64 } from '../random.js';
const CANDIDATE_COUNT = 32;
const WINNER_COUNT = 8;
const ALLOCATION_SALT = 0x9e3779b97f4a7c15n;
function signalId(descriptor) {
    return sha({ version: 'AfferentSignalIdentityV1', ...descriptor });
}
function continuousResolution(property) {
    if (property === 'yaw' || property === 'pitch')
        return Math.PI / 12;
    if (/^velocity(?:[XYZ]|\.(?:forward|right|up))$/.test(property))
        return 0.05;
    if (property === 'relativeDistance' || property.startsWith('displacement.'))
        return 0.25;
    return null;
}
function categoricalSignal(source, channel, property, value, channelOrdinal, receptorOrdinal = 0) {
    const descriptor = { source, channel, publicProperty: property,
        populationBin: null, categoricalValue: canonical(value) };
    return { signalId: signalId(descriptor), intensity: 1, descriptor,
        channelOrdinal, receptorOrdinal };
}
/**
 * Continuous public values use an overlapping population code.  The bins are
 * input identities only: their eventual physical locations are chosen by the
 * medium's local competition.
 */
function publicValueSignals(channel, property, value, channelOrdinal) {
    if (typeof value !== 'number')
        return [categoricalSignal('public-state', channel, property, value, channelOrdinal)];
    assert(Number.isFinite(value), 'afferent-non-finite-public-value');
    const resolution = continuousResolution(property);
    if (resolution === null)
        return [categoricalSignal('public-state', channel, property, value, channelOrdinal)];
    const position = value / resolution;
    const base = Math.floor(position);
    const signals = [];
    for (let bin = base - 1; bin <= base + 2; bin += 1) {
        const intensity = Math.exp(-0.5 * Math.pow(position - bin, 2));
        if (intensity < 0.1)
            continue;
        const descriptor = { source: 'public-state', channel,
            publicProperty: property, populationBin: bin, categoricalValue: null };
        signals.push({ signalId: signalId(descriptor), intensity, descriptor,
            channelOrdinal, receptorOrdinal: signals.length });
    }
    // Constant population mass prevents a continuous dimension from dominating
    // categorical public changes merely because it activates several overlapping
    // receptors.  Overlap still carries metric similarity through the bins.
    const total = signals.reduce((sum, signal) => sum + signal.intensity, 0);
    return signals.map(value => ({ ...value, intensity: value.intensity / total }));
}
function cueSignals(cue) {
    // Component populations preserve similarity between related body commands.
    // One simultaneously learned whole-cue population preserves the exact
    // conjunction, so shared `kind`/`target-role` receptors cannot route an
    // explicitly different parameterized action down the wrong continuation.
    // Its identity only looks up an already self-organised binding; it never
    // chooses a coordinate or supplies an outcome.
    const signals = [categoricalSignal('cue', 'exact-cue', null, canonical(cue), 0),
        categoricalSignal('cue', 'kind', null, cue.kind, 1),
        categoricalSignal('cue', 'target-role', null, cue.targetRole, 2)];
    for (const [key, value] of Object.entries(cue.parameters).sort(([left], [right]) => left.localeCompare(right, 'en')))
        signals.push(categoricalSignal('cue', `parameter/${key}`, null, value, signals.length));
    return signals;
}
function channelKey(change) {
    return `${change.subject}/${change.property}`;
}
function stateSignals(state) {
    const result = [];
    const orderedChannels = [...state.entries()].sort(([left], [right]) => left.localeCompare(right, 'en'));
    for (const [channelOrdinal, [channel, entry]] of orderedChannels.entries()) {
        // The property is already part of the population identity.  Adding a
        // second generic "channel present" population made opposite terminal
        // values share half their sites and recreated the old resolution collapse.
        result.push(...publicValueSignals(`value/${channel}`, entry.property, entry.value, channelOrdinal));
    }
    return result;
}
function mergeSignalDrives(signals) {
    const values = new Map();
    for (const signal of signals) {
        const previous = values.get(signal.signalId);
        if (previous !== undefined && canonical(previous.descriptor) !== canonical(signal.descriptor)) {
            throw new Error(`afferent-signal-descriptor-mismatch:${signal.signalId}`);
        }
        if (previous !== undefined) {
            assert(previous.channelOrdinal === signal.channelOrdinal
                && previous.receptorOrdinal === signal.receptorOrdinal, 'afferent-signal-sensor-ordinal-mismatch');
        }
        if (previous === undefined || signal.intensity > previous.intensity)
            values.set(signal.signalId, signal);
    }
    const ordered = [...values.values()].sort((left, right) => left.channelOrdinal - right.channelOrdinal
        || left.receptorOrdinal - right.receptorOrdinal);
    for (let index = 1; index < ordered.length; index++) {
        const left = ordered[index - 1], right = ordered[index];
        assert(left.channelOrdinal !== right.channelOrdinal
            || left.receptorOrdinal !== right.receptorOrdinal, 'afferent-duplicate-public-sensor-ordinal');
    }
    return ordered;
}
function eventSignalPulses(event, previouslyObservedOutcomeChannels) {
    const rows = eventRows(event);
    // Only true public state transitions become distinct pulses.  A completed
    // no-effect window is represented by residence in one unchanged state.
    // No before/after pair, pairwise conjunction, or whole-event sequence is
    // converted into a new afferent identity: order exists only in pulse time
    // and in the directed physical bonds learned between successive pulses.
    const waves = rows.measurementChanges.map(wave => wave.filter(change => !Object.is(change.before, change.after)));
    const actualChanges = waves.flat();
    const state = new Map();
    for (const change of actualChanges) {
        const key = channelKey(change);
        if (!state.has(key))
            state.set(key, { subject: change.subject, property: change.property,
                value: change.before });
    }
    // A body command can affect self or a remote public object without a direct
    // targetId. Keep this exact cue's previously observed outcome channels in
    // every subsequent attempt, including unchanged outcomes. Otherwise failed
    // attempts lose the very channel whose condition the agent needs to learn.
    // Unrelated, never-changing context still does not enter the result basin.
    for (const [subject, properties] of Object.entries(rows.measurementStates[0] ?? {})) {
        for (const [property, value] of Object.entries(properties)) {
            const key = channelKey({ subject, property });
            if (!state.has(key) && previouslyObservedOutcomeChannels.has(key))
                state.set(key, { subject, property, value: value });
        }
    }
    if (state.size === 0)
        state.set('event/change-within-observed-window', {
            subject: 'event', property: 'change-within-observed-window', value: false,
        });
    // Reality presents the pre-action public state first, then the efference
    // copy of the exact body action, then the observed consequence.  Keeping
    // this order is essential: prediction seeds current perception followed by
    // a candidate action, so the learned directed channel must have the same
    // causal time orientation.  The pre-action state is deliberately limited
    // to properties that actually participate in this closed event; unrelated
    // scene conditions remain R2A's job.
    const physicalStep = 0.04;
    const pulses = [{ signals: mergeSignalDrives(stateSignals(state)),
            dwellSeconds: physicalStep }, { signals: mergeSignalDrives(cueSignals(event.cue)),
            dwellSeconds: physicalStep }];
    const changedObservationIndexes = waves.flatMap((wave, observationIndex) => wave.length > 0 ? [observationIndex] : []);
    const eventStart = event.frames[0].activeSeconds;
    const eventEnd = event.frames.at(-1).activeSeconds;
    const firstTransitionAt = changedObservationIndexes.length > 0
        ? event.frames[changedObservationIndexes[0]].activeSeconds : eventEnd;
    // A completed no-effect action still has a real post-action observation.
    // Reusing the same population after the cue learns action -> unchanged
    // state without inventing a displacement or a semantic result label.
    if (changedObservationIndexes.length === 0)
        pulses.push({ signals: mergeSignalDrives(stateSignals(state)),
            dwellSeconds: Number(Math.max(physicalStep, firstTransitionAt - eventStart).toFixed(9)) });
    changedObservationIndexes.forEach((observationIndex, index) => {
        const orderedWave = [...waves[observationIndex]].sort((left, right) => channelKey(left).localeCompare(channelKey(right), 'en'));
        for (const change of orderedWave)
            state.set(channelKey(change), {
                subject: change.subject, property: change.property, value: change.after,
            });
        const observedAt = event.frames[observationIndex].activeSeconds;
        const nextAt = index + 1 < changedObservationIndexes.length
            ? event.frames[changedObservationIndexes[index + 1]].activeSeconds : eventEnd;
        pulses.push({ signals: mergeSignalDrives(stateSignals(state)),
            dwellSeconds: Number(Math.max(physicalStep, nextAt - observedAt).toFixed(9)) });
    });
    return pulses;
}
function parseSeed(value) {
    assert(/^0x[0-9a-f]+$/i.test(value), 'afferent-invalid-seed');
    return BigInt(value);
}
function wavesWithActualPublicChange(event) {
    return eventRows(event).measurementChanges.filter(wave => wave.some(change => !Object.is(change.before, change.after))).length;
}
const MIN_READOUT_OVERLAP = 0.5;
const CATEGORICAL_AMBIGUITY_RATIO = 0.75;
const CONTINUOUS_RELATIVE_MASS_FLOOR = 0.09;
function parseCategoricalPublicValue(encoded) {
    const value = JSON.parse(encoded);
    assert(value === null || typeof value === 'boolean' || typeof value === 'number'
        || typeof value === 'string', 'afferent-invalid-categorical-public-value');
    if (typeof value === 'number')
        assert(Number.isFinite(value), 'afferent-non-finite-categorical-public-value');
    return value;
}
function unknownChannel(channel, property, overlap, competingOverlap, reason) {
    return { channel, property, status: reason === 'ambiguous-physical-overlap'
            ? 'ambiguous' : 'unknown', encoding: 'unknown', overlap, competingOverlap, reason };
}
function decodePublicChannel(channel, candidates) {
    const property = candidates[0].descriptor.publicProperty;
    const categorical = candidates.filter(candidate => candidate.descriptor.categoricalValue !== null);
    const continuous = candidates.filter(candidate => candidate.descriptor.populationBin !== null);
    if (categorical.length > 0 && continuous.length > 0) {
        return unknownChannel(channel, property, Math.max(...candidates.map(candidate => candidate.overlap)), 0, 'ambiguous-physical-overlap');
    }
    if (categorical.length > 0) {
        const ranked = [...categorical].sort((left, right) => right.activationMass - left.activationMass
            || right.overlap - left.overlap
            || left.binding.signalId.localeCompare(right.binding.signalId, 'en'));
        const top = ranked[0];
        const second = ranked[1];
        if (top.overlap < MIN_READOUT_OVERLAP) {
            return unknownChannel(channel, property, top.overlap, second?.overlap ?? 0, 'insufficient-physical-overlap');
        }
        if (second !== undefined && second.overlap >= MIN_READOUT_OVERLAP
            && second.activationMass >= top.activationMass * CATEGORICAL_AMBIGUITY_RATIO) {
            return unknownChannel(channel, property, top.overlap, second.overlap, 'ambiguous-physical-overlap');
        }
        return { channel, property, status: 'decoded', encoding: 'categorical',
            overlap: top.overlap, competingOverlap: second?.overlap ?? 0,
            reason: 'decoded-categorical',
            value: parseCategoricalPublicValue(top.descriptor.categoricalValue) };
    }
    const eligible = continuous.filter(candidate => candidate.overlap >= MIN_READOUT_OVERLAP);
    if (eligible.length === 0) {
        const top = [...continuous].sort((left, right) => right.overlap - left.overlap)[0];
        return unknownChannel(channel, property, top.overlap, 0, 'insufficient-physical-overlap');
    }
    const resolution = continuousResolution(property);
    assert(resolution !== null, 'afferent-continuous-descriptor-resolution-missing');
    const maximumMass = Math.max(...eligible.map(candidate => candidate.activationMass));
    const population = eligible.filter(candidate => candidate.activationMass
        >= maximumMass * CONTINUOUS_RELATIVE_MASS_FLOOR).sort((left, right) => left.descriptor.populationBin - right.descriptor.populationBin);
    if (population.some((candidate, index) => index > 0
        && candidate.descriptor.populationBin - population[index - 1].descriptor.populationBin > 1)) {
        return unknownChannel(channel, property, Math.max(...population.map(candidate => candidate.overlap)), 0, 'ambiguous-physical-overlap');
    }
    const totalMass = population.reduce((sum, candidate) => sum + candidate.activationMass, 0);
    assert(totalMass > 0, 'afferent-continuous-readout-zero-mass');
    let estimatedBin = population.reduce((sum, candidate) => sum + candidate.descriptor.populationBin * candidate.activationMass, 0) / totalMass;
    // The overlapping Gaussian code preserves the source position in the ratio
    // of any adjacent receptor pair: p=b+1/2+ln(m[b+1]/m[b]). This recovers the
    // encoded sensor value without consulting an event outcome or semantic map.
    const adjacentPairs = population.slice(1).map((right, index) => ({
        left: population[index], right,
        reliability: Math.min(population[index].activationMass, right.activationMass),
    })).filter(pair => pair.right.descriptor.populationBin
        - pair.left.descriptor.populationBin === 1)
        .sort((left, right) => right.reliability - left.reliability);
    const strongestPair = adjacentPairs[0];
    if (strongestPair !== undefined && strongestPair.left.activationMass > 0
        && strongestPair.right.activationMass > 0) {
        const ratioEstimate = strongestPair.left.descriptor.populationBin + 0.5
            + Math.log(strongestPair.right.activationMass / strongestPair.left.activationMass);
        if (Number.isFinite(ratioEstimate))
            estimatedBin = ratioEstimate;
    }
    const estimate = resolution * estimatedBin;
    const firstBin = population[0].descriptor.populationBin;
    const lastBin = population.at(-1).descriptor.populationBin;
    return { channel, property, status: 'decoded', encoding: 'continuous',
        overlap: Math.max(...population.map(candidate => candidate.overlap)), competingOverlap: 0,
        reason: 'decoded-continuous', continuous: { resolution, estimate,
            lowerBound: Math.max(firstBin - 0.5, estimatedBin - 0.5) * resolution,
            upperBound: Math.min(lastBin + 0.5, estimatedBin + 0.5) * resolution,
            populationBins: population.map(candidate => ({ bin: candidate.descriptor.populationBin,
                overlap: candidate.overlap, activationMass: candidate.activationMass })) } };
}
/**
 * Learns only afferent bindings.  It does not contain a coordinate function,
 * distance embedding, semantic map, or physical update rule.
 */
export class SelfOrganizingAfferentProjectionV1 {
    #seed;
    #allocationSequence;
    #bindings = new Map();
    #terminalOutcomeChannels = new Set();
    #terminalOutcomeScopes = new Map();
    #hasScopedOutcomeState;
    constructor(seed = 0x534f415246463031n, state) {
        this.#hasScopedOutcomeState = state === undefined || state.terminalOutcomeScopes !== undefined;
        if (state) {
            assert(state.version === 'SelfOrganizingAfferentStateV1', 'afferent-state-version-mismatch');
            assert(parseSeed(state.seedHex) === seed, 'afferent-seed-mismatch');
            assert(Number.isSafeInteger(state.allocationSequence) && state.allocationSequence >= 0, 'afferent-invalid-allocation-sequence');
            this.#seed = seed;
            this.#allocationSequence = state.allocationSequence;
            for (const binding of state.bindings) {
                assert(binding.siteIds.length === WINNER_COUNT
                    && new Set(binding.siteIds).size === WINNER_COUNT, 'afferent-invalid-restored-binding');
                assert(!this.#bindings.has(binding.signalId), 'afferent-duplicate-restored-signal');
                if (binding.descriptor !== undefined) {
                    assert(signalId(binding.descriptor) === binding.signalId, 'afferent-restored-descriptor-identity-mismatch');
                }
                this.#bindings.set(binding.signalId, { ...binding, siteIds: [...binding.siteIds],
                    ...(binding.descriptor === undefined ? {} : { descriptor: { ...binding.descriptor } }) });
            }
            for (const channel of state.terminalOutcomeChannels ?? []) {
                assert(channel.length > 0 && !this.#terminalOutcomeChannels.has(channel), 'afferent-invalid-restored-terminal-outcome-channel');
                this.#terminalOutcomeChannels.add(channel);
            }
            for (const scope of state.terminalOutcomeScopes ?? [])
                this.#terminalOutcomeScopes.set(scope.cueIdentity, new Set(scope.channels));
        }
        else {
            this.#seed = seed;
            this.#allocationSequence = 0;
        }
    }
    static restore(state) {
        return new SelfOrganizingAfferentProjectionV1(parseSeed(state.seedHex), state);
    }
    #randomForNextBinding() {
        const random = new SplitMix64(this.#seed ^ (BigInt(this.#allocationSequence + 1) * ALLOCATION_SALT));
        return () => random.uniform();
    }
    #ensureBinding(signal, medium) {
        const existing = this.#bindings.get(signal.signalId);
        if (existing) {
            if (existing.descriptor !== undefined) {
                assert(canonical(existing.descriptor) === canonical(signal.descriptor), 'afferent-existing-descriptor-mismatch');
            }
            return { binding: existing, allocated: false };
        }
        const random = this.#randomForNextBinding();
        // Pick one previously unbound seed without assigning it a meaning, then
        // let the physical lattice expose a connected local candidate patch.
        // Randomly scattered candidates produced disconnected "anchors" whose
        // apparent identity existed only in the binding table.
        const seed = medium.allocateSites(1, random);
        const candidates = medium.allocateSitesNear(seed, CANDIDATE_COUNT, random);
        assert(candidates.length === CANDIDATE_COUNT && new Set(candidates).size === CANDIDATE_COUNT, 'afferent-medium-returned-invalid-candidates');
        const winners = medium.competeForSites(candidates, WINNER_COUNT, random);
        assert(winners.length === WINNER_COUNT && new Set(winners).size === WINNER_COUNT
            && winners.every(siteId => candidates.includes(siteId)), 'afferent-medium-returned-invalid-winners');
        medium.bindSites(signal.signalId, winners);
        const binding = { signalId: signal.signalId, siteIds: [...winners],
            observationCount: 0, descriptor: { ...signal.descriptor } };
        this.#bindings.set(signal.signalId, binding);
        this.#allocationSequence += 1;
        return { binding, allocated: true };
    }
    #lookupSignals(signals, unresolvedRoles = []) {
        const siteIds = new Set();
        const drives = new Map();
        let unresolvedSignalCount = 0;
        for (const signal of mergeSignalDrives(signals)) {
            const binding = this.#bindings.get(signal.signalId);
            if (!binding) {
                unresolvedSignalCount += 1;
                continue;
            }
            binding.siteIds.forEach(siteId => {
                siteIds.add(siteId);
                drives.set(siteId, Math.max(drives.get(siteId) ?? 0, signal.intensity));
            });
        }
        const orderedSiteIds = [...siteIds].sort((left, right) => left - right);
        const orderedDrives = orderedSiteIds.map(siteId => ({ siteId, intensity: drives.get(siteId) }));
        // Keep the historical object shape for categorical/unit lookups.  A
        // weighted field is emitted only when it carries information that would be
        // lost by the compatibility id-only view.
        const weighted = orderedDrives.some(value => value.intensity !== 1);
        return { version: 'ReadOnlyAfferentLookupV1', siteIds: orderedSiteIds,
            ...(weighted ? { drives: orderedDrives } : {}), unresolvedSignalCount,
            unresolvedRoles: [...new Set(unresolvedRoles)].sort((left, right) => left.localeCompare(right, 'en')) };
    }
    /** Resolve the exact candidate action only through already learned cue bindings. */
    lookupActionCue(cue) {
        return this.#lookupSignals(cueSignals(cue));
    }
    /** Existing receptors for public channels measured in an atom's result.
     * Include their already observed alternate values, never a remembered value
     * as the answer. The closing frame must supply the actual value. */
    publicResultChannelSiteIds(resultSiteIds) {
        const result = new Set(resultSiteIds), channels = new Set();
        for (const binding of this.#bindings.values()) {
            const descriptor = binding.descriptor;
            if (descriptor?.source === 'public-state'
                && descriptor.publicProperty !== 'change-within-observed-window'
                && binding.siteIds.some(site => result.has(site)))
                channels.add(descriptor.channel);
        }
        return [...new Set([...this.#bindings.values()].filter(binding => binding.descriptor?.source === 'public-state' && channels.has(binding.descriptor.channel))
                .flatMap(binding => binding.siteIds))].sort((a, b) => a - b);
    }
    /**
     * Resolve a real current observation in an event-local public frame.  This
     * path is pure: unknown public roles or signal values remain unresolved and
     * cannot allocate, reinforce, or move an afferent binding.
     */
    lookupCurrentObservation(observation, roleBindings, cue, purpose = 'query-origin') {
        const current = eventLocalCurrentPublicStateV1(observation, roleBindings);
        return this.lookupDecodedPublicState(current.values, cue, current.unresolvedRoles, purpose);
    }
    /** Re-encode only actual terminal readout values through frozen receptors.
     * No original observation or historical after-state is available here. */
    lookupDecodedPublicState(values, cue, unresolvedRoles = [], purpose = 'query-origin') {
        const scope = cue === undefined ? undefined : this.#terminalOutcomeScopes.get(canonical(cue));
        const state = new Map(values.filter(value => {
            // A fresh prediction defines its own zero displacement/angle origin.
            // Those synthetic zeroes are not observations that an earlier moving
            // process returned to its origin. Its actual motion remains in the
            // ordered R1 pulses; only persistent public values can close an R2 road.
            if (purpose === 'observed-terminal' && (value.property === 'yaw' || value.property === 'pitch'
                || value.property.startsWith('displacement.')))
                return false;
            return scope === undefined || scope.has(`${value.subjectRole}/${value.property}`);
        }).map(value => [`${value.subjectRole}/${value.property}`,
            { subject: value.subjectRole, property: value.property, value: value.value }]));
        return this.#lookupSignals(stateSignals(state), unresolvedRoles);
    }
    /**
     * Decode only what the supplied physical population actually overlaps.
     * This is the inverse of learned afferent bindings, not an event-log lookup:
     * event ids, historical outcomes and world coordinates are unavailable here.
     */
    readPublicState(drives) {
        const active = new Map();
        for (const drive of drives) {
            assert(Number.isSafeInteger(drive.siteId) && drive.siteId >= 0, 'afferent-readout-invalid-site-id');
            assert(Number.isFinite(drive.intensity), 'afferent-readout-non-finite-intensity');
            if (drive.intensity <= 0)
                continue;
            active.set(drive.siteId, Math.max(active.get(drive.siteId) ?? 0, drive.intensity));
        }
        const allBoundSites = new Set();
        let legacyDescriptorUnavailable = false;
        const byChannel = new Map();
        for (const binding of this.#bindings.values()) {
            binding.siteIds.forEach(siteId => allBoundSites.add(siteId));
            const activeSites = binding.siteIds.filter(siteId => active.has(siteId));
            if (activeSites.length === 0)
                continue;
            if (binding.descriptor === undefined) {
                legacyDescriptorUnavailable = true;
                continue;
            }
            if (binding.descriptor.source !== 'public-state')
                continue;
            assert(binding.descriptor.publicProperty !== null, 'afferent-public-descriptor-property-missing');
            const overlap = activeSites.length / binding.siteIds.length;
            const activationMass = activeSites.reduce((sum, siteId) => sum + active.get(siteId), 0)
                / binding.siteIds.length;
            const candidates = byChannel.get(binding.descriptor.channel) ?? [];
            candidates.push({ binding, descriptor: binding.descriptor, overlap, activationMass });
            byChannel.set(binding.descriptor.channel, candidates);
        }
        const channels = [...byChannel].sort(([left], [right]) => left.localeCompare(right, 'en'))
            .map(([channel, candidates]) => decodePublicChannel(channel, candidates));
        const unmatchedSiteIds = [...active.keys()].filter(siteId => !allBoundSites.has(siteId))
            .sort((left, right) => left - right);
        const status = channels.some(channel => channel.status === 'ambiguous') ? 'ambiguous'
            : channels.length === 0 ? 'unknown'
                : channels.every(channel => channel.status === 'decoded') ? 'decoded'
                    : channels.some(channel => channel.status === 'decoded') ? 'partial' : 'unknown';
        return { version: 'AfferentPublicStateReadoutV1', status, channels,
            unmatchedSiteIds, legacyDescriptorUnavailable };
    }
    projectEvent(event, medium) {
        const rows = eventRows(event);
        const cueIdentity = canonical(event.cue);
        const knownOutcomeChannels = this.#terminalOutcomeScopes.get(cueIdentity) ?? new Set();
        const signalPulses = eventSignalPulses(event, knownOutcomeChannels);
        const uniqueSignals = new Map();
        for (const [pulseOrdinal, pulse] of signalPulses.entries())
            for (const signal of pulse.signals) {
                const previous = uniqueSignals.get(signal.signalId);
                if (previous !== undefined && canonical(previous.signal.descriptor) !== canonical(signal.descriptor)) {
                    throw new Error(`afferent-signal-descriptor-mismatch:${signal.signalId}`);
                }
                if (previous === undefined)
                    uniqueSignals.set(signal.signalId, { signal, pulseOrdinal });
            }
        let newlyAllocatedSignalCount = 0;
        const newlyAllocatedSignalIds = [];
        for (const { signal } of [...uniqueSignals.values()].sort((left, right) => left.pulseOrdinal - right.pulseOrdinal
            || left.signal.channelOrdinal - right.signal.channelOrdinal
            || left.signal.receptorOrdinal - right.signal.receptorOrdinal)) {
            const ensured = this.#ensureBinding(signal, medium);
            if (ensured.allocated) {
                newlyAllocatedSignalCount += 1;
                newlyAllocatedSignalIds.push(signal.signalId);
            }
            const next = { ...ensured.binding, observationCount: ensured.binding.observationCount + 1 };
            this.#bindings.set(signal.signalId, next);
        }
        const pulses = signalPulses.map((pulse, ordinal) => {
            const drives = new Map();
            for (const signal of pulse.signals) {
                const binding = this.#bindings.get(signal.signalId);
                for (const siteId of binding.siteIds)
                    drives.set(siteId, Math.max(drives.get(siteId) ?? 0, signal.intensity));
            }
            return { version: 'R1SparseFieldPulseV1', ordinal, dwellSeconds: pulse.dwellSeconds,
                drives: [...drives].sort(([left], [right]) => left - right)
                    .map(([siteId, intensity]) => ({ siteId, intensity })) };
        });
        assert(pulses.length >= 2 && pulses.every(pulse => pulse.drives.length > 0), 'afferent-empty-distributed-episode');
        const eventSha256 = sha(event);
        const patternSha256 = sha(signalPulses.map(pulse => pulse.signals));
        const episode = { version: 'R1DistributedEpisodeV1', eventId: event.id,
            eventSha256, pulses, patternSha256, sourceFrameCount: event.frames.length,
            retainedTransitionWaveCount: wavesWithActualPublicChange(event) };
        for (const change of rows.measurementChanges.flat()) {
            if (!Object.is(change.before, change.after)) {
                const channel = channelKey(change);
                this.#terminalOutcomeChannels.add(channel);
                knownOutcomeChannels.add(channel);
            }
        }
        this.#terminalOutcomeScopes.set(cueIdentity, knownOutcomeChannels);
        this.#hasScopedOutcomeState = true;
        return { version: 'SelfOrganizingProjectionResultV1', episode,
            newlyAllocatedSignalCount, newlyAllocatedSignalIds,
            reusedSignalCount: uniqueSignals.size - newlyAllocatedSignalCount };
    }
    snapshot() {
        return { version: 'SelfOrganizingAfferentStateV1', seedHex: `0x${this.#seed.toString(16)}`,
            allocationSequence: this.#allocationSequence,
            terminalOutcomeChannels: [...this.#terminalOutcomeChannels]
                .sort((left, right) => left.localeCompare(right, 'en')),
            ...(this.#hasScopedOutcomeState ? { terminalOutcomeScopes: [...this.#terminalOutcomeScopes]
                    .sort(([left], [right]) => left.localeCompare(right, 'en'))
                    .map(([cueIdentity, channels]) => ({ cueIdentity,
                    channels: [...channels].sort((left, right) => left.localeCompare(right, 'en')) })) } : {}),
            bindings: [...this.#bindings.values()].sort((left, right) => left.signalId.localeCompare(right.signalId, 'en')).map(binding => ({ ...binding,
                siteIds: [...binding.siteIds], ...(binding.descriptor === undefined ? {}
                    : { descriptor: { ...binding.descriptor } }) })) };
    }
}
//# sourceMappingURL=self-organizing-afferent.js.map