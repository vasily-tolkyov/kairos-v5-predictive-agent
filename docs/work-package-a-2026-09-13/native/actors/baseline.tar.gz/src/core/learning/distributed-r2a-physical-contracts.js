export {};
//# sourceMappingURL=distributed-r2a-physical-contracts.js.map