/** Recover commands from the frozen R1 contract (before, command, observed
 * changes), never from result identities or a desired terminal. */
export function r2aInputAtActionBoundaryV1(input, event) {
    const weighted = (sites) => sites.map(siteId => ({ siteId, intensity: 1 }));
    const projected = input.projectedPulseDrives ?? input.projectedPulseSiteIds.map(weighted);
    const actions = input.actionPulseDrives ?? input.actionPulseSiteIds.map(weighted);
    const route = [input.conditionDrives ?? weighted(input.conditionSiteIds)];
    const commandIndices = [];
    event.atomPulseRanges.forEach((range, ordinal) => {
        const commandIndex = range.startPulseIndex + 1;
        if (commandIndex >= range.endPulseIndexExclusive || projected[commandIndex] === undefined)
            throw new Error('R2A-source-atom-missing-actual-command-pulse');
        commandIndices.push(commandIndex);
        route.push(actions[ordinal]);
        const end = ordinal === event.atomPulseRanges.length - 1
            ? commandIndex + 1 : range.endPulseIndexExclusive;
        route.push(...projected.slice(range.startPulseIndex, end));
    });
    return { ...input, projectedCommandPulseIndices: commandIndices,
        reachableContinuationPulseDrives: route,
        reachableContinuationPulseSiteIds: route.map(pulse => pulse.map(drive => drive.siteId)) };
}
//# sourceMappingURL=r2a-action-input-boundary.js.map