/** Build native distributed evidence without manufacturing page/point fields. */
export function distributedEvidenceReferenceV1(input) {
    return {
        version: 'DistributedPhysicalEvidenceReferenceV3', eventId: input.eventId,
        experienceTraceId: input.r1.traceId,
        r1: { active: input.r1Active, footprintTraceIds: [input.r1.traceId],
            supportStrength: input.r1SupportStrength, attractorId: input.r1AttractorId,
            returnRate: input.r1ReturnRate, escapeRate: input.r1EscapeRate },
        r2: { active: input.r2Active, footprintTraceIds: input.r2 ? [input.r2.traceId] : [],
            supportStrength: input.r2SupportStrength, corridorId: input.r2CorridorId },
        r2a: { active: input.r2aSupportStrength > 0,
            footprintTraceIds: [...input.r2aPhysicalTraceIds], supportStrength: input.r2aSupportStrength,
            patternIds: [...input.patternIds], relationIds: [...input.relationIds],
            branchSelectionStrength: input.applicability, applicability: input.applicability,
            productionEligible: input.productionEligible, predictionEligible: input.predictionEligible,
            evidenceGrade: input.evidenceGrade },
    };
}
/** Decode only assemblies physically reached by this stochastic field run. */
export function distributedPredictionSampleV1(seed, result, changesByAssembly) {
    return {
        version: 'DistributedPredictionSampleV3', seed, status: result.status, reason: result.reason,
        fieldSteps: result.fieldRun.steps, acceptedSteps: result.fieldRun.acceptedSteps,
        rejectedSteps: result.fieldRun.rejectedSteps,
        leaderSiteIds: [...result.fieldRun.leaderSiteIds],
        attractorCoreSiteIds: [...result.attractorReadout.coreSiteIds],
        attractorDwellSteps: result.attractorReadout.dwellSteps,
        attractorReturnRate: result.attractorReadout.returnRate,
        attractorEscapeRate: result.attractorReadout.escapeRate,
        reaches: result.reaches.map(reach => ({ assemblyId: reach.assemblyId,
            reachedFraction: reach.reachedFraction, purity: reach.purity,
            residenceScore: reach.residenceScore, visitedSiteIds: [...reach.visitedSiteIds],
            changes: structuredClone(changesByAssembly.get(reach.assemblyId) ?? []) })),
    };
}
export function emptyDistributedPredictionV1(kind, reason, evidence, substrateSha256) {
    return { version: 'DistributedPredictionV3', kind, support: 0, calibratedProbability: false,
        samples: [], evidence, unknown: [reason], substrateSha256 };
}
//# sourceMappingURL=distributed-reasoning-adapter.js.map