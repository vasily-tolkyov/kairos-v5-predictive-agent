import { cueIdentity } from '../events.js';
import { assert, canonical, sha } from '../util.js';
const reasoningOperations = new Set(['recall-effect', 'compare-condition', 'predict-branch', 'expand-condition']);
const bodyOperations = new Set(['execute', 'observe-public']);
const experiencedNodeId = (objectiveNodeId, candidateId, rootObjective) => rootObjective ? `experienced:${candidateId}` : `experienced:${sha([objectiveNodeId, candidateId])}:${candidateId}`;
const transitionNodeId = (physicalGroupKey) => `factor-transition:${physicalGroupKey}`;
// An offerId is bound to one raw observation sequence.  Using it as the
// transient branch identity created the same legal action again at every
// Minecraft physics tick and made a stationary scene grow without bound.
// The branch identity is the exact action cue plus its real public target;
// the stored offer is refreshed to the newest observation before execution.
const explorationNodeId = (offer) => `exploration:${sha({
    cue: cueIdentity(offer.cue), targetId: offer.action.targetId ?? null,
})}`;
// One grounded public fact is one transient objective even when several
// remembered branches currently depend on it.  The dependency edges preserve
// all parent links; including a parent in this identity would duplicate the
// same question and crowd the finite control field with aliases.
const publicRequirementNodeId = (goal) => `public-requirement:${sha(goal)}`;
const effectSignature = (changes) => changes.map(change => ({ subject: change.subject, property: change.property,
    before: change.before, after: change.after, meaning: change.meaning }))
    .sort((left, right) => JSON.stringify(left).localeCompare(JSON.stringify(right), 'en'));
function physicalEvidenceGroupingIdentity(evidence) {
    return { version: 'distributed-physical-control-group-v3',
        r1AttractorId: evidence.r1.attractorId,
        r2CorridorId: evidence.r2.corridorId,
        r2aPatternIds: [...evidence.r2a.patternIds].sort(),
        r2aRelationIds: [...evidence.r2a.relationIds].sort() };
}
/** Exact, non-semantic identity allowed to reduce finite control-field load. */
export function effectCandidatePhysicalGroupKeyV1(objectiveNodeId, candidate) {
    return sha({ objectiveNodeId, exactCue: cueIdentity(candidate.actionCue),
        r2Basin: physicalEvidenceGroupingIdentity(candidate.evidence),
        relationIds: [...candidate.evidence.r2a.relationIds].sort(),
        effectSignature: effectSignature(candidate.observedChanges) });
}
/**
 * A parent branch says who currently needs a transition; it is not part of
 * the transition's physical identity.  Keeping the parent in this key made
 * one real R1/R2/R2A branch appear once per ancestor and recursively crowded
 * the finite control field with aliases.
 */
export function factorTransitionPhysicalGroupKeyV2(transition) {
    return sha({ version: 'factor-transition-physical-group-v2', exactCue: cueIdentity(transition.actionCue),
        r2Basin: physicalEvidenceGroupingIdentity(transition.evidence),
        relationIds: [...transition.evidence.r2a.relationIds].sort(),
        evidenceGrade: transition.evidence.r2a.evidenceGrade ?? null,
        predictionEligible: transition.evidence.r2a.predictionEligible ?? false,
        effectSignature: { activated: [...transition.activatedFactorIds].sort(),
            deactivated: [...transition.deactivatedFactorIds].sort(),
            unchangedActive: [...transition.unchangedActiveFactorIds].sort() } });
}
export function groupEffectCandidatesForControlV1(objectiveNodeId, candidates) {
    const grouped = new Map();
    for (const candidate of candidates) {
        const key = effectCandidatePhysicalGroupKeyV1(objectiveNodeId, candidate);
        const members = grouped.get(key) ?? [];
        members.push(structuredClone(candidate));
        grouped.set(key, members);
    }
    return [...grouped].sort(([left], [right]) => left.localeCompare(right, 'en')).map(([physicalGroupKey, members]) => ({
        physicalGroupKey,
        members: members.sort((left, right) => left.candidateId.localeCompare(right.candidateId, 'en')),
    }));
}
export function groupFactorTransitionsForControlV2(transitions) {
    const grouped = new Map();
    for (const transition of transitions) {
        const key = factorTransitionPhysicalGroupKeyV2(transition);
        const members = grouped.get(key) ?? [];
        members.push(structuredClone(transition));
        grouped.set(key, members);
    }
    return [...grouped].sort(([left], [right]) => left.localeCompare(right, 'en')).map(([physicalGroupKey, members]) => ({
        physicalGroupKey,
        members: members.sort((left, right) => left.transitionId.localeCompare(right.transitionId, 'en')),
    }));
}
/**
 * Keep control/audit snapshots bounded without changing the live physical
 * prediction. The controller needs readouts and outcome counts; the complete
 * integration path remains available only on the immediate PhysicalMemory
 * result. Endpoints plus the original count make this projection explicit.
 */
export function compactBranchPredictionForControlAuditV2(value) {
    const compactSingle = (single) => structuredClone(single);
    const { memberResults, winningCandidateId, ...single } = value;
    return { ...compactSingle(single),
        ...(memberResults ? { memberResults: memberResults.map(member => ({ candidateId: member.candidateId,
                value: compactSingle(member.value) })) } : {}),
        ...(winningCandidateId !== undefined ? { winningCandidateId } : {}) };
}
/**
 * Persistent-in-a-run dependency workspace for joint control. It stores evidence and graph
 * continuity, but never decides an operation, creates a semantic subgoal, or writes memory.
 */
export class ControlWorkspaceV2 {
    #nodes = new Map();
    #dependencies = new Map();
    #pending = new Map();
    #usedRequestIds = new Set();
    #completedOperations = [];
    #attentionNotices = [];
    #goalId = null;
    #rootNodeId = null;
    #epoch = 0;
    #observation = null;
    #offers = [];
    #goalEvaluation = null;
    #lastFailure = null;
    setGoal(goal) {
        this.#nodes.clear();
        this.#dependencies.clear();
        this.#pending.clear();
        this.#usedRequestIds.clear();
        this.#completedOperations.length = 0;
        this.#attentionNotices.length = 0;
        this.#observation = null;
        this.#offers = [];
        this.#goalEvaluation = null;
        this.#lastFailure = null;
        this.#epoch++;
        this.#goalId = goal.id;
        this.#rootNodeId = `root:${goal.id}`;
        this.#nodes.set(this.#rootNodeId, { node: { nodeId: this.#rootNodeId, kind: 'root', goal: structuredClone(goal),
                createdEpoch: this.#epoch, createdObservationSequence: null }, continuousPatterns: [], condition: null, prediction: null,
            continuationPredictions: null,
            lastActionResult: null });
        return this.#rootNodeId;
    }
    registerExploration(offer) {
        this.#requireGoal();
        const nodeId = explorationNodeId(offer);
        this.#upsertNode({ nodeId, kind: 'exploration', offer: structuredClone(offer), createdEpoch: this.#epoch,
            createdObservationSequence: offer.observationSequence });
        return nodeId;
    }
    /**
     * Preserve a body's missing public fact as a transient goal node.  The body
     * supplies no method for satisfying it; effect recall must populate any
     * candidate branches later.
     */
    registerPublicRequirement(dependentNodeId, goal, kind = 'public-action-requirement') {
        this.#requireGoal();
        this.#requireNode(dependentNodeId);
        const nodeId = publicRequirementNodeId(goal);
        this.#upsertNode({ nodeId, kind: 'public-requirement', goal: structuredClone(goal),
            createdEpoch: this.#epoch, createdObservationSequence: this.#observation?.sequence ?? null });
        this.#addDependency(dependentNodeId, nodeId, [], kind);
        return nodeId;
    }
    addDependency(dependentNodeId, requiredNodeId, factorIds) {
        return this.#addDependency(dependentNodeId, requiredNodeId, factorIds, 'opaque-factor');
    }
    #addDependency(dependentNodeId, requiredNodeId, factorIds, kind) {
        this.#requireNode(dependentNodeId);
        this.#requireNode(requiredNodeId);
        const normalizedFactors = [...new Set(factorIds)].sort((left, right) => left.localeCompare(right, 'en'));
        if (dependentNodeId === requiredNodeId || this.#hasDependencyPath(requiredNodeId, dependentNodeId))
            return { accepted: false, reason: 'dependency-cycle-rejected', registeredNodeIds: [] };
        const edgeId = `requires:${JSON.stringify([kind, dependentNodeId, requiredNodeId, normalizedFactors])}`;
        if (!this.#dependencies.has(edgeId))
            this.#dependencies.set(edgeId, { edgeId, dependentNodeId, requiredNodeId,
                factorIds: normalizedFactors, kind, createdEpoch: this.#epoch,
                createdObservationSequence: this.#observation?.sequence ?? 0 });
        return { accepted: true, reason: 'dependency-recorded', registeredNodeIds: [requiredNodeId] };
    }
    beginRequest(input) {
        this.#requireGoal();
        this.#requireNode(input.nodeId);
        assert(!this.#usedRequestIds.has(input.requestId), 'control-request-id-reused');
        assert(this.#observation && input.baseSequence === this.#observation.sequence, 'control-request-base-sequence-not-current');
        assert(input.channel === 'reasoning' ? reasoningOperations.has(input.operation) : bodyOperations.has(input.operation), 'control-request-channel-operation-mismatch');
        assert(![...this.#pending.values()].some(request => request.channel === input.channel), `control-${input.channel}-request-already-in-flight`);
        const request = { ...structuredClone(input), epoch: this.#epoch,
            factorIds: [...new Set(input.factorIds ?? [])].sort((left, right) => left.localeCompare(right, 'en')),
            invalidated: false };
        this.#pending.set(request.requestId, request);
        this.#usedRequestIds.add(request.requestId);
        return structuredClone(request);
    }
    ingest(event) {
        switch (event.kind) {
            case 'observation': return this.#ingestObservation(event);
            case 'attention': return this.#ingestAttention(event.notice);
            case 'action-completed': return this.#ingestAction(event);
            case 'operation-failed': return this.#ingestFailure(event);
            case 'operation-completed': return this.#ingestOperation(event);
        }
    }
    currentCondition(nodeId) {
        const evidence = this.#requireNode(nodeId).condition;
        return this.#fresh(evidence) ? structuredClone(evidence.value) : null;
    }
    invalidateFeedback() {
        this.#epoch++;
        this.#invalidateTransientEvidence('feedback');
        this.#invalidatePending();
    }
    currentPrediction(nodeId) {
        const evidence = this.#requireNode(nodeId).prediction;
        return this.#fresh(evidence) ? structuredClone(evidence.value) : null;
    }
    currentContinuationPredictions(nodeId) {
        const evidence = this.#requireNode(nodeId).continuationPredictions;
        return this.#fresh(evidence) ? structuredClone(evidence.value) : null;
    }
    hasCompleted(operation, nodeId, options = {}) {
        return this.#completedOperations.some(value => value.operation === operation && value.nodeId === nodeId
            && (!options.currentEpoch || value.epoch === this.#epoch)
            && (!options.currentObservation || value.baseSequence === this.#observation?.sequence));
    }
    snapshot() {
        const sequence = this.#observation?.sequence ?? null;
        const nodes = [...this.#nodes.values()].map(state => ({ node: structuredClone(state.node),
            continuousPatterns: structuredClone(state.continuousPatterns),
            condition: state.condition ? { ...structuredClone(state.condition), fresh: this.#fresh(state.condition) } : null,
            prediction: state.prediction ? {
                requestId: state.prediction.requestId,
                epoch: state.prediction.epoch,
                observationSequence: state.prediction.observationSequence,
                invalidatedBy: state.prediction.invalidatedBy,
                value: compactBranchPredictionForControlAuditV2(state.prediction.value),
                fresh: this.#fresh(state.prediction),
            } : null,
            continuationPredictions: state.continuationPredictions ? {
                ...structuredClone(state.continuationPredictions), fresh: this.#fresh(state.continuationPredictions),
            } : null,
            lastActionResult: state.lastActionResult ? structuredClone(state.lastActionResult) : null }))
            .sort((left, right) => left.node.nodeId.localeCompare(right.node.nodeId, 'en'));
        return { version: 'ControlWorkspaceV2', goalId: this.#goalId, rootNodeId: this.#rootNodeId,
            epoch: this.#epoch, observationSequence: sequence,
            observation: this.#observation ? structuredClone(this.#observation) : null,
            offers: structuredClone(this.#offers), goalEvaluation: this.#goalEvaluation ? structuredClone(this.#goalEvaluation) : null,
            nodes, dependencies: [...this.#dependencies.values()].map(value => structuredClone(value))
                .sort((left, right) => left.edgeId.localeCompare(right.edgeId, 'en')),
            pendingRequests: [...this.#pending.values()].map(value => structuredClone(value))
                .sort((left, right) => left.requestId.localeCompare(right.requestId, 'en')),
            completedOperations: structuredClone(this.#completedOperations),
            attentionNotices: structuredClone(this.#attentionNotices),
            lastFailure: this.#lastFailure ? structuredClone(this.#lastFailure) : null };
    }
    #ingestObservation(event) {
        this.#requireGoal();
        if (this.#observation && (event.observation.sequence < this.#observation.sequence
            || (event.observation.sequence === this.#observation.sequence && this.#goalEvaluation !== null)))
            return { accepted: false, reason: 'stale-or-out-of-order-observation', registeredNodeIds: [] };
        if (event.goalEvaluation.goalId !== this.#goalId
            || event.goalEvaluation.observationSequence !== event.observation.sequence)
            return { accepted: false, reason: 'observation-goal-evaluation-mismatch', registeredNodeIds: [] };
        if (event.offers.some(offer => offer.observationSequence !== event.observation.sequence))
            return { accepted: false, reason: 'observation-offer-sequence-mismatch', registeredNodeIds: [] };
        this.#observation = structuredClone(event.observation);
        this.#offers = structuredClone(event.offers);
        this.#goalEvaluation = structuredClone(event.goalEvaluation);
        return { accepted: true, reason: 'observation-accepted', registeredNodeIds: [] };
    }
    #ingestAttention(notice) {
        this.#requireGoal();
        this.#epoch++;
        this.#attentionNotices.push(structuredClone(notice));
        this.#invalidateTransientEvidence('attention');
        this.#invalidatePending();
        return { accepted: true, reason: 'attention-retained-graph-and-invalidated-transient-evidence', registeredNodeIds: [] };
    }
    #ingestAction(event) {
        const request = this.#pending.get(event.requestId);
        if (!request || request.channel !== 'body' || request.nodeId !== event.nodeId)
            return { accepted: false, reason: 'unknown-or-mismatched-action-request', registeredNodeIds: [] };
        this.#pending.delete(event.requestId);
        this.#requireNode(event.nodeId).lastActionResult = structuredClone(event.result);
        this.#epoch++;
        this.#invalidateTransientEvidence('action');
        this.#invalidatePending();
        if (!this.#observation || event.result.observation.sequence > this.#observation.sequence) {
            this.#observation = structuredClone(event.result.observation);
            this.#offers = [];
            this.#goalEvaluation = null;
        }
        return { accepted: true, reason: 'real-action-result-accepted', registeredNodeIds: [] };
    }
    #ingestFailure(event) {
        const request = this.#pending.get(event.requestId);
        if (!request || !this.#sameRequest(request, event))
            return { accepted: false, reason: 'unknown-or-mismatched-failed-request', registeredNodeIds: [] };
        this.#pending.delete(event.requestId);
        this.#lastFailure = { requestId: event.requestId, error: structuredClone(event.error) };
        return { accepted: true, reason: 'operation-failure-recorded', registeredNodeIds: [] };
    }
    #ingestOperation(event) {
        const request = this.#pending.get(event.requestId);
        if (!request || !this.#sameRequest(request, event))
            return { accepted: false, reason: 'unknown-or-mismatched-operation-result', registeredNodeIds: [] };
        this.#pending.delete(event.requestId);
        // Historical recall is goal-bound evidence. A newer public frame or attention
        // epoch does not turn a real past event into a different event. State-bound
        // comparisons, rollouts and factor expansion remain strict.
        if (event.operation !== 'recall-effect' && (request.invalidated || event.epoch !== this.#epoch))
            return { accepted: false, reason: 'stale-operation-epoch', registeredNodeIds: [] };
        if ((event.operation === 'compare-condition' || event.operation === 'predict-branch')
            && this.#observation?.sequence !== event.baseSequence)
            return { accepted: false, reason: 'stale-operation-observation', registeredNodeIds: [] };
        this.#completedOperations.push({ requestId: event.requestId, operation: event.operation,
            nodeId: event.nodeId, epoch: event.epoch, baseSequence: event.baseSequence,
            resultCount: event.operation === 'recall-effect' ? event.result.atomicCandidates.length
                + event.result.continuousPatterns.length : event.operation === 'expand-condition' ? event.result.length : 1 });
        if (this.#completedOperations.length > 128)
            this.#completedOperations.splice(0, this.#completedOperations.length - 128);
        if (event.operation === 'recall-effect') {
            const objectiveState = this.#requireNode(event.nodeId);
            objectiveState.continuousPatterns = event.result.continuousPatterns.map(pattern => ({
                pattern: structuredClone(pattern), sharedRelationIds: [],
            }));
            const registered = groupEffectCandidatesForControlV1(event.nodeId, event.result.atomicCandidates)
                .map(group => this.#registerExperienced(event.nodeId, group.physicalGroupKey, group.members));
            for (const nodeId of registered) {
                const branch = this.#requireNode(nodeId);
                const relationIds = new Set((branch.node.kind === 'experienced'
                    ? branch.node.candidateMembers ?? [branch.node.candidate] : [])
                    .flatMap(candidate => candidate.evidence.r2a.relationIds));
                branch.continuousPatterns = event.result.continuousPatterns.flatMap(pattern => {
                    const sharedRelationIds = [...new Set(pattern.currentRelationIds ?? [])]
                        .filter(relationId => relationIds.has(relationId)).sort((left, right) => left.localeCompare(right, 'en'));
                    return sharedRelationIds.length ? [{ pattern: structuredClone(pattern), sharedRelationIds }] : [];
                });
            }
            if (this.#requireNode(event.nodeId).node.kind === 'public-requirement')
                for (const nodeId of registered)
                    this.#addDependency(event.nodeId, nodeId, [], 'public-requirement-candidate');
            return { accepted: true, reason: 'historical-effect-recall-accepted', registeredNodeIds: registered };
        }
        if (event.operation === 'expand-condition') {
            const registered = [];
            for (const group of groupFactorTransitionsForControlV2(event.result)) {
                const nodeId = this.#registerTransition(event.nodeId, group.physicalGroupKey, group.members);
                registered.push(nodeId);
                this.addDependency(event.nodeId, nodeId, request.factorIds);
            }
            return { accepted: true, reason: 'factor-transition-recall-accepted', registeredNodeIds: registered };
        }
        const state = this.#requireNode(event.nodeId);
        if (event.operation === 'compare-condition')
            state.condition = { requestId: event.requestId, epoch: event.epoch,
                observationSequence: event.baseSequence, value: structuredClone(event.result), invalidatedBy: null };
        else {
            state.prediction = { requestId: event.requestId, epoch: event.epoch,
                observationSequence: event.baseSequence, value: structuredClone(event.result.atomic), invalidatedBy: null };
            state.continuationPredictions = { requestId: event.requestId, epoch: event.epoch,
                observationSequence: event.baseSequence, value: structuredClone(event.result.continuations), invalidatedBy: null };
        }
        return { accepted: true, reason: `${event.operation}-accepted`, registeredNodeIds: [event.nodeId] };
    }
    #registerExperienced(objectiveNodeId, physicalGroupKey, candidateMembers) {
        assert(candidateMembers.length > 0, 'empty-experienced-physical-group');
        const candidate = candidateMembers[0];
        const objective = this.#requireNode(objectiveNodeId).node;
        let nodeId = experiencedNodeId(objectiveNodeId, candidate.candidateId, objective.kind === 'root');
        const collision = this.#nodes.get(nodeId)?.node;
        if (collision?.kind === 'experienced' && collision.physicalGroupKey !== physicalGroupKey)
            nodeId = `${nodeId}:physical-group:${physicalGroupKey}`;
        this.#upsertNode({ nodeId, kind: 'experienced', candidate: structuredClone(candidate),
            candidateMembers: structuredClone(candidateMembers), physicalGroupKey, objectiveNodeId,
            createdEpoch: this.#epoch,
            createdObservationSequence: this.#observation?.sequence ?? null });
        return nodeId;
    }
    #registerTransition(objectiveNodeId, physicalGroupKey, transitionMembers) {
        assert(transitionMembers.length > 0, 'empty-factor-transition-physical-group');
        void objectiveNodeId;
        const nodeId = transitionNodeId(physicalGroupKey);
        const prior = this.#nodes.get(nodeId);
        assert(!prior || prior.node.kind === 'factor-transition', 'factor-transition-physical-node-kind-collision');
        if (prior?.node.kind === 'factor-transition')
            assert(prior.node.physicalGroupKey === physicalGroupKey, 'factor-transition-physical-key-collision');
        const byId = new Map();
        const add = (member) => {
            const existing = byId.get(member.transitionId);
            if (existing) {
                // The real event/factor transition is immutable. Its present physical
                // support and R3 applicability are query-time views, not its identity.
                const { evidence: _oldEvidence, ...oldFact } = existing;
                const { evidence: _newEvidence, ...newFact } = member;
                assert(canonical(oldFact) === canonical(newFact), 'factor-transition-member-identity-collision');
            }
            byId.set(member.transitionId, structuredClone(member));
        };
        if (prior?.node.kind === 'factor-transition')
            for (const member of prior.node.transitionMembers ?? [prior.node.transition])
                add(member);
        for (const member of transitionMembers)
            add(member);
        const merged = [...byId.values()].sort((left, right) => left.transitionId.localeCompare(right.transitionId, 'en'));
        const evidenceChanged = prior?.node.kind === 'factor-transition'
            && canonical(prior.node.transitionMembers ?? [prior.node.transition]) !== canonical(merged);
        const node = { nodeId, kind: 'factor-transition', transition: merged[0],
            transitionMembers: merged, physicalGroupKey,
            createdEpoch: prior?.node.createdEpoch ?? this.#epoch,
            createdObservationSequence: prior?.node.createdObservationSequence
                ?? this.#observation?.sequence ?? null };
        if (prior) {
            prior.node = node;
            // A changed member set OR current support view needs fresh comparison
            // and prediction. Refreshing history does not certify its applicability.
            if (evidenceChanged) {
                prior.condition = null;
                prior.prediction = null;
                prior.continuationPredictions = null;
            }
        }
        else
            this.#upsertNode(node);
        return nodeId;
    }
    #upsertNode(node) {
        const prior = this.#nodes.get(node.nodeId);
        if (prior) {
            prior.node = node;
            return;
        }
        this.#nodes.set(node.nodeId, { node, continuousPatterns: [], condition: null, prediction: null,
            continuationPredictions: null, lastActionResult: null });
    }
    #hasDependencyPath(startNodeId, targetNodeId) {
        const visited = new Set(), pending = [startNodeId];
        while (pending.length) {
            const current = pending.pop();
            if (current === targetNodeId)
                return true;
            if (visited.has(current))
                continue;
            visited.add(current);
            for (const edge of this.#dependencies.values())
                if (edge.dependentNodeId === current)
                    pending.push(edge.requiredNodeId);
        }
        return false;
    }
    #invalidateTransientEvidence(reason) {
        for (const state of this.#nodes.values()) {
            if (state.condition && !state.condition.invalidatedBy)
                state.condition = { ...state.condition, invalidatedBy: reason };
            if (state.prediction && !state.prediction.invalidatedBy)
                state.prediction = { ...state.prediction, invalidatedBy: reason };
            if (state.continuationPredictions && !state.continuationPredictions.invalidatedBy)
                state.continuationPredictions = { ...state.continuationPredictions, invalidatedBy: reason };
        }
    }
    #invalidatePending() {
        for (const [requestId, request] of this.#pending)
            if (request.channel === 'reasoning')
                this.#pending.set(requestId, { ...request, invalidated: true });
    }
    #fresh(evidence) {
        return !!evidence && !evidence.invalidatedBy && evidence.epoch === this.#epoch
            && evidence.observationSequence === this.#observation?.sequence;
    }
    #sameRequest(request, event) {
        return request.requestId === event.requestId && request.epoch === event.epoch && request.operation === event.operation
            && request.nodeId === event.nodeId && request.baseSequence === event.baseSequence;
    }
    #requireGoal() { assert(this.#rootNodeId && this.#goalId, 'control-workspace-goal-not-set'); }
    #requireNode(nodeId) {
        const node = this.#nodes.get(nodeId);
        assert(node, `control-workspace-node-not-found:${nodeId}`);
        return node;
    }
}
//# sourceMappingURL=workspace.js.map