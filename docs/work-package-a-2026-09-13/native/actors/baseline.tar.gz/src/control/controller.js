import { cueIdentity } from '../events.js';
import { assert, sha } from '../util.js';
import { JointTransientControlFieldV2 } from './field.js';
import { ControlHabitWeightsV1 } from './habit.js';
import { goalPredicates, groundedPublicObservableV1, GroundedGoalEvaluatorV1 } from './goal.js';
import { compactBranchPredictionForControlAuditV2, ControlWorkspaceV2 } from './workspace.js';
import { ActiveControlTrajectoryV1 } from './active-trajectory.js';
import { physicalDependencyPathsV1 } from './short-chain-paths.js';
const zeroDrives = () => ({ goal: 0, evidence: 0, condition: 0, rollout: 0,
    unknown: 0, attention: 0, novelty: 0, habit: 0 });
const clamp01 = (value) => Math.max(0, Math.min(1, value));
const pseudoGoal = (id) => ({ version: 'GroundedGoalV1', id,
    expression: { kind: 'predicate', predicate: { version: 'GoalPredicateV1', id: `${id}:open-ended`,
            subject: { kind: 'self' }, observable: 'visible', comparator: 'equals', target: false } } });
/** Fair admission into the finite transient workspace; this never scores an action. */
export function fairEvidenceWindowV2(values, capacity, rotation, identity) {
    assert(Number.isInteger(capacity) && capacity > 0 && Number.isInteger(rotation) && rotation >= 0, 'invalid-joint-control-evidence-window');
    if (values.length <= capacity)
        return { selected: [...values], nextRotation: rotation };
    const groups = new Map();
    for (const value of values) {
        const key = identity(value), group = groups.get(key) ?? [];
        group.push(value);
        groups.set(key, group);
    }
    const ordered = [...groups.entries()].sort(([left], [right]) => left.localeCompare(right, 'en'));
    const groupOffset = rotation % ordered.length, withinOffset = Math.floor(rotation / ordered.length);
    const selected = [];
    for (let round = 0; selected.length < capacity && round < values.length; round++) {
        let added = false;
        for (let offset = 0; offset < ordered.length && selected.length < capacity; offset++) {
            const group = ordered[(groupOffset + offset) % ordered.length][1];
            if (round >= group.length)
                continue;
            selected.push(group[(withinOffset + round) % group.length]);
            added = true;
        }
        if (!added)
            break;
    }
    return { selected, nextRotation: rotation + Math.max(1, Math.ceil(capacity / ordered.length)) };
}
/** Finite workspace admission must never contain only blind exploration while
 * goal-grounded physical work is available.  One rotating grounded anchor is
 * reserved; every remaining slot is still filled by the ordinary fair window,
 * so this admits evidence without choosing an operation or action winner. */
export function fairGroundedControlWindowV2(values, capacity, rotation, identity, isGrounded) {
    assert(Number.isInteger(capacity) && capacity > 0 && Number.isInteger(rotation) && rotation >= 0, 'invalid-grounded-control-window');
    if (values.length <= capacity || !values.some(isGrounded))
        return fairEvidenceWindowV2(values, capacity, rotation, identity);
    const indexed = values.map((value, index) => ({ value, index }));
    const grounded = fairEvidenceWindowV2(indexed.filter(entry => isGrounded(entry.value)), 1, rotation, entry => identity(entry.value));
    const anchor = grounded.selected[0];
    if (capacity === 1)
        return { selected: [anchor.value], nextRotation: grounded.nextRotation };
    const remainder = fairEvidenceWindowV2(indexed.filter(entry => entry.index !== anchor.index), capacity - 1, grounded.nextRotation, entry => identity(entry.value));
    return { selected: [anchor.value, ...remainder.selected.map(entry => entry.value)],
        nextRotation: remainder.nextRotation };
}
/** Blind exploration is pressure for the absence of usable goal-grounded work,
 * not a permanent competitor to evidence that is still being compared or
 * predicted.  Keep the transient sites themselves (and their activation), but
 * remove only their unknown/novelty input while any grounded physical operation
 * remains available.  When that work is exhausted the same sites regain their
 * ordinary inputs on the next control event. */
export function modulateBlindExplorationInputsV2(sites, groundedWorkAvailable) {
    if (!groundedWorkAvailable)
        return sites;
    return sites.map(site => site.drives.goal === 0 && site.drives.evidence === 0 && site.drives.rollout === 0
        ? { ...site, drives: { ...site.drives, unknown: 0, novelty: 0 } }
        : site);
}
/** A retained physical branch with an unresolved condition is already useful
 * reasoning work, even before it is production-qualified.  Its compare,
 * factor-expansion or prediction site must be allowed to compete before a
 * blind body action can consume the same observation.  This is a transient
 * drive relation, not an action-order script: it does not choose which query
 * wins and it never makes an execution site eligible. */
export function physicalReasoningPendingControlSiteV2(site) {
    if (!site.hardEligible || site.productiveGrounding?.kind !== 'physical-branch')
        return false;
    if (site.operation !== 'compare-condition' && site.operation !== 'expand-condition'
        && site.operation !== 'predict-branch')
        return false;
    return site.drives.goal > 0 && site.drives.evidence > 0;
}
/** A goal-grounded operation is productive only when it is a real outstanding
 * effect/requirement query or has a complete production physical binding.  A
 * merely provisional R2A/factor node must not suppress the exploration needed
 * to obtain its missing evidence. */
export function productiveGoalControlSiteV2(site) {
    if (!site.hardEligible || site.drives.goal <= 0)
        return false;
    const grounding = site.productiveGrounding;
    if (!grounding || grounding.kind === 'none')
        return false;
    if (grounding.kind === 'outstanding-effect-query')
        return site.operation === 'recall-effect' && grounding.goalNodeId === site.nodeId;
    return grounding.kind === 'physical-branch' && site.operation !== 'recall-effect'
        && grounding.evidence.some(hasProductionPhysicalRepresentationV2);
}
export const G5_EXECUTION_MINIMUM_VALID_SAMPLES_V1 = 8;
export const G5_EXECUTION_MINIMUM_PROGRESS_RATE_V1 = .75;
function executionSampleProgressRateV1(prediction) {
    if (!Number.isInteger(prediction.validSampleCount) || prediction.validSampleCount <= 0
        || !Number.isInteger(prediction.progressSampleCount) || prediction.progressSampleCount < 0
        || prediction.progressSampleCount > prediction.validSampleCount)
        return 0;
    return prediction.progressSampleCount / prediction.validSampleCount;
}
function predictionMeetsExecutionQualificationV1(prediction, evidence, requireProgress) {
    void evidence;
    return prediction.validSampleCount >= G5_EXECUTION_MINIMUM_VALID_SAMPLES_V1
        && (!requireProgress
            || executionSampleProgressRateV1(prediction) >= G5_EXECUTION_MINIMUM_PROGRESS_RATE_V1);
}
/** Select only a member whose own physical rollout satisfies the G5 execution
 * qualification. Aggregate summaries may never lend support to another member. */
export function selectQualifiedPredictionMemberV1(candidates, memberResults) {
    return memberResults.filter(member => {
        const candidate = candidates.find(value => value.candidateId === member.candidateId);
        if (!candidate)
            return false;
        const evidence = member.value.currentEvidence ?? candidate.evidence;
        return evidence.r1.active && evidence.r2.active && evidence.r2a.productionEligible
            && predictionMeetsExecutionQualificationV1(member.value, evidence, true);
    }).sort((left, right) => executionSampleProgressRateV1(right.value)
        - executionSampleProgressRateV1(left.value)
        || right.value.validSampleCount - left.value.validSampleCount
        || (right.value.currentEvidence?.r2a.applicability ?? 0)
            - (left.value.currentEvidence?.r2a.applicability ?? 0)
        || left.candidateId.localeCompare(right.candidateId, 'en'))[0] ?? null;
}
const conditionMember = (condition, candidateId, singleton) => condition?.memberResults
    ? condition.memberResults.find(member => member.candidateId === candidateId)?.value ?? null
    : singleton && condition ? condition : null;
const predictionMember = (prediction, candidateId, singleton) => prediction?.memberResults
    ? prediction.memberResults.find(member => member.candidateId === candidateId)?.value ?? null
    : singleton && prediction ? prediction : null;
export const desiredFactorProgressFractionV2 = (prediction, desiredFactors) => {
    // A projected parent-relation score is already the complete conjunction
    // read from R2A.  Re-inspecting its individual factor arrays here would
    // silently weaken it back to the former "any changed factor" criterion.
    if (prediction.progressBasis === 'parent-R2A-relation-complete')
        return prediction.progressFraction;
    if (desiredFactors.length === 0)
        return prediction.progressFraction;
    if (prediction.nextStates.length === 0)
        return 0;
    return prediction.nextStates.filter(state => desiredFactors.some(id => state.knownActiveFactorIds.includes(id))).length
        / prediction.nextStates.length;
};
export function scoreDesiredFactorProgressV2(prediction, desiredFactors) {
    if (desiredFactors.length === 0)
        return prediction;
    const progressSampleCount = prediction.nextStates.filter(state => desiredFactors.some(id => state.knownActiveFactorIds.includes(id))).length;
    return { ...prediction, progressSampleCount,
        progressFraction: prediction.nextStates.length ? progressSampleCount / prediction.nextStates.length : 0 };
}
/** Score a transition rollout only by whether each simulated state restores
 * one complete, currently production-eligible parent R2A relation.  The
 * physical reasoning port performs the factor conjunction; this function is
 * deliberately ignorant of factor names and cannot turn a partial match into
 * progress. */
export function scoreProjectedParentRelationProgressV1(prediction, projected) {
    assert(projected.length === prediction.nextStates.length, 'projected-parent-relation-result-count-mismatch');
    const progressSampleCount = projected.filter(value => value.selectedRelationId !== null
        && value.productionEligible && value.applicability > 0
        && value.contradictedFactorIds.length === 0 && value.unknownFactorIds.length === 0).length;
    return { ...prediction, progressSampleCount,
        progressFraction: prediction.nextStates.length ? progressSampleCount / prediction.nextStates.length : 0,
        progressBasis: 'parent-R2A-relation-complete' };
}
/** Resolve the complete physical parent relations of one transition node.
 * Dependencies contain no semantic action ordering: they only bind the real
 * parent branches which requested this opaque transition. */
export function projectedParentRelationIdsV1(nodeId, workspace) {
    const parentIds = new Set(workspace.dependencies
        .filter(edge => edge.kind === 'opaque-factor' && edge.requiredNodeId === nodeId)
        .map(edge => edge.dependentNodeId));
    return [...new Set(workspace.nodes.flatMap(node => {
            if (!parentIds.has(node.node.nodeId))
                return [];
            if (node.node.kind === 'experienced')
                return (node.node.candidateMembers ?? [node.node.candidate])
                    .flatMap(candidate => candidate.evidence.r2a.relationIds);
            // Recursive condition expansion makes a transition branch the dependent
            // parent of another transition.  Its retained real transition events are
            // the physical candidates whose complete relations must be restored.
            if (node.node.kind === 'factor-transition')
                return (node.node.transitionMembers ?? [node.node.transition])
                    .flatMap(transition => transition.evidence.r2a.relationIds);
            return [];
        }))].sort((left, right) => left.localeCompare(right, 'en'));
}
export function factorTransitionCandidateForControlV2(transition, desiredFactors) {
    return { candidateId: transition.transitionId, goalPredicateIds: [], actionCue: transition.actionCue,
        observedChanges: [], observedBefore: {}, evidence: transition.evidence,
        unknown: [`opaque-factor-transition:${desiredFactors.join('+')}:observed-co-occurrence-not-causal-proof`] };
}
/** Existential hard gate over the original physical members. No aggregate
 * average can turn a failing event into an executable one. */
export function selectExecutablePhysicalMemberV1(candidates, condition, prediction, desiredFactors, requirePositiveProgress = true) {
    const singleton = candidates.length === 1;
    return candidates.flatMap(candidate => {
        const candidateCondition = conditionMember(condition, candidate.candidateId, singleton);
        const candidatePrediction = predictionMember(prediction, candidate.candidateId, singleton);
        if (!candidateCondition || !candidatePrediction)
            return [];
        const evidence = candidatePrediction.currentEvidence ?? candidate.evidence;
        const factorProgress = desiredFactorProgressFractionV2(candidatePrediction, desiredFactors);
        const sampleProgress = executionSampleProgressRateV1(candidatePrediction);
        const progress = desiredFactors.length === 0 ? sampleProgress : Math.min(factorProgress, sampleProgress);
        if (!candidateCondition.productionEligible || candidateCondition.applicability <= 0
            || candidateCondition.unknownFactorIds.length > 0 || candidateCondition.contradictedFactorIds.length > 0
            || !evidence.r1.active || !evidence.r2.active || !evidence.r2a.productionEligible
            || !predictionMeetsExecutionQualificationV1(candidatePrediction, evidence, requirePositiveProgress)
            || (requirePositiveProgress && progress < G5_EXECUTION_MINIMUM_PROGRESS_RATE_V1))
            return [];
        return [{ candidate, condition: candidateCondition, prediction: candidatePrediction, progress }];
    }).sort((left, right) => right.progress - left.progress
        || right.condition.applicability - left.condition.applicability
        || right.prediction.validSampleCount - left.prediction.validSampleCount
        || left.candidate.candidateId.localeCompare(right.candidate.candidateId, 'en'))[0] ?? null;
}
export function dependencyEdgeSatisfiedV2(edge, condition) {
    if (!condition || edge.factorIds.length === 0)
        return false;
    const values = condition.memberResults?.map(member => member.value) ?? [condition];
    return values.some(value => value.productionEligible
        && edge.factorIds.every(factorId => new Set(value.matchedFactorIds).has(factorId)));
}
/** Only a complete, currently active production representation can replace
 * the body's generic exploration copy of the same exact cue.  Applicability is
 * deliberately not part of this identity gate: a stable but conflicting R2A
 * relation must remain a known condition constraint, not be bypassed as blind
 * exploration. */
export function hasProductionPhysicalRepresentationV2(evidence) {
    return evidence.r1.active && evidence.r2.active && evidence.r2a.active
        && evidence.r2a.productionEligible;
}
/**
 * Return the physical substrate binding of a recalled branch, independently
 * of whether the branch currently applies to the observed factors.  R2A's
 * `active`/`supportStrength` fields are intentionally current-branch
 * readouts: the distributed memory sets them to zero when the present
 * condition is missing or conflicting.  Using those fields as the existence
 * gate for a condition query made a real, physically retained branch look as
 * if it had no substrate at all, so the controller could only explore and
 * never ask R2A which factor was missing.
 *
 * The binding therefore uses only live lower-layer support and a live R2A
 * physical footprint.  It does not grant action execution: the execution
 * selector below still requires current applicability, a production relation
 * and a qualified PredictionClone rollout.
 */
export function physicalEvidenceBindingV2(evidence) {
    const r1 = evidence.r1.active && evidence.r1.footprintTraceIds.length > 0
        ? Math.max(0, Math.min(1, evidence.r1.supportStrength)) : 0;
    const r2 = evidence.r2.active && evidence.r2.footprintTraceIds.length > 0
        ? Math.max(0, Math.min(1, evidence.r2.supportStrength)) : 0;
    const r2a = evidence.r2a.footprintTraceIds.length > 0 && evidence.r2a.relationIds.length > 0
        && evidence.r2a.evidenceGrade !== 'single-observation' ? 1 : 0;
    return Math.min(r1, r2, r2a);
}
/**
 * Derive one public intermediate state only from a real transition which was
 * recalled for an exact public-property goal.  This is not a semantic rule and
 * does not claim that the historical before-value caused the result: it says
 * only that every currently usable physical member which actually reached the
 * requested value was observed to start from the same public value.
 *
 * A disagreement between members, an unavailable current value, or a member
 * already matching its real before-value leaves the requirement unknown rather
 * than guessing a subgoal.  Numeric ordering and Minecraft property names are
 * deliberately absent from this operation.
 */
export function historicalTransitionPreconditionV1(candidates, objective, observation) {
    if (candidates.length === 0)
        return null;
    const predicates = new Map(goalPredicates(objective).map(predicate => [predicate.id, predicate]));
    const requirements = [];
    for (const candidate of candidates) {
        const memberRequirements = [];
        let alreadyAtHistoricalBefore = false;
        for (const predicateId of candidate.goalPredicateIds) {
            const predicate = predicates.get(predicateId);
            if (!predicate || predicate.comparator !== 'equals' || predicate.subject.kind !== 'public-object'
                || !predicate.observable.startsWith('properties.'))
                continue;
            const property = predicate.observable.slice('properties.'.length);
            const current = groundedPublicObservableV1(predicate, observation);
            if (current === undefined)
                continue;
            const transitions = candidate.observedChanges.filter(change => change.property === property
                && Object.is(change.after, predicate.target));
            if (transitions.some(change => Object.is(current, change.before))) {
                alreadyAtHistoricalBefore = true;
                break;
            }
            const beforeValues = [...new Map(transitions.map(change => [JSON.stringify(change.before), change.before])).values()];
            if (beforeValues.length !== 1)
                continue;
            memberRequirements.push({ predicateId, observable: predicate.observable,
                subject: predicate.subject, before: beforeValues[0] });
        }
        if (alreadyAtHistoricalBefore)
            return null;
        if (memberRequirements.length !== 1)
            return null;
        requirements.push(memberRequirements[0]);
    }
    const identities = new Set(requirements.map(value => JSON.stringify({ predicateId: value.predicateId,
        observable: value.observable, subject: value.subject, before: value.before })));
    if (identities.size !== 1)
        return null;
    const requirement = requirements[0];
    const identity = sha({ objectiveId: objective.id, predicateId: requirement.predicateId,
        subject: requirement.subject, observable: requirement.observable, before: requirement.before });
    return { version: 'GroundedGoalV1', id: `historical-transition-precondition:${identity}`,
        expression: { kind: 'predicate', predicate: { version: 'GoalPredicateV1',
                id: `historical-transition-precondition:${requirement.predicateId}:${identity}`,
                subject: structuredClone(requirement.subject), observable: requirement.observable,
                comparator: 'equals', target: requirement.before } } };
}
/** Shortest dependency distance to any top-level branch. Sorting makes the
 * answer independent of edge insertion order when a node has several parents. */
export function dependencyDepthV2(nodeId, dependencies) {
    let frontier = [nodeId];
    const visited = new Set();
    let depth = 0;
    while (frontier.length) {
        const next = [];
        for (const current of [...frontier].sort((left, right) => left.localeCompare(right, 'en'))) {
            if (visited.has(current))
                continue;
            visited.add(current);
            const parents = dependencies.filter(edge => edge.requiredNodeId === current)
                .map(edge => edge.dependentNodeId).sort((left, right) => left.localeCompare(right, 'en'));
            if (parents.length === 0)
                return depth;
            next.push(...parents);
        }
        frontier = [...new Set(next)];
        depth++;
    }
    return 0;
}
const publicValueAt = (observation, change) => {
    if (change.subject === 'self') {
        if (change.property === 'yaw')
            return observation.self.yaw;
        if (change.property === 'pitch')
            return observation.self.pitch;
        if (change.property.startsWith('displacement.'))
            return observation.self.position[Number(change.property.at(-1))];
        return observation.self.properties[change.property];
    }
    if (change.subject === 'crosshair') {
        const target = observation.objects.find(object => object.id === observation.targetId);
        if (change.property === 'visible')
            return target !== undefined;
        if (change.property === 'type')
            return target?.type ?? null;
        return undefined;
    }
    const direct = observation.objects.find(object => object.id === change.subject);
    const match = /^(.*)#(\d+)$/.exec(change.subject);
    const typed = match ? [...observation.objects].filter(object => object.type === match[1])
        .sort((left, right) => Math.hypot(...left.relativePosition) - Math.hypot(...right.relativePosition))[Number(match[2])] : null;
    const subject = direct ?? typed;
    if (!subject)
        return change.property === 'visible' ? false : undefined;
    if (change.property === 'visible')
        return true;
    if (change.property.startsWith('displacement.'))
        return subject.relativePosition[Number(change.property.at(-1))];
    return subject.properties[change.property];
};
const oppositeChange = (prediction, actualBefore, actualAfter) => {
    if (actualBefore === actualAfter)
        return false;
    if (typeof prediction.before === 'number' && typeof prediction.after === 'number'
        && typeof actualBefore === 'number' && typeof actualAfter === 'number')
        return (prediction.after - prediction.before) * (actualAfter - actualBefore) < 0;
    return actualBefore === prediction.after && actualAfter === prediction.before;
};
/** Habit punishment requires a comparable, explicitly opposite real change.
 * A goal residual that merely failed to fall is not evidence of prediction error. */
export function explicitPredictionViolationV2(prediction, before, after) {
    if (!prediction || prediction.prediction.support < .5)
        return null;
    const predicted = prediction.nextStates.flatMap(state => state.knownChanges);
    let comparable = 0, opposite = 0;
    for (const change of predicted) {
        const actualBefore = publicValueAt(before, change), actualAfter = publicValueAt(after, change);
        if (actualBefore === undefined || actualAfter === undefined || actualBefore === actualAfter)
            continue;
        comparable++;
        if (oppositeChange(change, actualBefore, actualAfter))
            opposite++;
    }
    if (comparable === 0 || opposite === 0)
        return null;
    return { matched: true, highSupport: true, deviation: opposite / comparable };
}
/** Thin coupling: one global operation-by-node competition, then one mechanical port call. */
export class PhysicalControlManagerV2 {
    reasoning;
    environment;
    config;
    options;
    field;
    workspace = new ControlWorkspaceV2();
    habit;
    #goalEvaluator = new GroundedGoalEvaluatorV1();
    #useInhibition = new Map();
    #dispatchHistory = [];
    #explorationRotation = 0;
    #groundedRotation = 0;
    #explorationWindow = null;
    #requestNumber = 0;
    #attentionDrive = 0;
    #lastSnapshot = null;
    #goalActive = false;
    #runInProgress = false;
    #queuedAttention = [];
    activity = new ActiveControlTrajectoryV1();
    #sealedContext = null;
    #queryContext = null;
    constructor(reasoning, environment, config, habit = new ControlHabitWeightsV1(), options = {}) {
        this.reasoning = reasoning;
        this.environment = environment;
        this.config = config;
        this.options = options;
        this.field = new JointTransientControlFieldV2(config);
        this.habit = habit;
        this.habit.beginNewControlEpisode();
    }
    get snapshot() {
        return this.#lastSnapshot ? structuredClone({ ...this.#lastSnapshot,
            activeTrajectory: this.activity.snapshot() }) : null;
    }
    /** Called by the body while the numerical worker is busy. No learning or
     * field winner is produced on the frame callback. */
    acceptPublicFeedback(observation) { this.activity.accept(observation); }
    interrupt(notice) {
        this.activity.deviation();
        this.#attentionDrive = 1;
        if (this.#goalActive)
            this.workspace.ingest({ kind: 'attention', notice });
        else
            this.#queuedAttention.push(structuredClone(notice));
        this.field.interrupt();
        this.environment.record('joint-control-attention', { notice, retainedDependencyGraph: this.#goalActive });
    }
    async initializeFromRealExploration() {
        return this.#run(pseudoGoal('physical-initialization'), 'initialization');
    }
    async exploreUntil(stopCondition) {
        return this.#run(pseudoGoal('open-ended-physical-exploration'), 'exploration', stopCondition);
    }
    async runGoal(goal) { return this.#run(goal, 'goal'); }
    async #run(goal, mode, stopCondition) {
        assert(!this.#runInProgress, 'physical-control-run-already-in-progress');
        this.#runInProgress = true;
        let cycles = 0, firstSatisfiedSequence = null;
        // A read-only operation that leaves the same node on the same public frame
        // cannot discover anything by being submitted again.  This is a
        // computation bound, not a cognitive priority: it ends only a repeated
        // no-progress query and leaves the root goal/evidence intact.
        let noProgressFingerprint = null, noProgressCount = 0;
        try {
            let observation = await this.environment.observe();
            this.#goalEvaluator.setGoal(goal, observation);
            this.workspace.setGoal(goal);
            this.field.setGoal(goal.id);
            this.#goalActive = true;
            this.#dispatchHistory.length = 0;
            this.#explorationRotation = 0;
            this.#groundedRotation = 0;
            this.#explorationWindow = null;
            this.habit.beginNewControlEpisode();
            for (const notice of this.#queuedAttention.splice(0))
                this.workspace.ingest({ kind: 'attention', notice });
            while (true) {
                const evaluation = this.#goalEvaluator.evaluate(observation);
                // Readiness is only a completion condition for the explicit
                // initialization mode.  Do not enqueue a worker status query on every
                // exploration/goal cycle; it is neither a permission check nor useful
                // to the field's decision.
                const status = mode === 'initialization' ? await this.environment.status() : null;
                const currentWorkspace = this.workspace.snapshot();
                if (currentWorkspace.observationSequence !== observation.sequence || currentWorkspace.goalEvaluation === null)
                    this.#ingestObservation(observation, evaluation);
                this.field.setGoalEvaluation(evaluation);
                this.environment.record('goal-difference', evaluation);
                if (mode === 'initialization' && status?.ready)
                    return this.#result('initialization-complete', cycles, null);
                if (mode === 'exploration' && stopCondition?.(observation))
                    return this.#result('exploration-stop-condition-met', cycles, null);
                const isRealGoal = mode === 'goal';
                if (isRealGoal && evaluation.status === 'satisfied')
                    firstSatisfiedSequence ??= observation.sequence;
                else
                    firstSatisfiedSequence = null;
                const budgetExhausted = this.environment.actionCount >= this.environment.actionBudget;
                // Physical readiness is telemetry, not a permission gate. Goals may
                // run while the substrate is still collecting its first events.
                let sites = isRealGoal
                    ? evaluation.status === 'satisfied' ? []
                        : this.#reasoningAndActionSites(observation, evaluation, !budgetExhausted)
                    : this.#explorationSites(observation)
                        .filter(site => !budgetExhausted || (site.operation !== 'execute' && site.operation !== 'observe-public'));
                const queryAvailable = sites.some(site => site.hardEligible && (site.operation === 'recall-effect'
                    || site.operation === 'compare-condition' || site.operation === 'predict-branch'
                    || site.operation === 'expand-condition'));
                sites = this.#mergeSites([...sites, ...this.#terminalSites(observation, evaluation, isRealGoal, firstSatisfiedSequence, budgetExhausted, queryAvailable)]);
                const decision = this.#choose(sites);
                cycles++;
                if (!decision.converged) {
                    this.environment.record('joint-control-awaiting-new-event', {
                        observationSequence: observation.sequence, epoch: this.workspace.snapshot().epoch,
                        reason: decision.reason,
                    });
                    observation = await this.environment.waitForObservationAfter(observation.sequence);
                    continue;
                }
                if (decision.operation === 'finish-verified')
                    return this.#result('goal-verified', cycles, evaluation);
                if (decision.operation === 'finish-unknown')
                    return this.#result(mode === 'initialization'
                        ? 'initialization-budget-exhausted' : mode === 'exploration' ? 'exploration-budget-exhausted'
                        : 'current-experience-and-budget-exhausted', cycles, isRealGoal ? evaluation : null);
                const dispatchEpoch = this.workspace.snapshot().epoch;
                await this.#dispatch(decision, goal, evaluation, observation);
                if (decision.operation !== 'execute' && decision.operation !== 'observe-public') {
                    const current = this.workspace.snapshot();
                    // Physical ticks are not semantic progress.  A stable public scene
                    // may produce thousands of new sequence numbers while the same
                    // read-only query is being recomputed.  Count only the public state
                    // that the query can actually observe; retain epoch/node/operation
                    // so a real world or goal change starts a fresh query opportunity.
                    const fingerprint = sha({ operation: decision.operation, nodeId: decision.nodeId,
                        epoch: current.epoch, targetId: observation.targetId,
                        objects: observation.objects, self: observation.self });
                    noProgressCount = fingerprint === noProgressFingerprint ? noProgressCount + 1 : 1;
                    noProgressFingerprint = fingerprint;
                    if (noProgressCount >= 2) {
                        this.environment.record('control-no-progress-stop', { operation: decision.operation,
                            nodeId: decision.nodeId, observationSequence: observation.sequence,
                            repeatedQueries: noProgressCount, reason: 'same-read-only-query-no-new-state' });
                        return this.#result('current-experience-and-budget-exhausted', cycles, evaluation);
                    }
                }
                else {
                    noProgressFingerprint = null;
                    noProgressCount = 0;
                }
                // A reasoning chain is evaluated against one sealed public frame. Raw
                // Minecraft ticks may continue while the worker runs, but they do not
                // silently invalidate compare -> predict -> execute before the model
                // gets a control decision.  Body results and attention are real state
                // boundaries, so both force a new public frame before the next site.
                if (decision.operation === 'execute' || decision.operation === 'observe-public')
                    this.field.crossRealityBoundary();
                if (this.#sealedContext && !this.activity.current(this.#sealedContext)
                    && this.workspace.snapshot().epoch === dispatchEpoch)
                    this.workspace.invalidateFeedback();
                if (decision.operation === 'execute' || decision.operation === 'observe-public'
                    || this.workspace.snapshot().epoch !== dispatchEpoch)
                    observation = await this.environment.observe();
                this.#attentionDrive *= .5;
                if (this.#attentionDrive < .01) {
                    this.#attentionDrive = 0;
                    this.field.clearInterrupt();
                }
            }
        }
        finally {
            this.#goalActive = false;
            this.#runInProgress = false;
        }
    }
    #ingestObservation(observation, evaluation) {
        this.activity.accept(observation);
        this.#sealedContext = this.activity.capture();
        const snapshot = this.workspace.snapshot();
        if (snapshot.observationSequence !== null && observation.sequence <= snapshot.observationSequence)
            return;
        const offers = this.environment.listActionOffers(observation);
        const result = this.workspace.ingest({ kind: 'observation', observation, offers, goalEvaluation: evaluation });
        assert(result.accepted, `control-observation-rejected:${result.reason}`);
        for (const offer of this.#explorationOffers(offers).slice(0, Math.max(1, this.config.branchCapacity - 1)))
            this.workspace.registerExploration(offer);
    }
    #terminalSites(observation, evaluation, isRealGoal, firstSatisfiedSequence, budgetExhausted, queryAvailable) {
        const root = this.workspace.snapshot().rootNodeId;
        const sites = [];
        if (isRealGoal && evaluation.status === 'satisfied' && firstSatisfiedSequence !== null) {
            const verified = observation.sequence - firstSatisfiedSequence >= this.config.goalVerificationTicks;
            if (verified)
                sites.push(this.#site('finish-verified', root, true, { goal: 1, evidence: 1, attention: this.#attentionDrive }));
            else if (!budgetExhausted) {
                const offer = this.environment.listActionOffers(observation)
                    .find(value => value.action.kind === 'observe' && value.action.parameters.ticks === 5);
                if (offer) {
                    const nodeId = this.workspace.registerExploration(offer);
                    sites.push(this.#site('observe-public', nodeId, true, { goal: 1, unknown: 1, attention: this.#attentionDrive, novelty: 1 }));
                }
            }
        }
        // An achieved goal still needs later public verification. Exhausting the
        // motor budget does not exhaust observation; wait for fresh frames instead
        // of racing an unknown finish against a result that is already present.
        if (budgetExhausted && !(isRealGoal && evaluation.status === 'satisfied')) {
            if (!queryAvailable)
                sites.push(this.#site('finish-unknown', root, true, { goal: evaluation.residual, unknown: 1, evidence: 1 }));
        }
        return sites;
    }
    #mergeSites(sites) {
        const merged = new Map();
        for (const site of sites) {
            const prior = merged.get(site.siteId);
            if (!prior) {
                merged.set(site.siteId, site);
                continue;
            }
            const drives = {
                goal: Math.max(site.drives.goal, prior.drives.goal),
                evidence: Math.max(site.drives.evidence, prior.drives.evidence),
                condition: Math.max(site.drives.condition, prior.drives.condition),
                rollout: Math.max(site.drives.rollout, prior.drives.rollout),
                unknown: Math.max(site.drives.unknown, prior.drives.unknown),
                attention: Math.max(site.drives.attention, prior.drives.attention),
                novelty: Math.max(site.drives.novelty, prior.drives.novelty),
                habit: Math.max(site.drives.habit, prior.drives.habit),
            };
            const productiveGrounding = site.productiveGrounding?.kind !== 'none'
                ? site.productiveGrounding : prior.productiveGrounding;
            merged.set(site.siteId, { ...site, hardEligible: site.hardEligible || prior.hardEligible,
                ...(productiveGrounding ? { productiveGrounding } : {}), drives });
        }
        return [...merged.values()];
    }
    #reasoningAndActionSites(observation, evaluation, allowBodyOperations) {
        this.#synchronizePublicRequirements(observation);
        this.#synchronizeHistoricalTransitionRequirements(observation);
        const snapshot = this.workspace.snapshot(), root = snapshot.rootNodeId;
        const rootSites = [];
        if (!this.workspace.hasCompleted('recall-effect', root, { currentEpoch: true }))
            rootSites.push(this.#site('recall-effect', root, true, { goal: evaluation.residual,
                unknown: snapshot.nodes.some(value => value.node.kind === 'experienced') ? .25 : 1,
                attention: this.#attentionDrive, evidence: .2 }, { kind: 'outstanding-effect-query', goalNodeId: root }));
        const experienced = snapshot.nodes.filter(value => value.node.kind === 'experienced'
            || value.node.kind === 'factor-transition');
        const publicRequirements = snapshot.nodes.filter(value => value.node.kind === 'public-requirement');
        // A production-qualified physical branch already represents this exact
        // cue, so a second exploration copy would bypass its condition and rollout
        // gates.  R1/R2-only or provisional R2A history is not production evidence:
        // it may guide a query, but it must not erase the body's still-legal chance
        // to explore the cue and obtain the missing real condition evidence.
        const physicallyRepresentedCues = new Set(experienced.filter(value => {
            return this.#candidates(value, snapshot).some(candidate => hasProductionPhysicalRepresentationV2(candidate.evidence));
        }).map(value => this.#nodeCueIdentity(value)));
        const exploration = snapshot.nodes.filter(value => value.node.kind === 'exploration'
            && !physicallyRepresentedCues.has(this.#nodeCueIdentity(value)));
        const all = [...publicRequirements, ...experienced, ...exploration];
        const active = all.map(node => ({ node, sites: this.#sitesForNode(node, snapshot, observation, evaluation)
                .filter(site => allowBodyOperations || (site.operation !== 'execute' && site.operation !== 'observe-public')) }))
            .filter(value => value.sites.some(site => site.hardEligible
            && Object.values(site.drives).some(drive => drive > 0)));
        const groundedWorkAvailable = rootSites.some(productiveGoalControlSiteV2)
            || active.some(value => value.node.node.kind !== 'exploration'
                && value.sites.some(productiveGoalControlSiteV2));
        const physicalReasoningAvailable = active.some(value => value.node.node.kind !== 'exploration'
            && value.sites.some(physicalReasoningPendingControlSiteV2));
        const modulated = active.map(value => value.node.node.kind === 'exploration'
            ? { ...value, sites: modulateBlindExplorationInputsV2(value.sites, groundedWorkAvailable || physicalReasoningAvailable) }
            : value);
        // Keep one transient slot for an observation/verification event that may be
        // admitted later in this same global competition.  The remaining nodes are
        // still selected only by fair rotation; this reserve does not score or pick
        // an operation, branch, or action.
        const capacity = Math.max(1, this.config.branchCapacity - (rootSites.length ? 1 : 0) - 1);
        const window = fairGroundedControlWindowV2(modulated, capacity, this.#groundedRotation, value => this.#nodeCueIdentity(value.node), value => value.node.node.kind !== 'exploration'
            && value.sites.some(site => productiveGoalControlSiteV2(site)
                || physicalReasoningPendingControlSiteV2(site)));
        this.#groundedRotation = window.nextRotation;
        const sites = [...rootSites];
        for (const value of window.selected)
            sites.push(...value.sites);
        return sites;
    }
    #sitesForNode(node, workspace, observation, evaluation) {
        if (node.node.kind === 'exploration') {
            const current = this.#rebindOffer(node.node.offer, observation);
            if (!current)
                return [];
            return [this.#site(current.action.kind === 'observe' || current.action.kind === 'wait'
                    ? 'observe-public' : 'execute', node.node.nodeId, true, { unknown: 1, novelty: this.#novelty(current), attention: this.#attentionDrive })];
        }
        if (node.node.kind === 'public-requirement') {
            const requirementEvaluation = this.#evaluateGoal(node.node.goal, observation);
            if (requirementEvaluation.status === 'satisfied')
                return [];
            if (this.workspace.hasCompleted('recall-effect', node.node.nodeId, { currentEpoch: true }))
                return [];
            return [this.#site('recall-effect', node.node.nodeId, true, {
                    goal: requirementEvaluation.residual, evidence: .2, unknown: 1, attention: this.#attentionDrive,
                }, { kind: 'outstanding-effect-query', goalNodeId: node.node.nodeId })];
        }
        const incomingDependencies = workspace.dependencies.filter(edge => edge.requiredNodeId === node.node.nodeId);
        // A requirement-changing branch stops consuming reasoning capacity once
        // every parent which needs it is already true in current reality. Shared
        // branches remain active while even one parent still needs them.
        const dependencyFulfilled = incomingDependencies.length > 0
            && incomingDependencies.every(edge => edge.kind === 'opaque-factor'
                ? dependencyEdgeSatisfiedV2(edge, this.workspace.currentCondition(edge.dependentNodeId))
                : edge.kind === 'public-requirement-candidate'
                    ? this.#publicRequirementSatisfied(edge.dependentNodeId, workspace, observation) : false);
        if (dependencyFulfilled)
            return [];
        const candidates = this.#candidates(node, workspace);
        const candidate = candidates[0];
        const condition = this.workspace.currentCondition(node.node.nodeId);
        const prediction = this.workspace.currentPrediction(node.node.nodeId);
        const continuations = this.workspace.currentContinuationPredictions(node.node.nodeId);
        const currentEvidence = candidates.map(member => predictionMember(prediction, member.candidateId, candidates.length === 1)?.currentEvidence ?? member.evidence);
        const binding = Math.max(...currentEvidence.map(evidence => physicalEvidenceBindingV2(evidence)));
        const physicalGrounding = {
            kind: 'physical-branch', evidence: currentEvidence,
        };
        const factors = this.#conditionFactors(condition);
        const desiredFactors = this.#desiredFactors(node.node.nodeId, workspace);
        const depthGoal = this.#nodeGoalDrive(node.node.nodeId, workspace, evaluation.residual);
        const requirement = candidate.actionCue.kind === 'passive' ? null
            : this.environment.describeActionRequirement(candidate.actionCue, observation);
        if (requirement && !requirement.satisfied)
            this.environment.record('control-public-action-requirement', {
                nodeId: node.node.nodeId, actionKind: candidate.actionCue.kind,
                observationSequence: observation.sequence, missing: requirement.missing,
            });
        const unknown = Math.max(condition
            ? clamp01(factors.length / Math.max(1, factors.length + condition.matchedFactorIds.length)) : .65, requirement && !requirement.satisfied ? 1 : 0);
        const sites = [];
        if (!condition)
            sites.push(this.#site('compare-condition', node.node.nodeId, binding > 0, { goal: depthGoal, evidence: binding, unknown, attention: this.#attentionDrive }, physicalGrounding));
        // A zero applicability readout is a physical result to investigate, not a
        // reason to hide the read-only rollout.  If the retained R1/R2/R2A
        // footprint is present, the predictor must be allowed to test the current
        // condition and report reached/unknown honestly.  Action execution still
        // requires the separate production qualification below.
        if (!prediction && condition !== null && binding > 0)
            sites.push(this.#site('predict-branch', node.node.nodeId, true, { goal: depthGoal, evidence: binding, condition: condition.applicability,
                unknown, attention: this.#attentionDrive }, physicalGrounding));
        if (condition && factors.length > 0
            && !this.workspace.hasCompleted('expand-condition', node.node.nodeId, { currentEpoch: true }))
            sites.push(this.#site('expand-condition', node.node.nodeId, binding > 0, { goal: depthGoal, evidence: binding, condition: condition.applicability,
                unknown: 1, attention: this.#attentionDrive }, physicalGrounding));
        const winner = selectExecutablePhysicalMemberV1(candidates, condition, prediction, desiredFactors, this.options.requirePredictionProgress !== false);
        const continuationSupport = winner && continuations ? continuations
            .filter(item => item.candidateId === winner.candidate.candidateId)
            .reduce((maximum, item) => Math.max(maximum, item.value.evidenceGrade === 'predictive-stable' || item.value.evidenceGrade === 'causal-hypothesis'
            || item.value.evidenceGrade === 'intervention-supported' ? item.value.support : 0), 0) : 0;
        const offer = winner ? this.#offerForCandidate(node, winner.candidate, workspace, observation) : null;
        // Once a requirement-changing action has happened, reality must first re-test
        // the dependent branch. This is freshness of a graph edge, not a parent-stack
        // resume rule and not an action-order preference.
        const dependencyAwaitingRealityCheck = node.lastActionResult?.executed === true
            && workspace.dependencies.some(edge => edge.kind === 'opaque-factor' && edge.requiredNodeId === node.node.nodeId
                && this.workspace.currentCondition(edge.dependentNodeId) === null);
        if (offer && winner
            && requirement?.satisfied !== false && !dependencyAwaitingRealityCheck)
            sites.push(this.#site('execute', node.node.nodeId, true, { goal: depthGoal, evidence: binding, condition: winner.condition.applicability,
                rollout: Math.max(winner.progress, continuationSupport, winner.prediction.shortChain ? winner.prediction.shortChain.progressSampleCount
                    / winner.prediction.shortChain.totalSampleCount : 0), unknown: 0, attention: this.#attentionDrive }, physicalGrounding));
        return sites;
    }
    #explorationSites(observation) {
        const offers = this.environment.listActionOffers(observation);
        return this.#explorationOffers(offers).map(offer => {
            const nodeId = this.workspace.registerExploration(offer), observe = offer.action.kind === 'observe' || offer.action.kind === 'wait';
            return this.#site(observe ? 'observe-public' : 'execute', nodeId, true, { unknown: 1, novelty: this.#novelty(offer), attention: this.#attentionDrive });
        });
    }
    /** Keep a fair offer window stable while the public reality is unchanged.
     * Offers are rebound to the newest frame before execution; only admission is
     * cached so the field can accumulate activation instead of rotating away. */
    #explorationOffers(offers) {
        const capacity = this.config.branchCapacity;
        const identity = (offer) => this.#explorationIdentity(offer);
        if (this.#explorationWindow === null) {
            const window = fairEvidenceWindowV2(offers, capacity, this.#explorationRotation, identity);
            this.#explorationRotation = window.nextRotation;
            this.#explorationWindow = window.selected.map(identity);
        }
        const current = new Map(offers.map(offer => [identity(offer), offer]));
        const selected = this.#explorationWindow
            .map(key => current.get(key)).filter((offer) => offer !== undefined);
        if (selected.length < Math.min(capacity, offers.length)) {
            const known = new Set(this.#explorationWindow);
            const remaining = offers.filter(offer => !known.has(identity(offer)));
            const fill = fairEvidenceWindowV2(remaining, capacity - selected.length, this.#explorationRotation, identity);
            this.#explorationRotation = fill.nextRotation;
            this.#explorationWindow.push(...fill.selected.map(identity));
            selected.push(...fill.selected);
        }
        return selected.slice(0, capacity);
    }
    #site(operation, nodeId, hardEligible, drives, productiveGrounding = { kind: 'none' }) {
        const base = { ...zeroDrives(), ...drives };
        return { siteId: `${operation}:${nodeId}`, operation, nodeId, hardEligible,
            productiveGrounding, drives: { ...base, habit: this.#habitDrive(operation, nodeId) } };
    }
    #choose(sites) {
        this.field.replaceSites(sites);
        const decision = this.field.decide();
        this.#lastSnapshot = { version: 'PhysicalControlSnapshotV2', field: this.field.snapshot(),
            workspace: this.workspace.snapshot(), habits: this.habit.exportCheckpoint(), lastDecision: decision,
            attentionDrive: this.#attentionDrive, activeTrajectory: this.activity.snapshot(),
            recentDispatches: structuredClone(this.#dispatchHistory) };
        this.environment.record('joint-control-decision', this.#lastSnapshot);
        return decision;
    }
    async #dispatch(decision, goal, evaluation, observation) {
        assert(decision.converged && decision.nodeId && decision.operation !== 'unknown', 'cannot-dispatch-unknown-control-site');
        const operation = decision.operation, nodeId = decision.nodeId;
        const dispatchSequence = this.#recordDispatch(operation, nodeId);
        if (operation === 'finish-verified' || operation === 'finish-unknown')
            return;
        const workspace = this.workspace.snapshot();
        const node = workspace.nodes.find(value => value.node.nodeId === nodeId);
        assert(node, 'joint-control-selected-node-not-found');
        const requestId = `control-request-${++this.#requestNumber}`;
        const latest = await this.environment.observe();
        this.activity.accept(latest);
        if (this.#sealedContext && !this.activity.current(this.#sealedContext)) {
            this.workspace.invalidateFeedback();
            this.environment.record('control-stale-feedback', { requestId, operation, nodeId,
                baseSequence: observation.sequence, latestSequence: latest.sequence, reason: 'public-state-changed' });
            return;
        }
        if (operation === 'execute' || operation === 'observe-public') {
            const physicalMembers = node.node.kind === 'exploration' ? [] : this.#candidates(node, workspace);
            const winningMember = node.node.kind === 'exploration' ? null : selectExecutablePhysicalMemberV1(physicalMembers, node.condition?.fresh ? node.condition.value : null, node.prediction?.fresh ? node.prediction.value : null, this.#desiredFactors(nodeId, workspace), this.options.requirePredictionProgress !== false);
            const offer = node.node.kind === 'exploration' ? this.#rebindOffer(node.node.offer, observation)
                : winningMember ? this.#offerForCandidate(node, winningMember.candidate, workspace, observation) : null;
            if (!offer) {
                this.environment.record('control-action-reality-refusal', { nodeId, reason: 'offer-stale',
                    observationSequence: observation.sequence });
                return;
            }
            const request = this.workspace.beginRequest({ requestId, channel: 'body', operation, nodeId,
                baseSequence: observation.sequence });
            const beforeResidual = evaluation.residual;
            const selectedPrediction = winningMember?.prediction ?? null;
            const result = await this.environment.executeOffer(offer, this.#actionObservationScope(goal, workspace), selectedPrediction?.binding);
            this.activity.accept(result.observation);
            if (result.executed && result.eventId)
                this.activity.action(result.eventId);
            const accepted = this.workspace.ingest({ kind: 'action-completed', requestId: request.requestId, nodeId,
                result: { executed: result.executed, observation: result.observation, result } });
            assert(accepted.accepted, `control-action-result-rejected:${accepted.reason}`);
            this.environment.record('control-action-result', { offer, result, workspace: accepted });
            this.#markUsed(offer);
            if (result.executed && result.eventId) {
                const afterEvaluation = this.#goalEvaluator.evaluate(result.observation);
                const reduction = clamp01(beforeResidual - afterEvaluation.residual);
                if (this.environment.recordTrustedRuntimeGoalMeasurement)
                    await this.environment.recordTrustedRuntimeGoalMeasurement(result.eventId, result.observation.activeSeconds, beforeResidual, afterEvaluation.residual);
                const outcome = { source: 'trusted-real-executed-action', dispatchSequence,
                    residualReduction: reduction,
                    predictionViolation: explicitPredictionViolationV2(selectedPrediction, observation, result.observation) };
                if (this.environment.commitHabitOutcome)
                    await this.environment.commitHabitOutcome(outcome);
                else
                    this.habit.applyTrustedRealActionOutcome(outcome);
            }
            return;
        }
        const request = this.workspace.beginRequest({ requestId, channel: 'reasoning', operation, nodeId,
            baseSequence: observation.sequence, factorIds: operation === 'expand-condition'
                ? this.#missingFactors(nodeId) : undefined });
        this.#queryContext = this.activity.begin(requestId, nodeId);
        try {
            if (operation === 'recall-effect') {
                const queryGoal = node.node.kind === 'root' || node.node.kind === 'public-requirement'
                    ? node.node.goal : goal;
                const queryEvaluation = node.node.kind === 'public-requirement'
                    ? this.#evaluateGoal(queryGoal, observation) : evaluation;
                const [atomicCandidates, continuousPatterns] = await Promise.all([
                    this.reasoning.recallAtomicEffect(queryGoal, queryEvaluation, observation),
                    this.reasoning.recallContinuousPattern(queryGoal, queryEvaluation, observation),
                ]);
                const result = { version: 'PhysicalRecallBundleV2', atomicCandidates, continuousPatterns };
                await this.#acceptOperation({ kind: 'operation-completed', requestId, epoch: request.epoch, operation,
                    nodeId, baseSequence: request.baseSequence, result });
            }
            else if (operation === 'compare-condition') {
                const result = await this.#compareCandidateGroup(this.#candidates(node, workspace), observation);
                await this.#acceptOperation({ kind: 'operation-completed', requestId, epoch: request.epoch, operation,
                    nodeId, baseSequence: request.baseSequence, result });
            }
            else if (operation === 'predict-branch') {
                const predictionGoal = this.#objectiveGoal(node, workspace, goal);
                const predictionEvaluation = predictionGoal.id === goal.id
                    ? evaluation : this.#evaluateGoal(predictionGoal, observation);
                const parentRelationIds = node.node.kind === 'factor-transition'
                    ? projectedParentRelationIdsV1(nodeId, workspace) : null;
                const result = await this.#predictCandidateGroup(this.#candidates(node, workspace), node.continuousPatterns, observation, predictionGoal, predictionEvaluation, parentRelationIds);
                await this.#attachDependencyRollout(result, nodeId, workspace, observation, goal, evaluation);
                await this.#acceptOperation({ kind: 'operation-completed', requestId, epoch: request.epoch, operation,
                    nodeId, baseSequence: request.baseSequence, result });
            }
            else if (operation === 'expand-condition') {
                const result = await this.reasoning.recallFactorTransition(request.factorIds, observation);
                await this.#acceptOperation({ kind: 'operation-completed', requestId, epoch: request.epoch, operation,
                    nodeId, baseSequence: request.baseSequence, result });
            }
        }
        catch (error) {
            this.activity.end(null);
            this.workspace.ingest({ kind: 'operation-failed', requestId, epoch: request.epoch, operation,
                nodeId, baseSequence: request.baseSequence, error });
            throw error;
        }
    }
    async #acceptOperation(event) {
        const prediction = event.kind === 'operation-completed' && event.operation === 'predict-branch'
            ? event.result.atomic : null;
        const version = prediction?.binding?.mediumVersion ?? null;
        const port = this.reasoning;
        const staleMedium = version !== null && port.physicalVersion !== undefined
            && version !== await port.physicalVersion();
        if ((this.#queryContext && !this.activity.current(this.#queryContext)) || staleMedium)
            this.workspace.invalidateFeedback();
        this.activity.end(version);
        this.#queryContext = null;
        const accepted = this.workspace.ingest(event);
        const auditEvent = event.kind === 'operation-completed' && event.operation === 'predict-branch'
            ? { ...event, result: { ...event.result,
                    atomic: compactBranchPredictionForControlAuditV2(event.result.atomic),
                    continuations: event.result.continuations.map(item => ({ ...item,
                        value: this.#compactContinuationForAudit(item.value) })) } }
            : event;
        this.environment.record('control-operation-result', { event: auditEvent, accepted });
        if (!accepted.accepted && !accepted.reason.startsWith('stale-operation'))
            throw new Error(`control-operation-result-rejected:${accepted.reason}`);
    }
    async #attachDependencyRollout(result, nodeId, workspace, observation, goal, evaluation) {
        const port = this.reasoning;
        if (!port.predictShortChain)
            return; // V2 synthetic ports have no future-state capability.
        const node = workspace.nodes.find(value => value.node.nodeId === nodeId);
        const members = this.#candidates(node, workspace);
        const selected = result.atomic.memberResults
            ? selectQualifiedPredictionMemberV1(members, result.atomic.memberResults)
            : result.atomic.validSampleCount >= 8 ? { candidateId: members[0].candidateId, value: result.atomic } : null;
        if (!selected)
            return;
        for (const path of physicalDependencyPathsV1(nodeId, workspace)) {
            const candidates = path.map((id, index) => {
                const pathNode = workspace.nodes.find(value => value.node.nodeId === id);
                const group = this.#candidates(pathNode, workspace);
                // A single physical member nominates a path. It lends no qualification
                // to the other members; every step gets its own actual field rollout.
                return index === 0 ? group.find(value => value.candidateId === selected.candidateId) : group[0];
            });
            const chain = await port.predictShortChain(candidates, observation, goal, evaluation);
            this.environment.record('control-physical-short-chain', { nodeId, dependencyPath: path, chain });
            // This is additional rollout input, never permission to run a suffix.
            // The first action still needs its own current condition and prediction.
            if (!selected.value.shortChain || chain.progressSampleCount > selected.value.shortChain.progressSampleCount) {
                Object.assign(selected.value, { shortChain: chain });
                if (result.atomic.winningCandidateId === selected.candidateId || members.length === 1)
                    Object.assign(result.atomic, { shortChain: chain });
            }
        }
    }
    #candidate(node, workspace) {
        return this.#candidates(node, workspace)[0];
    }
    #candidates(node, workspace) {
        if (node.node.kind === 'experienced')
            return node.node.candidateMembers ?? [node.node.candidate];
        assert(node.node.kind === 'factor-transition', 'control-node-has-no-physical-candidate');
        const desired = this.#desiredFactors(node.node.nodeId, workspace);
        return (node.node.transitionMembers ?? [node.node.transition]).map(transition => factorTransitionCandidateForControlV2(transition, desired));
    }
    async #compareCandidateGroup(candidates, observation) {
        assert(candidates.length > 0, 'cannot-compare-empty-physical-group');
        const memberResults = [];
        for (const candidate of candidates) {
            const relationIds = [...new Set(candidate.evidence.r2a.relationIds)]
                .sort((left, right) => left.localeCompare(right, 'en'));
            const comparisons = await Promise.all(relationIds.map(relationId => this.reasoning.compareCurrentFactors(relationId, observation)));
            const result = comparisons.sort((left, right) => Number(right.productionEligible) - Number(left.productionEligible)
                || right.applicability - left.applicability
                || right.matchedFactorIds.length - left.matchedFactorIds.length)[0]
                ?? { matchedFactorIds: [], contradictedFactorIds: [], unknownFactorIds: [],
                    applicability: 0, productionEligible: false };
            const { memberResults: _nested, selectedCandidateId: _selected, ...value } = result;
            memberResults.push({ candidateId: candidate.candidateId, value });
        }
        memberResults.sort((left, right) => left.candidateId.localeCompare(right.candidateId, 'en'));
        const selected = [...memberResults].sort((left, right) => Number(right.value.productionEligible) - Number(left.value.productionEligible)
            || right.value.applicability - left.value.applicability
            || right.value.matchedFactorIds.length - left.value.matchedFactorIds.length
            || left.candidateId.localeCompare(right.candidateId, 'en'))[0];
        if (candidates.length === 1)
            return selected.value;
        return { ...selected.value, memberResults, selectedCandidateId: selected.candidateId };
    }
    async #predictCandidateGroup(candidates, continuousPatterns, observation, goal, evaluation, parentRelationIds) {
        assert(candidates.length > 0, 'cannot-predict-empty-physical-group');
        const memberResults = [];
        for (const candidate of candidates) {
            const raw = await this.reasoning.predictCandidate(candidate, observation, goal, evaluation);
            const result = parentRelationIds === null ? raw
                : await this.#scoreProjectedParentRelationProgress(candidate, raw, parentRelationIds, observation);
            const { memberResults: _nested, winningCandidateId: _winner, ...value } = result;
            memberResults.push({ candidateId: candidate.candidateId, value });
        }
        memberResults.sort((left, right) => left.candidateId.localeCompare(right.candidateId, 'en'));
        const selected = [...memberResults].sort((left, right) => right.value.progressFraction - left.value.progressFraction
            || right.value.validSampleCount - left.value.validSampleCount
            || (right.value.currentEvidence?.r2a.applicability ?? 0) - (left.value.currentEvidence?.r2a.applicability ?? 0)
            || left.candidateId.localeCompare(right.candidateId, 'en'))[0];
        const physicallyProgressing = selectQualifiedPredictionMemberV1(candidates, memberResults);
        const atomic = candidates.length === 1 ? selected.value
            : { ...selected.value, memberResults, winningCandidateId: physicallyProgressing?.candidateId ?? null };
        const continuations = [];
        for (const candidate of candidates)
            for (const binding of continuousPatterns) {
                const exactIdentity = cueIdentity(candidate.actionCue);
                if (binding.pattern.nextActionCueIdentities
                    && !binding.pattern.nextActionCueIdentities.includes(exactIdentity))
                    continue;
                continuations.push({ candidateId: candidate.candidateId, patternId: binding.pattern.patternId,
                    sharedRelationIds: [...binding.sharedRelationIds],
                    value: await this.reasoning.predictContinuation(binding.pattern.patternId, candidate.actionCue, observation) });
            }
        return { version: 'ControlBranchPredictionResultV2', atomic, continuations };
    }
    async #scoreProjectedParentRelationProgress(candidate, prediction, parentRelationIds, observation) {
        const failClosed = (reason) => ({ ...prediction,
            progressSampleCount: 0, progressFraction: 0,
            progressBasis: 'parent-R2A-relation-complete',
            unknown: [...new Set([...prediction.unknown, reason])].sort((left, right) => left.localeCompare(right, 'en')) });
        if (parentRelationIds.length === 0)
            return failClosed('parent-R2A-relation-unavailable');
        if (prediction.nextStates.length === 0)
            return failClosed('parent-R2A-projection-unavailable');
        const evidence = prediction.currentEvidence ?? candidate.evidence;
        const projected = await this.reasoning.compareProjectedParentRelations(parentRelationIds, observation, prediction.nextStates, { r1Active: evidence.r1.active, r2Active: evidence.r2.active });
        if (projected.length !== prediction.nextStates.length)
            return failClosed('parent-R2A-projection-incomplete');
        return scoreProjectedParentRelationProgressV1(prediction, projected);
    }
    #compactContinuationForAudit(value) {
        return structuredClone(value);
    }
    /**
     * This only widens the real observation window. It neither creates a
     * subgoal nor scores an action: every ID already occurs in the grounded root
     * goal or one of its retained public requirement dependencies.
     */
    #actionObservationScope(rootGoal, workspace) {
        const goals = [rootGoal, ...workspace.nodes.flatMap(node => node.node.kind === 'root'
                || node.node.kind === 'public-requirement' ? [node.node.goal] : [])];
        const referencedPublicObjectIds = [...new Set(goals.flatMap(goal => goalPredicates(goal))
                .flatMap(predicate => predicate.subject.kind === 'public-object' ? [predicate.subject.id] : []))];
        return { version: 'ActionObservationScopeV1', referencedPublicObjectIds };
    }
    #desiredFactors(nodeId, workspace = this.workspace.snapshot()) {
        return [...new Set(workspace.dependencies.filter(edge => edge.requiredNodeId === nodeId).flatMap(edge => edge.factorIds))].sort();
    }
    #missingFactors(nodeId) {
        const condition = this.workspace.currentCondition(nodeId);
        return this.#conditionFactors(condition);
    }
    #conditionFactors(condition) {
        if (!condition)
            return [];
        const values = condition.memberResults?.map(member => member.value) ?? [condition];
        return [...new Set(values.flatMap(value => [...value.unknownFactorIds, ...value.contradictedFactorIds]))].sort();
    }
    #offerForCandidate(node, candidate, workspace, observation) {
        void node;
        void workspace;
        // The object whose state should change is not necessarily the object the
        // body must act on (a control can change a separate indicator or door).
        // Bind only to the body's exact current offer.  A cue with several current
        // targets is ambiguous and must not be guessed from the effect goal.
        const matches = this.environment.listActionOffers(observation)
            .filter(value => cueIdentity(value.cue) === cueIdentity(candidate.actionCue));
        return matches.length === 1 ? matches[0] : null;
    }
    #rebindOffer(offer, observation) {
        return this.environment.listActionOffers(observation).find(value => cueIdentity(value.cue) === cueIdentity(offer.cue)
            && (offer.action.targetId === undefined || value.action.targetId === offer.action.targetId)) ?? null;
    }
    #nodeCueIdentity(node) {
        if (node.node.kind === 'experienced')
            return cueIdentity(node.node.candidate.actionCue);
        if (node.node.kind === 'factor-transition')
            return cueIdentity(node.node.transition.actionCue);
        if (node.node.kind === 'exploration')
            return cueIdentity(node.node.offer.cue);
        return node.node.nodeId;
    }
    #synchronizePublicRequirements(observation) {
        const snapshot = this.workspace.snapshot();
        for (const node of snapshot.nodes) {
            if (node.node.kind !== 'experienced' && node.node.kind !== 'factor-transition')
                continue;
            const candidate = this.#candidate(node, snapshot);
            if (candidate.actionCue.kind === 'passive')
                continue;
            const requirement = this.environment.describeActionRequirement(candidate.actionCue, observation);
            if (requirement.satisfied || requirement.goal === null)
                continue;
            const requirementNodeId = this.workspace.registerPublicRequirement(node.node.nodeId, requirement.goal);
            this.environment.record('control-public-requirement-goal', {
                dependentNodeId: node.node.nodeId, requirementNodeId, observationSequence: observation.sequence,
                goal: requirement.goal, missing: requirement.missing,
            });
        }
    }
    #synchronizeHistoricalTransitionRequirements(observation) {
        const snapshot = this.workspace.snapshot();
        for (const node of snapshot.nodes) {
            if (node.node.kind !== 'experienced' || !node.prediction?.fresh)
                continue;
            const candidates = this.#candidates(node, snapshot);
            const memberPredictions = candidates.map(candidate => ({ candidate,
                prediction: predictionMember(node.prediction.value, candidate.candidateId, candidates.length === 1) }));
            // A genuinely progressing physical member is already a direct plan.  A
            // prerequisite is introduced only when real random readout reached a
            // known transition but none of the members advanced the current goal.
            if (memberPredictions.some(value => value.prediction && value.prediction.validSampleCount > 0
                && value.prediction.progressFraction > 0))
                continue;
            const stalled = memberPredictions.filter((value) => value.prediction !== null
                && value.prediction.validSampleCount > 0
                && value.prediction.readoutDiagnostics?.goalRelevantKernelVisited === true
                && value.prediction.readoutDiagnostics.roleBindingStatus === 'matched')
                .map(value => value.candidate);
            if (stalled.length === 0)
                continue;
            const root = snapshot.nodes.find(value => value.node.nodeId === snapshot.rootNodeId)?.node;
            assert(root?.kind === 'root', 'control-workspace-root-goal-unavailable');
            const objective = this.#objectiveGoal(node, snapshot, root.goal);
            const requirement = historicalTransitionPreconditionV1(stalled, objective, observation);
            if (!requirement)
                continue;
            const requirementNodeId = `public-requirement:${sha(requirement)}`;
            const alreadyRegistered = snapshot.dependencies.some(edge => edge.dependentNodeId === node.node.nodeId
                && edge.requiredNodeId === requirementNodeId && edge.kind === 'historical-transition-precondition');
            this.workspace.registerPublicRequirement(node.node.nodeId, requirement, 'historical-transition-precondition');
            if (!alreadyRegistered)
                this.environment.record('control-historical-transition-requirement', {
                    dependentNodeId: node.node.nodeId, requirementNodeId,
                    observationSequence: observation.sequence, goal: requirement,
                    candidateIds: stalled.map(candidate => candidate.candidateId).sort(),
                    evidenceBoundary: 'shared-real-before-value-not-causal-proof',
                });
        }
    }
    #evaluateGoal(goal, observation) {
        const evaluator = new GroundedGoalEvaluatorV1();
        evaluator.setGoal(goal, observation);
        return evaluator.evaluate(observation);
    }
    #publicRequirementSatisfied(nodeId, workspace, observation) {
        const node = workspace.nodes.find(value => value.node.nodeId === nodeId)?.node;
        return node?.kind === 'public-requirement'
            && this.#evaluateGoal(node.goal, observation).status === 'satisfied';
    }
    #objectiveGoal(node, workspace, fallback) {
        if (node.node.kind !== 'experienced')
            return fallback;
        const objectiveNodeId = node.node.objectiveNodeId;
        const objective = workspace.nodes.find(value => value.node.nodeId === objectiveNodeId)?.node;
        return objective?.kind === 'root' || objective?.kind === 'public-requirement' ? objective.goal : fallback;
    }
    #nodeGoalDrive(nodeId, workspace, rootResidual) {
        const depth = dependencyDepthV2(nodeId, workspace.dependencies);
        return clamp01(rootResidual * Math.pow(.8, depth));
    }
    #explorationIdentity(offer) {
        return `${cueIdentity(offer.cue)}:${offer.action.targetId ?? ''}`;
    }
    #novelty(offer) {
        return 1 / (1 + (this.#useInhibition.get(this.#explorationIdentity(offer)) ?? 0));
    }
    #markUsed(offer) {
        for (const [key, value] of this.#useInhibition) {
            const next = value * .85;
            if (next < .01)
                this.#useInhibition.delete(key);
            else
                this.#useInhibition.set(key, next);
        }
        const key = this.#explorationIdentity(offer);
        this.#useInhibition.set(key, (this.#useInhibition.get(key) ?? 0) + 1);
    }
    #relation(previousNodeId, nextNodeId) {
        if (previousNodeId === nextNodeId)
            return 'same-node';
        const snapshot = this.workspace.snapshot();
        if (previousNodeId === snapshot.rootNodeId)
            return 'root-to-branch';
        if (nextNodeId === snapshot.rootNodeId)
            return 'branch-to-root';
        if (snapshot.dependencies.some(edge => edge.dependentNodeId === previousNodeId && edge.requiredNodeId === nextNodeId))
            return 'parent-to-child';
        if (snapshot.dependencies.some(edge => edge.requiredNodeId === previousNodeId && edge.dependentNodeId === nextNodeId))
            return 'child-to-parent';
        return null;
    }
    #habitDrive(operation, nodeId) {
        const previous = this.#dispatchHistory.at(-1);
        if (!previous)
            return 0;
        const relation = this.#relation(previous.nodeId, nodeId);
        if (!relation)
            return 0;
        return this.habit.drive({ previousOperation: previous.operation, nextOperation: operation, relation });
    }
    #recordDispatch(operation, nodeId) {
        const recent = this.#dispatchHistory.slice(-Math.min(this.#dispatchHistory.length, 7)).reverse();
        const sequence = this.habit.recordDispatch({ operation,
            relationsFromRecent: recent.map(value => this.#relation(value.nodeId, nodeId)) });
        this.#dispatchHistory.push({ operation, nodeId });
        if (this.#dispatchHistory.length > 8)
            this.#dispatchHistory.shift();
        return sequence;
    }
    #result(status, cycles, goalEvaluation) {
        return { status, actions: this.environment.actionCount, cycles, goalEvaluation,
            notGlobalImpossibilityClaim: true };
    }
}
//# sourceMappingURL=controller.js.map