import { sha } from '../util.js';
/** Transient feedback cursor, not a task planner or an experience store.
 * Sequence-only frames preserve a query. A -> B -> A still invalidates it. */
export class ActiveControlTrajectoryV1 {
    #latestSequence = 0;
    #identity = '';
    #publicRevision = 0;
    #actionRevision = 0;
    #lastActionEventId = null;
    #query = null;
    #mediumVersion = null;
    #deviations = 0;
    accept(observation) {
        if (observation.sequence <= this.#latestSequence)
            return;
        const identity = sha({ self: observation.self, objects: observation.objects, targetId: observation.targetId });
        if (identity !== this.#identity)
            this.#publicRevision++;
        this.#identity = identity;
        this.#latestSequence = observation.sequence;
    }
    capture() {
        return { publicRevision: this.#publicRevision, actionRevision: this.#actionRevision,
            observationSequence: this.#latestSequence, observationIdentity: this.#identity };
    }
    current(context) {
        return context.publicRevision === this.#publicRevision && context.actionRevision === this.#actionRevision;
    }
    begin(requestId, nodeId) {
        const context = this.capture();
        this.#query = { requestId, nodeId, context };
        return context;
    }
    end(mediumVersion) { this.#query = null; this.#mediumVersion = mediumVersion; }
    action(eventId) { this.#actionRevision++; this.#lastActionEventId = eventId; }
    deviation() { this.#publicRevision++; this.#deviations++; }
    snapshot() {
        return { version: 'ActiveControlTrajectoryV1', ...this.capture(),
            mediumVersion: this.#mediumVersion, lastActionEventId: this.#lastActionEventId,
            pending: this.#query, deviationCount: this.#deviations };
    }
}
//# sourceMappingURL=active-trajectory.js.map