import { assert, canonical, sha } from '../util.js';
const META_CHANNELS = new Set([
    'branch-entropy', 'prediction-support', 'applicable-relations', 'surprise-rate',
    'goal-residual', 'action-budget-remaining',
]);
function bandFor(value) {
    assert(Number.isFinite(value) && value >= 0 && value <= 1, 'meta-channel-value-out-of-range');
    return Math.min(7, Math.floor(value * 8));
}
export function quantizeMetaInternalChannelsV1(channels) {
    const seen = new Set();
    return channels.slice().sort((left, right) => left.name.localeCompare(right.name, 'en'))
        .map(channel => {
        assert(channel.version === 'VerifiedInternalChannelV1'
            && META_CHANNELS.has(channel.name)
            && channel.provenance === 'verified-internal'
            && channel.availableBeforeOutcome === true, 'invalid-meta-channel-provenance');
        assert(!seen.has(channel.name), 'duplicate-meta-channel');
        seen.add(channel.name);
        return { version: 'MetaInternalConditionBandV1', channel: channel.name,
            bandId: bandFor(channel.value), value: channel.value };
    });
}
function conditionKey(channel, bandId) {
    return `${channel}:${bandId}`;
}
function jointContextIds(externalContextIds, key) {
    return [...new Set(externalContextIds)].sort((left, right) => left.localeCompare(right, 'en'))
        .map(contextId => `${contextId}×${key}`);
}
/** Derive maximal presence runs without using wall-clock or event-id order. */
export function deriveMetaEvidenceEpisodesV1(observations) {
    const ordered = observations.slice().sort((left, right) => left.depositionOrdinal - right.depositionOrdinal);
    const seenOrdinals = new Set();
    const seenEventIds = new Set();
    const open = new Map();
    const episodes = [];
    const close = (key) => {
        const current = open.get(key);
        if (!current)
            return;
        const contexts = [...current.externalContextIds].sort((left, right) => left.localeCompare(right, 'en'));
        const joint = jointContextIds(contexts, key);
        const identity = { key, startOrdinal: current.startOrdinal, endOrdinal: current.endOrdinal,
            memberEventIds: current.memberEventIds, externalContextIds: contexts };
        episodes.push({ version: 'MetaEvidenceEpisodeV1', episodeId: sha(identity), conditionKey: key,
            channel: current.channel, bandId: current.bandId, startOrdinal: current.startOrdinal,
            endOrdinal: current.endOrdinal, memberEventIds: [...current.memberEventIds],
            externalContextIds: contexts, jointContextIds: joint });
        open.delete(key);
    };
    for (const observation of ordered) {
        assert(Number.isSafeInteger(observation.depositionOrdinal) && observation.depositionOrdinal >= 0, 'meta-invalid-deposition-ordinal');
        assert(!seenOrdinals.has(observation.depositionOrdinal), 'meta-duplicate-deposition-ordinal');
        assert(observation.eventId.length > 0 && !seenEventIds.has(observation.eventId), 'meta-duplicate-event-id');
        seenEventIds.add(observation.eventId);
        // Missing ordinals are an observation gap, not evidence that an internal
        // condition left its band.  The next explicit observation decides this.
        seenOrdinals.add(observation.depositionOrdinal);
        const present = new Set(observation.bands.map(band => conditionKey(band.channel, band.bandId)));
        const observed = observation.observedChannels === undefined ? null
            : new Set(observation.observedChannels);
        for (const key of [...open.keys()]) {
            const channel = key.slice(0, key.lastIndexOf(':'));
            if (observed !== null && observed.has(channel) && !present.has(key))
                close(key);
        }
        for (const band of observation.bands) {
            const key = conditionKey(band.channel, band.bandId);
            assert(META_CHANNELS.has(band.channel) && Number.isInteger(band.bandId)
                && band.bandId >= 0 && band.bandId <= 7 && Number.isFinite(band.value)
                && band.value >= 0 && band.value <= 1, 'invalid-meta-condition-band');
            const current = open.get(key);
            if (current) {
                current.endOrdinal = observation.depositionOrdinal;
                current.memberEventIds.push(observation.eventId);
                for (const contextId of observation.externalContextIds)
                    current.externalContextIds.add(contextId);
            }
            else {
                open.set(key, { channel: band.channel, bandId: band.bandId,
                    startOrdinal: observation.depositionOrdinal, endOrdinal: observation.depositionOrdinal,
                    memberEventIds: [observation.eventId], externalContextIds: new Set(observation.externalContextIds) });
            }
        }
    }
    for (const key of [...open.keys()])
        close(key);
    return episodes.sort((left, right) => left.startOrdinal - right.startOrdinal
        || left.conditionKey.localeCompare(right.conditionKey, 'en'));
}
export class MetaEvidenceStoreV1 {
    #observations = [];
    observe(eventId, depositionOrdinal, channels, externalContextIds, observedChannels) {
        assert(eventId.length > 0, 'meta-event-id-empty');
        assert(Number.isSafeInteger(depositionOrdinal) && depositionOrdinal >= 0, 'meta-invalid-deposition-ordinal');
        assert(!this.#observations.some(value => value.depositionOrdinal === depositionOrdinal), 'meta-duplicate-deposition-ordinal');
        assert(!this.#observations.some(value => value.eventId === eventId), 'meta-duplicate-event-id');
        this.#observations.push({ version: 'MetaEvidenceObservationV1', eventId, depositionOrdinal,
            externalContextIds: [...new Set(externalContextIds)].sort((left, right) => left.localeCompare(right, 'en')),
            ...(observedChannels === undefined ? {} : { observedChannels: [...new Set(observedChannels)]
                    .sort((left, right) => left.localeCompare(right, 'en')) }),
            bands: quantizeMetaInternalChannelsV1(channels ?? []) });
    }
    snapshot() {
        const observations = structuredClone(this.#observations).sort((left, right) => left.depositionOrdinal - right.depositionOrdinal);
        return { version: 'MetaEvidenceStateV1', observations,
            episodes: deriveMetaEvidenceEpisodesV1(observations) };
    }
    static restore(state) {
        assert(state.version === 'MetaEvidenceStateV1', 'meta-state-version-mismatch');
        const orderedObservations = [...state.observations].sort((left, right) => left.depositionOrdinal - right.depositionOrdinal);
        assert(canonical(state.observations) === canonical(orderedObservations), 'meta-observations-not-canonical');
        const store = new MetaEvidenceStoreV1();
        for (const observation of state.observations) {
            assert(observation.version === 'MetaEvidenceObservationV1', 'meta-observation-version-mismatch');
            const contexts = [...observation.externalContextIds];
            assert(new Set(contexts).size === contexts.length
                && contexts.slice().sort((left, right) => left.localeCompare(right, 'en'))
                    .every((contextId, index) => contextId === contexts[index]), 'meta-contexts-not-canonical');
            if (observation.observedChannels !== undefined) {
                const channels = [...observation.observedChannels];
                assert(new Set(channels).size === channels.length
                    && channels.every(channel => META_CHANNELS.has(channel))
                    && channels.slice().sort((left, right) => left.localeCompare(right, 'en'))
                        .every((channel, index) => channel === channels[index]), 'meta-observed-channels-not-canonical');
                assert(observation.bands.every(band => channels.includes(band.channel)), 'meta-band-channel-not-observed');
            }
            assert(canonical(observation) === canonical({ ...observation,
                bands: quantizeMetaInternalChannelsV1(observation.bands.map(band => ({
                    version: 'VerifiedInternalChannelV1', name: band.channel, value: band.value,
                    provenance: 'verified-internal', availableBeforeOutcome: true
                }))) }), 'meta-observation-not-canonical');
            store.#observations.push(structuredClone(observation));
        }
        const derived = deriveMetaEvidenceEpisodesV1(store.#observations);
        assert(canonical(derived) === canonical(state.episodes), 'meta-episode-state-mismatch');
        return store;
    }
}
//# sourceMappingURL=meta-evidence.js.map