import { createReadStream } from 'node:fs';
import { access, mkdir, readFile } from 'node:fs/promises';
import { dirname, relative, resolve } from 'node:path';
import { createInterface } from 'node:readline';
import { cueFor, validateEvent } from '../events.js';
import { DistributedHierarchicalPhysicalMemoryV1, DISTRIBUTED_HIERARCHICAL_MEMORY_VERSION_V3 } from '../distributed-hierarchical-memory.js';
import { ControlHabitWeightsV1 } from '../control/habit.js';
import { createDistributedG6ProvenanceV1, validateDistributedG6ProvenanceV1, DISTRIBUTED_G6_R1_REBUILD_PRODUCER_IDENTITY_V1, saveExperienceBundleV1 } from '../runtime.js';
import { assert, canonical, fileSha, saveJson, sha } from '../util.js';
export const TRUSTED_ATTEMPT_018_SOURCE_V1 = Object.freeze({
    version: 'TrustedRawR1SourceSpecificationV1',
    sourceId: 'hierarchical-multilevel-goal-chain-live-v1-attempt-018',
    files: {
        frames: { filename: 'frames.jsonl',
            sha256: 'e47145afc07081a80dd28d29d625bfcc9edb17256276c7cdbb963189ceced59f' },
        events: { filename: 'events.jsonl',
            sha256: 'd9a3e45df39e0c5b3526f53e62feb9a8ba5fcee4948f1941481a120da718f7ca' },
        protocol: { filename: 'RUN_PROTOCOL.json',
            sha256: 'f1ef4b09f53f83b36b64e56c1224c39081b4e97c61324acff3e06a3b523380bc' },
    },
    expected: { frameCount: 6_330, firstSequence: 1, lastSequence: 6_330,
        protocolEpisodes: 128, bodyResults: 256, interactionAttempts: 16 },
    integrityBoundary: 'hashes-frozen-at-rebuild-time-not-a-contemporaneous-capture-manifest',
});
async function jsonLines(path) {
    const values = [];
    const lines = createInterface({ input: createReadStream(path, { encoding: 'utf8' }), crlfDelay: Infinity });
    for await (const line of lines) {
        if (!line.trim())
            continue;
        const value = JSON.parse(line);
        assert(value !== null && typeof value === 'object' && !Array.isArray(value), 'trusted-R1-jsonl-record-must-be-object');
        values.push(value);
    }
    return values;
}
function asObservation(value) {
    assert(value !== null && typeof value === 'object' && !Array.isArray(value), 'trusted-R1-frame-value-must-be-object');
    return value;
}
function asBodyResult(value) {
    assert(value !== null && typeof value === 'object' && !Array.isArray(value), 'trusted-R1-body-result-must-be-object');
    return value;
}
function samePlannedAction(cue, result) {
    return cue !== undefined && cue.kind === result.action.kind
        && canonical(cue.parameters) === canonical(result.action.parameters);
}
function publicTrackedIds(frames, result) {
    const tracked = new Set(['self']);
    if (result.action.targetId)
        tracked.add(result.action.targetId);
    for (const frame of frames)
        if (frame.targetId)
            tracked.add(frame.targetId);
    for (let index = 1; index < frames.length; index++) {
        const before = new Map(frames[index - 1].objects.map(value => [value.id, value]));
        const after = new Map(frames[index].objects.map(value => [value.id, value]));
        for (const id of new Set([...before.keys(), ...after.keys()]))
            if (canonical(before.get(id) ?? null) !== canonical(after.get(id) ?? null))
                tracked.add(id);
    }
    return [...tracked].sort((left, right) => left.localeCompare(right, 'en'));
}
function assertFrames(frames, specification) {
    assert(frames.length === specification.expected.frameCount, `trusted-R1-frame-count:${frames.length}:${specification.expected.frameCount}`);
    const bySequence = new Map();
    for (let index = 0; index < frames.length; index++) {
        const frame = frames[index];
        assert(Number.isSafeInteger(frame.sequence), 'trusted-R1-frame-sequence-invalid');
        assert(Number.isFinite(frame.activeSeconds), 'trusted-R1-frame-time-invalid');
        assert(!bySequence.has(frame.sequence), `trusted-R1-frame-sequence-duplicate:${frame.sequence}`);
        if (index > 0) {
            assert(frame.sequence === frames[index - 1].sequence + 1, `trusted-R1-frame-gap:${frames[index - 1].sequence}:${frame.sequence}`);
            assert(frame.activeSeconds > frames[index - 1].activeSeconds, `trusted-R1-frame-time-not-increasing:${frame.sequence}`);
        }
        bySequence.set(frame.sequence, frame);
    }
    assert(frames[0].sequence === specification.expected.firstSequence
        && frames.at(-1).sequence === specification.expected.lastSequence, 'trusted-R1-frame-range-mismatch');
    return bySequence;
}
function assertInteractionAttempts(attempts, receipts, expected) {
    assert(attempts.length === expected, `trusted-R1-interaction-attempt-count:${attempts.length}:${expected}`);
    const interacts = receipts.filter(value => value.action.kind === 'interact');
    assert(interacts.length === attempts.length, 'trusted-R1-interaction-receipt-count-mismatch');
    const packetSequences = new Set();
    for (const attempt of attempts) {
        assert(Number.isSafeInteger(attempt.observationSequence)
            && typeof attempt.targetId === 'string' && attempt.targetId.length > 0, 'trusted-R1-interaction-attempt-invalid');
        const matches = interacts.filter(result => result.startSequence === attempt.observationSequence
            && result.action.targetId === attempt.targetId);
        assert(matches.length === 1, 'trusted-R1-interaction-attempt-receipt-mismatch');
        const packetSequence = attempt.packet?.sequence;
        assert(Number.isSafeInteger(packetSequence) && !packetSequences.has(packetSequence), 'trusted-R1-interaction-packet-sequence-invalid');
        packetSequences.add(packetSequence);
    }
}
export async function reconstructTrustedRawR1SourceV1(sourceDirectory, specification = TRUSTED_ATTEMPT_018_SOURCE_V1) {
    const source = resolve(sourceDirectory);
    const paths = { frames: resolve(source, specification.files.frames.filename),
        events: resolve(source, specification.files.events.filename),
        protocol: resolve(source, specification.files.protocol.filename) };
    await Promise.all(Object.values(paths).map(path => access(path)));
    const actualHashes = { frames: await fileSha(paths.frames), events: await fileSha(paths.events),
        protocol: await fileSha(paths.protocol) };
    for (const key of ['frames', 'events', 'protocol'])
        assert(actualHashes[key] === specification.files[key].sha256, `trusted-R1-source-hash-mismatch:${key}:${actualHashes[key]}:${specification.files[key].sha256}`);
    const protocol = JSON.parse(await readFile(paths.protocol, 'utf8'));
    assert(Array.isArray(protocol.foundation)
        && protocol.foundation.length === specification.expected.protocolEpisodes, 'trusted-R1-protocol-episode-count-mismatch');
    const frameRecords = await jsonLines(paths.frames);
    assert(frameRecords.every(value => value.kind === 'frame'), 'trusted-R1-non-frame-record-in-frame-stream');
    const frames = frameRecords.map(value => asObservation(value.value));
    const bySequence = assertFrames(frames, specification);
    const eventRecords = await jsonLines(paths.events);
    const bodyResults = eventRecords.filter(value => value.kind === 'body-result')
        .map(value => asBodyResult(value.value));
    const interactionAttempts = eventRecords.filter(value => value.kind === 'block-interaction-attempt')
        .map(value => value.value);
    assert(eventRecords.every(value => value.kind === 'body-result'
        || value.kind === 'block-interaction-attempt'), 'trusted-R1-unexpected-event-record-kind');
    assert(bodyResults.length === specification.expected.bodyResults, `trusted-R1-body-result-count:${bodyResults.length}:${specification.expected.bodyResults}`);
    assertInteractionAttempts(interactionAttempts, bodyResults, specification.expected.interactionAttempts);
    const reconstructed = [];
    for (let episodeIndex = 0; episodeIndex < protocol.foundation.length; episodeIndex++) {
        const episode = protocol.foundation[episodeIndex];
        for (let part = 0; part < 2; part++) {
            const receiptIndex = episodeIndex * 2 + part;
            const receipt = bodyResults[receiptIndex];
            assert(receipt.executed && receipt.status === 'completed', `trusted-R1-unexecuted-receipt:${receiptIndex}`);
            assert(Number.isSafeInteger(receipt.startSequence) && Number.isSafeInteger(receipt.endSequence)
                && receipt.startSequence < receipt.endSequence, `trusted-R1-receipt-window-invalid:${receiptIndex}`);
            const plannedCue = part === 0 ? episode.chain?.actionCue : episode.chain?.verificationCue;
            assert(samePlannedAction(plannedCue, receipt), `trusted-R1-action-plan-mismatch:${episodeIndex}:${part}`);
            const window = [];
            for (let sequence = receipt.startSequence; sequence <= receipt.endSequence; sequence++) {
                const frame = bySequence.get(sequence);
                assert(frame, `trusted-R1-receipt-frame-missing:${receiptIndex}:${sequence}`);
                window.push(frame);
            }
            const event = { version: 'RealEventV5',
                id: `${specification.sourceId}:${actualHashes.events.slice(0, 16)}:r1-${String(receiptIndex + 1).padStart(3, '0')}`,
                cue: cueFor(receipt.action, window[0]), frames: structuredClone(window),
                trackedIds: publicTrackedIds(window, receipt), bodyResult: structuredClone(receipt),
                provenance: 'executed-real-body', complete: true };
            validateEvent(event);
            reconstructed.push(event);
        }
    }
    assert(reconstructed.length === specification.expected.bodyResults, 'trusted-R1-reconstruction-cardinality-mismatch');
    const audit = { version: 'TrustedRawR1SourceAuditV1', passed: true,
        sourceId: specification.sourceId, sourceDirectory: source, sourceFileSha256: actualHashes,
        integrityBoundary: specification.integrityBoundary,
        raw: { frames: frames.length, firstSequence: frames[0].sequence,
            lastSequence: frames.at(-1).sequence, bodyResults: bodyResults.length,
            interactionAttempts: interactionAttempts.length, protocolEpisodes: protocol.foundation.length,
            realEventRecords: 0, explicitHierarchyContinuityRecords: 0 },
        reconstruction: { r1Atoms: reconstructed.length, r2ContinuousEvents: 0, r2aPatterns: 0,
            r2aRelations: 0, reconstructedEventSha256: reconstructed.map(value => sha(value)),
            armFieldsConsumed: 0, comparisonFieldsConsumed: 0, expectedResultFieldsConsumed: 0,
            legacySnapshotInputsConsumed: 0,
            acceptedSourceFiles: [specification.files.frames.filename, specification.files.events.filename,
                specification.files.protocol.filename],
            continuityQualification: 'R1-only-new-continuous-capture-required' } };
    return { audit: Object.freeze(audit), events: Object.freeze(reconstructed) };
}
function assertOutputOutsideSource(sourceDirectory, outputDirectory) {
    const source = resolve(sourceDirectory), output = resolve(outputDirectory);
    const fromSource = relative(source, output), fromOutput = relative(output, source);
    assert(fromSource !== '' && fromSource !== '.' && fromOutput !== '' && fromOutput !== '.', 'trusted-R1-rebuild-output-must-differ-from-source');
    assert(fromSource.startsWith('..') || resolve(source, fromSource) !== output, 'trusted-R1-rebuild-output-must-not-be-inside-source');
    assert(fromOutput.startsWith('..'), 'trusted-R1-rebuild-output-must-not-contain-source');
}
export async function rebuildTrustedRawR1BaselineV1(sourceDirectory, outputDirectory, specification) {
    assertOutputOutsideSource(sourceDirectory, outputDirectory);
    const reconstruction = await reconstructTrustedRawR1SourceV1(sourceDirectory, specification);
    const memory = new DistributedHierarchicalPhysicalMemoryV1();
    for (const event of reconstruction.events)
        memory.observe(event);
    const snapshot = memory.snapshot();
    assert(snapshot.version === DISTRIBUTED_HIERARCHICAL_MEMORY_VERSION_V3, 'trusted-R1-rebuild-produced-incompatible-snapshot');
    assert(snapshot.seenEventIds.length === reconstruction.events.length
        && snapshot.annotations.length === reconstruction.events.length, 'trusted-R1-rebuild-R1-cardinality-mismatch');
    assert(snapshot.r2.events.length === 0 && snapshot.r2.pending.length === 0, 'trusted-R1-only-source-must-not-produce-R2');
    assert(snapshot.r2a.patterns.length === 0 && snapshot.r2a.relations.length === 0, 'trusted-R1-only-source-must-not-produce-R2A');
    const rawEventHashes = new Map(reconstruction.events.map(value => [value.id, sha(value)]));
    assert(snapshot.annotations.every(value => value.r1Record.eventSha256 === rawEventHashes.get(value.eventId)), 'trusted-R1-rebuild-event-hash-not-bound-to-physical-record');
    const output = resolve(outputDirectory);
    await mkdir(dirname(output), { recursive: true });
    try {
        await access(output);
        throw new Error('trusted-R1-rebuild-output-already-exists');
    }
    catch (error) {
        if (error instanceof Error && error.message === 'trusted-R1-rebuild-output-already-exists')
            throw error;
    }
    await mkdir(output, { recursive: false });
    const sourceEventsSha256 = sha(reconstruction.events.map(value => sha(value)));
    const distributedG6Provenance = createDistributedG6ProvenanceV1({
        version: 'DistributedG6ExperienceProvenanceV1', producer: 'trusted-r1-rebuild-v1',
        producerIdentitySha256: DISTRIBUTED_G6_R1_REBUILD_PRODUCER_IDENTITY_V1,
        sourceId: specification.sourceId, sourceEventsSha256,
    });
    const pointer = await saveExperienceBundleV1(output, snapshot, {
        actions: reconstruction.events.length, eventCount: reconstruction.events.length,
        writes: snapshot.writes, distributedG6Provenance
    }, new ControlHabitWeightsV1());
    validateDistributedG6ProvenanceV1(pointer.distributedG6Provenance);
    assert(pointer.distributedG6Provenance.producer === 'trusted-r1-rebuild-v1'
        && pointer.distributedG6Provenance.sourceId === specification.sourceId
        && pointer.distributedG6Provenance.sourceEventsSha256 === sourceEventsSha256, 'trusted-R1-rebuild-pointer-provenance-mismatch');
    const pointerPath = resolve(output, 'EXPERIENCE_LATEST.json');
    const snapshotPath = resolve(output, pointer.filename);
    const audit = { version: 'TrustedDistributedR1RebuildAuditV1',
        passed: true, source: reconstruction.audit,
        output: { directory: output, pointerPath, pointerSha256: await fileSha(pointerPath), snapshotPath,
            snapshotFileSha256: await fileSha(snapshotPath), snapshotCanonicalSha256: sha(snapshot),
            snapshotVersion: snapshot.version, r1Atoms: snapshot.seenEventIds.length,
            r2ContinuousEvents: 0, r2aPatterns: 0, r2aRelations: 0 },
        nextStep: 'capture-32-real-continuous-events-across-8-layouts' };
    await saveJson(resolve(output, 'TRUSTED_SOURCE_AUDIT.json'), reconstruction.audit);
    await saveJson(resolve(output, 'REBUILD_AUDIT.json'), audit);
    return audit;
}
export async function rebuildTrustedAttempt018R1BaselineV1(sourceDirectory, outputDirectory) {
    return rebuildTrustedRawR1BaselineV1(sourceDirectory, outputDirectory, TRUSTED_ATTEMPT_018_SOURCE_V1);
}
//# sourceMappingURL=rebuild-minecraft-distributed-g6-r1-baseline-v1.js.map