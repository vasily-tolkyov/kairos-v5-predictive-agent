import { Worker } from 'node:worker_threads';
/** The only compute worker is a physical-model owner, never another agent. */
export class Compute {
    worker = new Worker(new URL('./worker.js', import.meta.url));
    #id = 0;
    #pending = new Map();
    #queue = [];
    #inFlight = null;
    #drainScheduled = false;
    #enqueuedCount = 0;
    #dispatchedCount = 0;
    #completedCount = 0;
    #backgroundCompletedCount = 0;
    #foregroundWaitMs = 0;
    #backgroundWaitMs = 0;
    #foregroundExecutionMs = 0;
    #backgroundExecutionMs = 0;
    #closed = false;
    #failure = null;
    constructor() {
        this.worker.on('message', message => {
            const pending = this.#pending.get(message.id);
            if (!pending)
                return;
            this.#pending.delete(message.id);
            const inFlight = this.#inFlight;
            if (inFlight === null || inFlight.id !== message.id)
                throw new Error('physical-worker-response-order-mismatch');
            this.#inFlight = null;
            this.#completedCount++;
            if (inFlight.background)
                this.#backgroundCompletedCount++;
            const executionMs = performance.now() - inFlight.startedAt;
            if (inFlight.background)
                this.#backgroundExecutionMs += executionMs;
            else
                this.#foregroundExecutionMs += executionMs;
            if (message.error) {
                const error = new Error(message.error.message);
                error.stack = message.error.stack;
                pending.reject(error);
            }
            else
                pending.resolve(message.value);
            this.#scheduleDrain();
        });
        this.worker.on('error', error => {
            this.#failure ??= error;
            for (const p of this.#pending.values())
                p.reject(error);
            this.#pending.clear();
            this.#queue.length = 0;
            this.#inFlight = null;
        });
        this.worker.on('exit', code => {
            if (this.#closed)
                return;
            const error = this.#failure ?? new Error(`physical-worker-exited:${code}`);
            this.#failure = error;
            for (const p of this.#pending.values())
                p.reject(error);
            this.#pending.clear();
            this.#queue.length = 0;
            this.#inFlight = null;
        });
    }
    call(method, ...args) {
        if (this.#failure)
            return Promise.reject(this.#failure);
        if (this.#closed)
            return Promise.reject(new Error('physical-worker-closed'));
        return new Promise((resolve, reject) => {
            const id = ++this.#id;
            const background = method === 'predict' || method === 'predictCandidate'
                || method === 'predictShortChain'
                || method === 'predictContinuation' || method === 'probe';
            this.#pending.set(id, { resolve: resolve, reject });
            this.#queue.push({ id, method, args, background, enqueuedAt: performance.now() });
            this.#enqueuedCount++;
            this.#scheduleDrain();
        });
    }
    #scheduleDrain() {
        if (this.#drainScheduled || this.#closed || this.#failure)
            return;
        this.#drainScheduled = true;
        setImmediate(() => { this.#drainScheduled = false; this.#drain(); });
    }
    #drain() {
        if (this.#inFlight || this.#queue.length === 0 || this.#closed || this.#failure)
            return;
        // Foreground memory/status work always drains before queued read-only
        // prediction work.  FIFO is preserved inside each class; no operation is
        // allowed to overtake a prior foreground write.
        const foregroundIndex = this.#queue.findIndex(entry => !entry.background);
        const index = foregroundIndex >= 0 ? foregroundIndex : 0;
        const entry = this.#queue.splice(index, 1)[0];
        const waitMs = performance.now() - entry.enqueuedAt;
        if (entry.background)
            this.#backgroundWaitMs += waitMs;
        else
            this.#foregroundWaitMs += waitMs;
        this.#inFlight = { id: entry.id, startedAt: performance.now(), background: entry.background };
        this.#dispatchedCount++;
        this.worker.postMessage({ id: entry.id, method: entry.method, args: entry.args });
    }
    /** Explicit opt-in seam for the staged V4 timescale owner. */
    async enableTimescaleV2() { await this.call('enableTimescaleV2'); }
    async advanceMeasured(logicalTime, measurements) {
        await this.call('advanceMeasured', logicalTime, measurements);
    }
    async snapshotV4() {
        return this.call('snapshotV4');
    }
    async restoreV4(snapshot) {
        await this.call('restoreV4', snapshot);
    }
    /** Serialize and persist the current memory snapshot inside the worker
     * (PLAN-005 1.2, PLAN-008 streaming). */
    async snapshotBundle(request) {
        return this.call('snapshotBundle', request);
    }
    /** Bounded media page from the worker-retained last saved snapshot (PLAN-005 1.1). */
    async mediaPage(request) {
        return this.call('mediaPage', request);
    }
    async recordRuntimeMeasurement(input) {
        await this.call('recordRuntimeMeasurement', input);
    }
    async recordAttractorPublicObservation(input) {
        await this.call('recordAttractorPublicObservation', input);
    }
    async resolveAttractorPublicReadout(mediumVersion, readout) {
        return this.call('resolveAttractorPublicReadout', mediumVersion, readout);
    }
    async recordPredictionViolation(input) {
        return this.call('recordPredictionViolation', input);
    }
    async recordFactorialArm(input) {
        return this.call('recordFactorialArm', input);
    }
    async pendingInterventionArmRequests() {
        return this.call('pendingInterventionArmRequests');
    }
    async recordInterventionWindow(input) {
        return this.call('recordInterventionWindow', input);
    }
    performanceAudit() {
        return { enqueued: this.#enqueuedCount, dispatched: this.#dispatchedCount,
            completed: this.#completedCount, backgroundCompleted: this.#backgroundCompletedCount,
            queued: this.#queue.length, foregroundWaitMs: this.#foregroundWaitMs,
            backgroundWaitMs: this.#backgroundWaitMs,
            foregroundExecutionMs: this.#foregroundExecutionMs,
            backgroundExecutionMs: this.#backgroundExecutionMs };
    }
    async close() {
        this.#closed = true;
        const error = new Error('physical-worker-closed');
        for (const entry of this.#queue)
            this.#pending.get(entry.id)?.reject(error);
        this.#queue.length = 0;
        for (const p of this.#pending.values())
            p.reject(error);
        this.#pending.clear();
        this.#inFlight = null;
        await this.worker.terminate();
    }
}
//# sourceMappingURL=compute.js.map