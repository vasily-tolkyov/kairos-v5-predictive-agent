export class StallWatchdogV1 {
    #options;
    #timer = null;
    #last = 0;
    #sustainedStallMs = 0;
    #tickBusy = false;
    #protectiveStopTriggered = false;
    #evidenceFailureObserved = false;
    constructor(options) {
        this.#options = { intervalMs: options.intervalMs ?? 1000,
            recordThresholdMs: options.recordThresholdMs ?? 5000,
            stopThresholdMs: options.stopThresholdMs ?? 25000, ...options };
    }
    get protectiveStopTriggered() { return this.#protectiveStopTriggered; }
    start() {
        if (this.#timer !== null)
            return;
        this.#last = Date.now();
        this.#timer = setInterval(() => { void this.#tick(); }, this.#options.intervalMs);
        this.#timer.unref();
    }
    async #tick() {
        if (this.#tickBusy)
            return;
        this.#tickBusy = true;
        try {
            const now = Date.now();
            const lagMs = now - this.#last - this.#options.intervalMs;
            this.#last = now;
            const evidenceFailure = this.#options.evidenceFailure();
            if (evidenceFailure !== null && !this.#evidenceFailureObserved) {
                this.#evidenceFailureObserved = true;
                this.#options.onEvidenceFailure(evidenceFailure);
            }
            if (lagMs <= this.#options.recordThresholdMs) {
                this.#sustainedStallMs = 0;
                return;
            }
            this.#sustainedStallMs += lagMs;
            this.#options.record('stall', { stallMs: lagMs, sustainedStallMs: this.#sustainedStallMs,
                measuredAt: new Date(now).toISOString() });
            if (this.#sustainedStallMs > this.#options.stopThresholdMs && !this.#protectiveStopTriggered) {
                this.#protectiveStopTriggered = true;
                this.#options.record('stall-protective-stop', { sustainedStallMs: this.#sustainedStallMs });
                try {
                    await this.#options.checkpoint();
                }
                catch (error) {
                    this.#options.record('stall-checkpoint-failed', { message: error instanceof Error ? error.message : String(error) });
                }
                finally {
                    this.#options.stop();
                }
            }
        }
        finally {
            this.#tickBusy = false;
        }
    }
    dispose() {
        if (this.#timer !== null)
            clearInterval(this.#timer);
        this.#timer = null;
    }
}
//# sourceMappingURL=stall-watchdog.js.map