import { desiredChangesForGoal, goalPredicates, evaluateGroundedReadoutV1 } from './control/goal.js';
import { predictPhysicalShortChainV1 } from './core/prediction/physical-short-chain.js';
import { cueIdentity, eventLocalCurrentPublicStateV1, decodedPublicFeaturesFromContextV1, publicReadoutProjectionContextV1, eventRows, relativePublicFeatures, resolveEventLocalPublicRolesV1, validateEvent } from './events.js';
import { assert, canonical, sha } from './util.js';
import { canonicalStreamSha256 } from './util-stream.js';
import { DistributedR1ExperienceStoreV1 } from './core/learning/distributed-r1.js';
import { DistributedR2ContinuityStoreV1, distributedPublicSignalIdsV1, distributedPublicSignalOccurrencesV1 } from './core/learning/distributed-r2.js';
import { DistributedR2APhysicalPatternLearnerV2 } from './core/learning/distributed-r2a.js';
import { DistributedPhysicalMedium3DV1 } from './core/physics/distributed-physical-medium.js';
import { DistributedHierarchicalTimescaleOwnerV1 } from './core/physics/distributed-hierarchical-timescale-owner-v1.js';
import { DistributedPredictionCloneV2, physicalResidenceMatchV1 } from './core/prediction/distributed-prediction-clone.js';
import { runDistributedPredictionCloneBatchParallelV1 } from './core/prediction/distributed-prediction-clone-parallel.js';
import { RuntimeMeasuredSalienceBridgeV1 } from './core/physics/runtime-measured-salience-bridge-v1.js';
import { runDistributedMediumProbeBatchSyncV1 } from './core/physics/distributed-medium-probe-parallel.js';
import { buildConsolidationReplayPlanV1, executeConsolidationReplayV1, idleForConsolidationReplayV1, validateConsolidationReplayPlanV1, DistributedMediumReplayWriterV1 } from './core/learning/consolidation-replay.js';
import { distributedEvidenceReferenceV1, distributedPredictionSampleV1, emptyDistributedPredictionV1 } from './core/prediction/distributed-reasoning-adapter.js';
import { KAIROS_V5_MEMORY_SEMANTICS, KAIROS_V5_MEMORY_VERSION } from './core/compatibility.js';
import { MetaEvidenceStoreV1 } from './control/meta-evidence.js';
import { AttractorPublicEventDictionaryStoreV1 } from './core/learning/attractor-public-dictionary.js';
import { InterventionAgendaStoreV1 } from './core/learning/intervention-agenda.js';
import { InterventionPairCollectorV1 } from './core/learning/intervention-pair-collector.js';
export const DISTRIBUTED_HIERARCHICAL_MEMORY_VERSION_V3 = KAIROS_V5_MEMORY_VERSION;
export const DISTRIBUTED_HIERARCHY_SEMANTICS_V2 = KAIROS_V5_MEMORY_SEMANTICS;
const GRADE_ORDER = ['single-observation', 'repeated-correlation',
    'predictive-stable', 'causal-hypothesis', 'intervention-supported'];
const gradeMaximum = (values) => [...values].sort((left, right) => GRADE_ORDER.indexOf(right) - GRADE_ORDER.indexOf(left))[0]
    ?? 'single-observation';
const predictiveGrade = (grade) => GRADE_ORDER.indexOf(grade) >= GRADE_ORDER.indexOf('predictive-stable');
const evidenceRankForMemory = (grade) => GRADE_ORDER.indexOf(grade);
function publicChangeMatches(change, desired) {
    if (desired.subject && change.subject !== desired.subject
        && !change.subject.startsWith(`${desired.subject}#`))
        return false;
    if (desired.property && change.property !== desired.property)
        return false;
    if (desired.value !== undefined && !Object.is(change.after, desired.value))
        return false;
    if (desired.direction === 'increase')
        return typeof change.before === 'number'
            && typeof change.after === 'number' && change.after > change.before;
    if (desired.direction === 'decrease')
        return typeof change.before === 'number'
            && typeof change.after === 'number' && change.after < change.before;
    if (desired.direction === 'unchanged')
        return Object.is(change.before, change.after);
    return desired.direction !== 'change' || !Object.is(change.before, change.after);
}
function effectSignature(changes) {
    return sha(changes.map(change => ({ subject: change.subject, property: change.property,
        before: change.before, after: change.after, meaning: change.meaning }))
        .sort((left, right) => canonical(left).localeCompare(canonical(right), 'en')));
}
function goalProgress(changes, goal, evaluation) {
    return desiredChangesForGoal(goal, evaluation).some(target => changes.some(change => publicChangeMatches(change, target.desired)));
}
/** Passive result relevance, not goal success. A measured intermediate value
 * can concern the exact goal object without already being its desired value. */
export function distributedGoalReadoutDiagnosticsV1(readouts, goal, observation, bindings) {
    const predicates = goalPredicates(goal);
    const { byRole } = resolveEventLocalPublicRolesV1(observation, bindings);
    const relevant = (value) => predicates.some(predicate => {
        const property = predicate.observable.startsWith('properties.')
            ? predicate.observable.slice('properties.'.length) : predicate.observable;
        if (value.property !== property)
            return false;
        if (predicate.subject.kind === 'self')
            return value.subjectRole === 'self';
        if (predicate.subject.kind === 'crosshair')
            return value.subjectRole === 'crosshair';
        const actual = byRole.get(value.subjectRole);
        return actual?.id === predicate.subject.id && actual.type === predicate.subject.expectedType;
    });
    const count = readouts.filter(readout => readout.valid && readout.decodedValues.some(relevant)).length;
    const publicPredicates = predicates.filter(predicate => predicate.subject.kind === 'public-object');
    const missing = publicPredicates.some(predicate => {
        const subject = predicate.subject;
        return subject.kind === 'public-object' && !observation.objects.some(object => object.id === subject.id
            && object.type === subject.expectedType);
    });
    return { version: 'BranchReadoutDiagnosticsV1',
        roleBindingStatus: publicPredicates.length === 0 ? 'not-required'
            : missing ? 'target-unavailable' : count > 0 ? 'matched' : 'goal-change-not-reached',
        goalRelevantReadoutCount: count, maxVisitedOriginalKernelIndex: null,
        // Retained interface name; distributed fields have no original kernel index.
        goalRelevantKernelVisited: count > 0 };
}
/**
 * Compare a terminal afferent population with the real event-local public
 * prefix.  No event id, historical outcome, goal answer or world coordinate
 * is available on this path.  Channels not physically decoded remain unknown.
 */
function physicalTerminalChangesV1(readout, currentValues) {
    if (readout.status === 'unknown' || readout.status === 'ambiguous')
        return {
            valid: false, changes: [], decodedValues: [],
            unknown: [`terminal-afferent-readout-${readout.status}`],
        };
    const current = new Map(currentValues.map(value => [`value/${value.subjectRole}/${value.property}`, value.value]));
    const changes = [];
    const decodedValues = [];
    const unknown = [];
    for (const channel of readout.channels) {
        if (channel.status !== 'decoded') {
            unknown.push(`terminal-channel-${channel.status}:${channel.channel}`);
            continue;
        }
        const prefix = 'value/';
        if (!channel.channel.startsWith(prefix)) {
            unknown.push(`terminal-channel-not-public-state:${channel.channel}`);
            continue;
        }
        const suffix = `/${channel.property}`;
        if (!channel.channel.endsWith(suffix)) {
            unknown.push(`terminal-channel-property-mismatch:${channel.channel}`);
            continue;
        }
        const subject = channel.channel.slice(prefix.length, -suffix.length);
        const before = current.get(channel.channel);
        const after = channel.encoding === 'continuous' ? channel.continuous?.estimate : channel.value;
        if (after === undefined) {
            unknown.push(`terminal-channel-value-unavailable:${channel.channel}`);
            continue;
        }
        decodedValues.push({ subjectRole: subject, property: channel.property, value: after });
        if (before === undefined) {
            // A no-effect event is a real, bounded observation encoded by its own
            // public channel.  It is not a guessed state transition.
            if (subject === 'event' && channel.property === 'change-within-observed-window'
                && after === false) {
                changes.push({ subject, property: channel.property, before: false, after: false,
                    observationIndex: 0, meaning: 'observed-co-occurrence' });
            }
            else
                unknown.push(`terminal-current-channel-unavailable:${channel.channel}`);
            continue;
        }
        const unchanged = channel.encoding === 'continuous' && typeof before === 'number'
            && channel.continuous !== undefined
            ? before >= channel.continuous.lowerBound && before <= channel.continuous.upperBound
            : Object.is(before, after);
        if (!unchanged)
            changes.push({ subject, property: channel.property, before, after,
                observationIndex: 0, meaning: 'observed-co-occurrence' });
    }
    return { valid: decodedValues.length > 0, changes, decodedValues,
        unknown: [...new Set(unknown)].sort() };
}
function physicalTerminalDrivesV1(result) {
    const core = new Set(result.attractorReadout.coreSiteIds);
    return result.fieldRun.finalActivations.filter(value => core.has(value.siteId)
        && value.activation > 0).map(value => ({ siteId: value.siteId, intensity: value.activation }));
}
function boundaryBefore(event) {
    return event.hierarchyContinuity?.boundaryBefore ?? 'reset';
}
/**
 * Production owner for the three independent distributed substrates. Public
 * state drives self-organising afferents; no world position is converted into
 * a substrate location and no result label selects a location.
 */
export class DistributedHierarchicalPhysicalMemoryV1 {
    #r1Medium;
    #r1;
    #r2;
    #r2a;
    #annotations = new Map();
    #processedR2 = new Set();
    #seen = new Set();
    #activeSeconds = 0;
    #writes = 0;
    #metaEvidence = new MetaEvidenceStoreV1();
    #metaDepositionOrdinal = 0;
    #r1Revision = 0;
    #r2Revision = 0;
    #originIdentity = 'empty-distributed-substrate';
    #physicalReadouts = new Map();
    #continuationQueryCache = null;
    #r1PredictionCache = null;
    #r2PredictionCache = null;
    #timescaleOwner = null;
    #timescaleEnabled = false;
    #attractorDictionary = new AttractorPublicEventDictionaryStoreV1('KairosV5-R1-terminal');
    #interventionAgenda = new InterventionAgendaStoreV1();
    #interventionPairCollector = new InterventionPairCollectorV1();
    constructor() {
        this.#r1Medium = new DistributedPhysicalMedium3DV1({ name: 'R1', seedHex: '5231' });
        this.#r2 = new DistributedR2ContinuityStoreV1(undefined, undefined, undefined, footprint => this.#r1Medium.isFootprintActive(footprint), () => this.#timescaleEnabled ? this.#timescaleOwner.encodingGain('r2') : 1);
        this.#r2a = new DistributedR2APhysicalPatternLearnerV2(id => this.#r2.isEventActive(id), undefined, undefined, undefined, () => this.#timescaleEnabled ? this.#timescaleOwner.encodingGain('r2a') : 1);
        this.#timescaleOwner = DistributedHierarchicalTimescaleOwnerV1.fromExisting(this.#r1Medium, this.#r2.medium, this.#r2a.medium, 0);
        this.#r1 = new DistributedR1ExperienceStoreV1(this.#r1Medium, undefined, undefined, () => this.#timescaleEnabled ? this.#timescaleOwner.encodingGain('r1') : 1);
    }
    get ready() { return this.#seen.size >= 128; }
    get writes() { return this.#writes; }
    get bufferedEvents() { return Math.min(this.#seen.size, 128); }
    get mapSha256() {
        return this.ready ? this.#r1.projectionSha256() : null;
    }
    /** Cheap identity for one physical/query version, not a per-action full hash.
     * Derived readout handles are transient and are never checkpoint contents. */
    physicalVersion() {
        return sha({ origin: this.#originIdentity, r1: this.#r1Revision, r2: this.#r2Revision,
            r2a: this.#r2a.physicalQueryRevision, time: this.#activeSeconds,
            events: this.#seen.size, writes: this.#writes, protocol: this.#timescaleEnabled });
    }
    advanceTo(activeSeconds, measurements) {
        assert(Number.isFinite(activeSeconds) && activeSeconds >= this.#activeSeconds, 'active-observation-time-reversed');
        const elapsed = activeSeconds - this.#activeSeconds;
        const hasMeasurements = measurements !== undefined
            && Object.values(measurements).some(value => value.length > 0);
        if (!this.#timescaleEnabled && hasMeasurements)
            throw new Error('timescale measurements require opt-in owner');
        if (elapsed > 0 || hasMeasurements) {
            if (this.#timescaleEnabled) {
                this.#timescaleOwner.advanceTo(activeSeconds, measurements ?? { r1: [], r2: [], r2a: [] });
            }
            else {
                this.#r1Medium.recover(elapsed);
                this.#r2.recover(elapsed);
                this.#r2a.recover(elapsed);
            }
            this.#r1.invalidatePhysicalQualification();
            this.#r1Revision++;
            this.#r2Revision++;
            this.#invalidatePredictionCaches();
            this.#activeSeconds = activeSeconds;
        }
    }
    /**
     * Ingest the runtime's measured outcome after the corresponding real event
     * has been deposited.  Structure identities are resolved from the committed
     * R1/R2/R2A records here; callers cannot choose support mass, salience or a
     * physical location.  This path exists only for the explicit V4 owner.
     */
    recordRuntimeMeasurement(input) {
        assert(this.#timescaleEnabled, 'runtime measurements require V4 timescale owner');
        assert(input.version === 'TrustedRuntimeMeasurementContextV1'
            && typeof input.eventId === 'string' && input.eventId.length > 0, 'invalid-runtime-measurement-context');
        const annotation = this.#annotations.get(input.eventId);
        assert(annotation, 'runtime-measurement-event-not-observed');
        assert(Number.isFinite(input.observedAt) && input.observedAt >= 0, 'invalid-runtime-measurement-time');
        const eventEnd = annotation.r1Record.footprint.depositedAt;
        assert(input.observedAt >= eventEnd, 'runtime-measurement-before-event-end');
        const bridge = new RuntimeMeasuredSalienceBridgeV1();
        const common = { observedAt: input.observedAt,
            predictionDeviation: input.predictionDeviation,
            goalResidualBefore: input.goalResidualBefore,
            goalResidualAfter: input.goalResidualAfter };
        const capture = (medium, structureIds) => [...new Set(structureIds)]
            .map(structureId => bridge.capture(medium, { ...common, structureId }));
        const r1 = capture(this.#r1Medium.snapshot(), [`trace:${annotation.r1Record.footprint.traceId}`]);
        const r2Events = annotation.r2EventIds
            .flatMap(eventId => { const event = this.#r2.event(eventId); return event ? [event] : []; })
            .filter(value => value.physicalFootprint !== null && value.learningEligible);
        const r2 = capture(this.#r2.medium.snapshot(), r2Events
            .map(value => `trace:${value.physicalFootprint.traceId}`));
        const r2aTraceIds = r2Events.flatMap(value => this.#patternsFor(value)
            .flatMap(pattern => pattern.physicalTraceIds));
        const r2a = capture(this.#r2a.medium.snapshot(), r2aTraceIds.map(value => `trace:${value}`));
        this.#timescaleOwner.advanceTo(input.observedAt, { r1, r2, r2a });
        if (input.observedAt > this.#activeSeconds) {
            this.#activeSeconds = input.observedAt;
            this.#r1.invalidatePhysicalQualification();
            this.#r1Revision++;
            this.#r2Revision++;
            this.#invalidatePredictionCaches();
        }
    }
    /**
     * Run the DESIGN-002 whitelist only when the controller has measured a
     * genuinely idle state.  Replay is opt-in V4 behaviour; ordinary V3 memory
     * never receives this path.  All plans are checked before any layer changes
     * so an invalid reference cannot leave a partially refreshed hierarchy.
     */
    replayIfIdleV1(signals, seed, maxTraces = 8) {
        assert(this.#timescaleEnabled, 'consolidation replay requires V4 timescale owner');
        if (!idleForConsolidationReplayV1(signals))
            return null;
        const layerSeeds = { r1: seed ^ 0x9e3779b97f4a7c15n,
            r2: seed ^ 0xbf58476d1ce4e5b9n, r2a: seed ^ 0x94d049bb133111ebn };
        const plans = {};
        const writers = {
            r1: new DistributedMediumReplayWriterV1(this.#r1Medium, traceId => this.#timescaleOwner.recordRehearsal('r1', `trace:${traceId}`)),
            r2: new DistributedMediumReplayWriterV1(this.#r2.medium, traceId => this.#timescaleOwner.recordRehearsal('r2', `trace:${traceId}`)),
            r2a: new DistributedMediumReplayWriterV1(this.#r2a.medium, traceId => this.#timescaleOwner.recordRehearsal('r2a', `trace:${traceId}`)),
        };
        const snapshots = { r1: this.#r1Medium.snapshot(), r2: this.#r2.medium.snapshot(),
            r2a: this.#r2a.medium.snapshot() };
        for (const layer of ['r1', 'r2', 'r2a']) {
            const plan = buildConsolidationReplayPlanV1(snapshots[layer], layerSeeds[layer], maxTraces);
            if (plan.selected.length > 0) {
                validateConsolidationReplayPlanV1(plan, writers[layer]);
                plans[layer] = plan;
            }
        }
        if (Object.keys(plans).length === 0)
            return null;
        const layers = {};
        for (const layer of ['r1', 'r2', 'r2a']) {
            const plan = plans[layer];
            if (plan === undefined)
                continue;
            layers[layer] = executeConsolidationReplayV1(plan, writers[layer]);
        }
        this.#r1Revision++;
        this.#r2Revision++;
        this.#invalidatePredictionCaches();
        return { version: 'DistributedHierarchicalConsolidationReplayReceiptV1', provenance: 'replay', layers };
    }
    #invalidatePredictionCaches() {
        this.#continuationQueryCache = null;
        this.#r1PredictionCache = null;
        this.#r2PredictionCache = null;
        this.#physicalReadouts.clear();
    }
    #r1PredictionSubstrate() {
        if (this.#r1PredictionCache === null) {
            const snapshot = this.#r1Medium.snapshot();
            const prescribedActionSiteIds = this.#r1.prescribedActionSiteIds();
            this.#r1PredictionCache = { snapshot, prescribedActionSiteIds,
                clone: new DistributedPredictionCloneV2(snapshot, prescribedActionSiteIds),
                revision: this.#r1Revision };
        }
        return this.#r1PredictionCache;
    }
    #r2PredictionSubstrate() {
        if (this.#r2PredictionCache === null) {
            const snapshot = this.#r2.medium.snapshot();
            const prescribedActionSiteIds = this.#r2.prescribedActionSiteIds();
            this.#r2PredictionCache = { snapshot, prescribedActionSiteIds,
                clone: new DistributedPredictionCloneV2(snapshot, prescribedActionSiteIds),
                revision: this.#r2Revision };
        }
        return this.#r2PredictionCache;
    }
    observe(event) {
        validateEvent(event);
        assert(!this.#seen.has(event.id), 'real-event-already-observed');
        const endedAt = event.frames.at(-1).activeSeconds;
        assert(endedAt >= this.#activeSeconds, 'event-arrived-after-time-was-advanced-past-it');
        this.advanceTo(endedAt);
        // The following trusted deposit changes at least R1 and may close R2/R2A.
        // Never let a pre-deposit read-only clone survive that write boundary.
        this.#invalidatePredictionCaches();
        const receipt = this.#r1.observe(event);
        this.#r1Revision++;
        // Consume one monotonic meta-observation ordinal for every trusted event.
        // Missing channels are recorded as unknown (via observedChannels), never
        // as an inferred absence; this prevents passive gaps from fabricating a
        // second meta episode.
        this.#metaEvidence.observe(event.id, this.#metaDepositionOrdinal++, event.verifiedInternalChannels, [event.frames[0].contextId], event.verifiedInternalChannels === undefined ? undefined
            : event.verifiedInternalChannels.map(channel => channel.name));
        const rows = eventRows(event);
        const before = relativePublicFeatures(event.frames[0]);
        const after = relativePublicFeatures(event.frames.at(-1));
        const beforeSignalOccurrences = distributedPublicSignalOccurrencesV1(before);
        const afterSignalOccurrences = distributedPublicSignalOccurrencesV1(after);
        const annotation = {
            version: 'DistributedR1AnnotationV1', eventId: event.id, cue: structuredClone(event.cue),
            completion: event.complete ? 'complete' : 'censored', contextId: event.frames[0].contextId,
            observedBefore: before, observedAfter: after,
            beforeSignalIds: beforeSignalOccurrences.map(value => value.signalId),
            afterSignalIds: afterSignalOccurrences.map(value => value.signalId),
            beforeSignalOccurrences, afterSignalOccurrences,
            changeWaves: structuredClone(rows.changes), publicRoleBindings: structuredClone(rows.roleBindings),
            r1Record: structuredClone(receipt.record), r2EventIds: [],
        };
        this.#annotations.set(event.id, annotation);
        this.#seen.add(event.id);
        this.#writes += Number(receipt.status === 'deposited');
        const continuity = event.hierarchyContinuity;
        if (!continuity) {
            this.#consumeR2Receipt(this.#r2.interrupt('continuity-reset'));
            return this.#receipt(receipt.novelty);
        }
        const actualTerminal = this.#r1.lookupCurrentObservation(event.frames.at(-1), rows.roleBindings, undefined, 'observed-terminal');
        const atom = { version: 'DistributedR2AtomV1', atomId: `r1:${event.id}`,
            sourceEventId: event.id, exactExperienceIdentity: cueIdentity(event.cue),
            episodePatternSha256: receipt.record.episodePatternSha256,
            r1Topology: structuredClone(receipt.record.episodeTopology),
            r1Footprint: structuredClone(receipt.record.footprint), cue: structuredClone(event.cue),
            contextId: event.frames[0].contextId,
            startedAt: event.frames[0].activeSeconds, endedAt,
            startFrameSequence: event.frames[0].sequence, endFrameSequence: event.frames.at(-1).sequence,
            sessionId: continuity.sessionId, continuityEpochId: continuity.continuityEpochId,
            dependencies: structuredClone(continuity.dependencies), publicChanges: rows.changes.flat(),
            beforePublicSignals: annotation.beforeSignalIds, afterPublicSignals: annotation.afterSignalIds,
            beforePublicSignalOccurrences: annotation.beforeSignalOccurrences,
            afterPublicSignalOccurrences: annotation.afterSignalOccurrences,
            resultChannelR1SiteIds: this.#r1.publicResultChannelSiteIds(receipt.record.episodeTopology.terminalSiteIds),
            observedTerminalR1Drives: actualTerminal.drives
                ?? actualTerminal.siteIds.map(siteId => ({ siteId, intensity: 1 })) };
        const ingested = this.#r2.ingest(atom, boundaryBefore(event));
        if (ingested.closedBefore)
            this.#consumeR2Receipt(ingested.closedBefore);
        if (continuity.processStatusAfter === 'publicly-resolved')
            this.#consumeR2Receipt(this.#r2.close('public-process-resolved'));
        else if (continuity.processStatusAfter === 'observation-insufficient')
            this.#consumeR2Receipt(this.#r2.interrupt('observation-ended'));
        return this.#receipt(receipt.novelty);
    }
    #receipt(novelty) {
        return { status: this.ready ? 'real-event-deposited' : 'initialization-buffer',
            writes: this.#writes, buffered: this.bufferedEvents, mapSha256: this.mapSha256,
            r1Atoms: this.#annotations.size, r2ContinuousEvents: this.#r2.committedEventCount,
            r2aStablePatterns: this.#r2a.indexedStablePatternCount(), novelty: structuredClone(novelty) };
    }
    #consumeR2Receipt(receipt) {
        if (receipt.status !== 'committed')
            return;
        this.#r2Revision++;
        this.#r2PredictionCache = null;
        for (const sourceEventId of receipt.event.sourceEventIds) {
            const annotation = this.#annotations.get(sourceEventId);
            if (annotation)
                this.#annotations.set(sourceEventId, { ...annotation,
                    r2EventIds: [...new Set([...annotation.r2EventIds, receipt.event.eventId])] });
        }
        if (!receipt.event.learningEligible || this.#processedR2.has(receipt.event.eventId))
            return;
        this.#r2a.observe(receipt.event);
        this.#processedR2.add(receipt.event.eventId);
    }
    closeContinuity(boundary) {
        const receipt = boundary.completion === 'complete'
            ? this.#r2.close('normal-stop') : this.#r2.interrupt('session-ended');
        this.#consumeR2Receipt(receipt);
        return receipt;
    }
    #stableR1(annotation) {
        // Semantic annotations decode a basin after it has qualified; they do not
        // decide whether the basin exists.  Support count, context count, dwell,
        // return, escape, ambiguity and competitor separation are all measured by
        // the R1 store against a read-only physical clone.
        return this.#r1.attractorQualification(annotation.eventId).status === 'stable-attractor';
    }
    #stableR1AssembliesForCue(cue) {
        const groups = new Map();
        for (const annotation of this.#annotations.values()) {
            if (cueIdentity(annotation.cue) !== cueIdentity(cue) || !this.#stableR1(annotation))
                continue;
            const qualification = this.#r1.attractorQualification(annotation.eventId);
            if (!this.#r1Medium.isFootprintActive(annotation.r1Record.footprint)
                || qualification.coreSiteIds.length === 0)
                continue;
            const assemblyId = sha({ version: 'DistributedR1PhysicalAttractorAssemblyV2',
                coreSiteIds: qualification.coreSiteIds });
            const group = groups.get(assemblyId) ?? { coreSiteIds: [...qualification.coreSiteIds], memberEventIds: [] };
            group.memberEventIds.push(annotation.eventId);
            groups.set(assemblyId, group);
        }
        return [...groups].sort(([left], [right]) => left.localeCompare(right, 'en'))
            .map(([assemblyId, group]) => ({ assemblyId, coreSiteIds: [...group.coreSiteIds],
            memberEventIds: [...new Set(group.memberEventIds)].sort() }));
    }
    #r2Event(annotation) {
        return annotation.r2EventIds.flatMap(id => {
            const event = this.#r2.event(id);
            return event ? [event] : [];
        })
            .find(value => value.learningEligible && this.#r2.isEventActive(value.eventId)) ?? null;
    }
    #patternsFor(event) {
        if (!event)
            return [];
        return this.#r2a.patterns().filter(value => value.memberR2EventIds.includes(event.eventId));
    }
    #relationsFor(patterns) {
        const ids = new Set(patterns.map(value => value.patternId));
        return this.#r2a.relations().filter(value => ids.has(value.patternId));
    }
    #activePatternQualification(pattern) {
        const active = [];
        pattern.memberR2EventIds.forEach((eventId, index) => {
            const contextIds = this.#r2.eventContextIds(eventId), traceId = pattern.physicalTraceIds[index];
            // The member event and the corresponding R2A deposition are one weakest
            // physical chain.  Missing/misaligned audit metadata fails closed.
            if (contextIds && traceId && this.#r2.isEventActive(eventId)
                && this.#r2a.medium.isFootprintActive(traceId))
                active.push({ eventId, contextIds, traceId });
        });
        const contextIds = [...new Set(active.flatMap(value => value.contextIds))].sort();
        // The index is live only while the physically discovered attractor and
        // ordered propagation corridor remain measurable.  Event counts decode
        // the physical basin; they cannot manufacture its qualification.
        const physicalAttractor = pattern.attractor.coreSiteIds.length > 0
            && pattern.attractor.dwellSteps > 0 && pattern.attractor.returnRate >= 0
            && pattern.attractor.escapeRate < 1 && !pattern.attractor.ambiguous;
        const physicalCorridor = pattern.corridor.forwardPropagationRate >= .75
            && pattern.corridor.reverseRejectionRate >= .75;
        const grade = active.length > 0 && physicalAttractor && physicalCorridor
            ? pattern.grade : 'single-observation';
        return {
            grade,
            activeMemberR2EventIds: active.map(value => value.eventId),
            activePhysicalTraceIds: active.map(value => value.traceId),
            contextIds,
        };
    }
    #activeRelationGrade(relation) {
        const pattern = this.#r2a.patterns().find(value => value.patternId === relation.patternId);
        if (!pattern)
            return 'single-observation';
        const base = this.#activePatternQualification(pattern).grade;
        if (!relation.physicalTraceIds.some(trace => this.#r2a.medium.isFootprintActive(trace)))
            return 'single-observation';
        return evidenceRankForMemory(base) < evidenceRankForMemory('predictive-stable') ? base : relation.grade;
    }
    #currentRelationApplicability(relation, observation, currentAction) {
        const historical = this.#r2a.compareCurrentFactors(relation.relationId, 'sequence' in observation ? distributedPublicSignalIdsV1(relativePublicFeatures(observation)) : observation, currentAction);
        const pattern = this.#r2a.patterns().find(value => value.patternId === relation.patternId);
        const qualification = pattern ? this.#activePatternQualification(pattern) : null;
        const grade = this.#activeRelationGrade(relation);
        const physicalSupportActive = historical.physicalSupportActive
            && (qualification?.activeMemberR2EventIds.length ?? 0) > 0;
        const applicability = physicalSupportActive ? historical.applicability : 0;
        return { ...historical, applicability, evidenceGrade: grade, physicalSupportActive,
            predictionEligible: applicability >= .5 && predictiveGrade(grade),
            highConfidenceActionEligible: applicability >= .75 && grade === 'intervention-supported' };
    }
    #relationComparisons(relations, observation, currentAction) {
        return relations.map(value => this.#currentRelationApplicability(value, observation, currentAction));
    }
    #evidence(annotation, observation, currentAction) {
        const r1Qualification = this.#r1.attractorQualification(annotation.eventId);
        const r1Active = r1Qualification.status === 'stable-attractor'
            && this.#r1Medium.isFootprintActive(annotation.r1Record.footprint);
        const r2Event = this.#r2Event(annotation), patterns = this.#patternsFor(r2Event);
        const r2Footprint = r2Event?.physicalFootprint ?? null;
        const relations = this.#relationsFor(patterns), comparisons = this.#relationComparisons(relations, observation, currentAction);
        const grade = gradeMaximum([...patterns.map(value => this.#activePatternQualification(value).grade),
            ...relations.map(value => this.#activeRelationGrade(value))]);
        const applicability = Math.max(0, ...comparisons.map(value => value.applicability));
        const physicalRelation = comparisons.some(value => value.physicalSupportActive);
        const r2SupportStrength = r2Event && r2Footprint
            ? Math.min(1, r2Footprint.supportMass / Math.max(1, r2Event.atomIds.length * 2)) : 0;
        const activePatternQualifications = patterns.map(value => this.#activePatternQualification(value));
        const r2aPhysicalTraceIds = [...new Set(activePatternQualifications
                .flatMap(value => value.activePhysicalTraceIds))].sort();
        const r2aSupportStrength = physicalRelation
            ? Math.max(0, ...comparisons.map(value => value.physicalBranchSelectionRate)) : 0;
        return distributedEvidenceReferenceV1({ eventId: annotation.eventId,
            r1: annotation.r1Record.footprint, r1Active,
            r2: r2Footprint, r2Active: r2Event !== null && r2Footprint !== null,
            relationIds: relations.map(value => value.relationId).sort(), applicability,
            evidenceGrade: grade,
            predictionEligible: physicalRelation && predictiveGrade(grade),
            productionEligible: physicalRelation && grade === 'intervention-supported',
            r1AttractorId: r1Active ? sha({ version: 'DistributedR1AttractorIdentityV2',
                coreSiteIds: r1Qualification.coreSiteIds }) : null,
            r1ReturnRate: r1Qualification.meanReturnRate,
            r1EscapeRate: r1Qualification.meanEscapeRate,
            r1SupportStrength: r1Active ? r1Qualification.physicalSupportStrength : 0,
            r2CorridorId: r2Event && r2Footprint ? sha({ version: 'DistributedR2CorridorIdentityV2',
                pulseSiteIds: r2Footprint.pulseSiteIds ?? [],
                directedBondIds: r2Footprint.directedBondIds }) : null,
            r2SupportStrength,
            patternIds: patterns.map(value => value.patternId).sort(),
            r2aPhysicalTraceIds, r2aSupportStrength });
    }
    #recallCandidates(goal, evaluation, observation) {
        const desired = desiredChangesForGoal(goal, evaluation);
        const result = [];
        for (const annotation of this.#annotations.values()) {
            if (annotation.completion !== 'complete' || !this.#stableR1(annotation))
                continue;
            const changes = annotation.changeWaves.flat();
            const goalPredicateIds = desired.filter(item => changes.some(change => publicChangeMatches(change, item.desired))).map(item => item.predicateId);
            if (goalPredicateIds.length === 0)
                continue;
            const evidence = this.#evidence(annotation, observation, this.#currentActionInput(annotation, observation));
            result.push({ candidateId: sha({ version: 'DistributedEffectCandidateV1',
                    eventId: annotation.eventId, effect: effectSignature(changes) }), goalPredicateIds,
                actionCue: structuredClone(annotation.cue), observedChanges: structuredClone(changes),
                observedBefore: structuredClone(annotation.observedBefore), evidence,
                unknown: evidence.r2a.relationIds.length === 0
                    ? ['no-repeated-R2A-branch-relation']
                    : evidence.r2a.applicability <= 0 ? ['current-factor-condition-not-satisfied'] : [] });
        }
        return result.sort((left, right) => left.candidateId.localeCompare(right.candidateId, 'en'));
    }
    recallAtomicEffect(goal, evaluation, observation) {
        return this.#recallCandidates(goal, evaluation, observation);
    }
    recallByEffect(goal, evaluation, observation) {
        return this.#recallCandidates(goal, evaluation, observation);
    }
    recallContinuousPattern(goal, evaluation, observation) {
        const desired = desiredChangesForGoal(goal, evaluation);
        return this.#r2a.patterns().flatMap(pattern => {
            // Fetch the named members, not a copy of the whole event store for
            // every member. Order and owned-result isolation remain identical.
            const events = pattern.memberR2EventIds.flatMap(id => {
                const event = this.#r2.event(id);
                return event ? [event] : [];
            });
            if (!events.some(event => desired.some(item => (event.processChanges ?? event.terminalChanges)
                .some(change => publicChangeMatches(change, item.desired)))))
                return [];
            const relations = this.#relationsFor([pattern]);
            const qualification = this.#activePatternQualification(pattern);
            const grade = gradeMaximum([qualification.grade,
                ...relations.map(value => this.#activeRelationGrade(value))]);
            const activeR2Support = qualification.activeMemberR2EventIds.length > 0;
            const activePatternTraces = qualification.activePhysicalTraceIds;
            const comparisons = activeR2Support
                ? this.#relationComparisons(relations, observation) : [];
            const currentApplicability = Math.max(0, ...comparisons.map(value => value.applicability));
            const currentPredictionEligible = activePatternTraces.length > 0
                && comparisons.some(value => value.predictionEligible);
            const observedAtomCount = this.#r2.pendingAtomCount;
            const nextActionCueIdentities = [...new Set(events.flatMap(event => {
                    const identity = event.orderedExperienceIdentities[observedAtomCount];
                    return identity === undefined ? [] : [identity];
                }))].sort();
            const unknown = !activeR2Support ? ['lower-R1-or-R2-physical-support-inactive']
                : activePatternTraces.length === 0 ? ['distributed-R2A-pattern-footprint-inactive']
                    : !predictiveGrade(grade) ? ['continuous-pattern-not-predictive-stable']
                        : !currentPredictionEligible ? ['current-factor-condition-not-predictively-supported'] : [];
            return [{ patternId: pattern.patternId, memberR2EventIds: [...pattern.memberR2EventIds],
                    orderedR1AtomIds: events[0]?.atomIds ?? [], evidenceGrade: grade,
                    activePhysicalTraceIds: activePatternTraces,
                    currentRelationIds: relations.map(value => value.relationId),
                    currentApplicability, currentPredictionEligible, nextActionCueIdentities, unknown }];
        });
    }
    compareCurrentFactors(relationId, observation) {
        const relation = this.#r2a.relations().find(value => value.relationId === relationId);
        // A physical index can change after recovery or a new real event. The
        // retained control branch still names the old relation; absence is zero
        // current support, not permission to relabel it as a different relation.
        if (!relation)
            return { matchedFactorIds: [], contradictedFactorIds: [], unknownFactorIds: [],
                applicability: 0, productionEligible: false, unavailableRelationIds: [relationId] };
        const value = this.#currentRelationApplicability(relation, observation);
        return { matchedFactorIds: value.matchedFactorIds,
            contradictedFactorIds: value.contradictedFactorIds, unknownFactorIds: value.unknownFactorIds,
            applicability: value.applicability, productionEligible: value.highConfidenceActionEligible };
    }
    compareConditions(candidate, state) {
        const currentAction = this.#currentActionInput(this.#annotationFor(candidate), state);
        if (!currentAction)
            return { matchedFactorIds: [], contradictedFactorIds: [],
                unknownFactorIds: 'version' in state ? state.unknownFactorIds : [], applicability: 0, productionEligible: false };
        const relations = this.#r2a.relations().filter(value => candidate.evidence.r2a.relationIds.includes(value.relationId));
        const values = [...this.#relationComparisons(relations, currentAction.signalIds, currentAction)];
        const selected = values.sort((a, b) => Number(b.highConfidenceActionEligible) - Number(a.highConfidenceActionEligible)
            || b.applicability - a.applicability)[0];
        return selected ? { matchedFactorIds: selected.matchedFactorIds,
            contradictedFactorIds: selected.contradictedFactorIds, unknownFactorIds: selected.unknownFactorIds,
            applicability: selected.applicability, productionEligible: selected.highConfidenceActionEligible }
            : { matchedFactorIds: [], contradictedFactorIds: [], unknownFactorIds: [],
                applicability: 0, productionEligible: false,
                unavailableRelationIds: [...candidate.evidence.r2a.relationIds] };
    }
    #annotationFor(candidate) {
        const value = [...this.#annotations.values()].find(annotation => annotation.eventId === candidate.evidence.eventId);
        assert(value, 'unknown-distributed-effect-candidate');
        return value;
    }
    #factorDelta(annotation) {
        const before = new Set(annotation.beforeSignalIds), after = new Set(annotation.afterSignalIds);
        const activated = [], deactivated = [], unchanged = [], universe = [];
        for (const relation of this.#r2a.relations())
            for (const factor of relation.factors) {
                universe.push(factor.factorId);
                const wasActive = factor.sourceSignalIds.some(signal => before.has(signal));
                const isActive = factor.sourceSignalIds.some(signal => after.has(signal));
                if (!wasActive && isActive)
                    activated.push(factor.factorId);
                else if (wasActive && !isActive)
                    deactivated.push(factor.factorId);
                else if (isActive)
                    unchanged.push(factor.factorId);
            }
        const unique = (values) => [...new Set(values)].sort();
        return { activated: unique(activated), deactivated: unique(deactivated),
            unchanged: unique(unchanged), universe: unique(universe) };
    }
    /**
     * Measured-performance escape hatch.  This is deliberately separate from
     * the synchronous reasoning API: callers provide the complete read-only
     * clone request and an explicit worker count.  The production decision path
     * remains unchanged, while benchmark/evaluation code can use the existing
     * exact seed workers without inventing a second predictor.
     */
    async predictPhysicalSeedsParallelV1(request) {
        const substrate = request.medium === 'r1'
            ? this.#r1PredictionSubstrate() : this.#r2PredictionSubstrate();
        return runDistributedPredictionCloneBatchParallelV1(substrate.snapshot, { ...request.request, seeds: request.seeds }, request.parallelism ?? 1, substrate.prescribedActionSiteIds);
    }
    /** Exact seed-level medium probes for capacity/temporal measurements. */
    probePhysicalSeedsSyncV1(medium, jobs, parallelism = 1, options = {}) {
        const substrate = medium === 'r1' ? this.#r1PredictionSubstrate() : this.#r2PredictionSubstrate();
        return runDistributedMediumProbeBatchSyncV1(substrate.snapshot, jobs, parallelism, { ...options, prescribedActionSiteIds: substrate.prescribedActionSiteIds });
    }
    /** Read-only diagnostics for PLAN-002; revisions never enter persisted state. */
    performanceCacheAuditV1() {
        return { r1Revision: this.#r1Revision, r2Revision: this.#r2Revision,
            r1CachedRevision: this.#r1PredictionCache?.revision ?? null,
            r2CachedRevision: this.#r2PredictionCache?.revision ?? null };
    }
    predictCandidate(candidate, state, goal, evaluation) {
        return this.#predictCandidate(candidate, state, goal, evaluation, Array.from({ length: 24 }, (_unused, index) => index + 1));
    }
    predictShortChain(candidates, observation, goal, evaluation) {
        return predictPhysicalShortChainV1(candidates, observation, goal, evaluation, (candidate, state, target, baseline, seeds) => this.#predictCandidate(candidate, state, target, baseline, seeds));
    }
    #retainedReadout(state) {
        const ref = state.physicalReadout;
        if (!ref || ref.mediumVersion !== this.physicalVersion())
            return undefined;
        const value = this.#physicalReadouts.get(ref.readoutId);
        return value?.binding.mediumVersion === ref.mediumVersion ? value : undefined;
    }
    #currentActionInput(annotation, state, seeds = Array.from({ length: 24 }, (_, index) => index + 1)) {
        const retained = 'version' in state ? this.#retainedReadout(state) : undefined;
        if ('version' in state && !retained)
            return undefined;
        if (retained && annotation.publicRoleBindings.some(binding => !retained.context.roles.some(role => role.role === binding.role && role.type === binding.type)))
            return undefined;
        const perception = retained ? this.#r1.lookupDecodedPublicState(retained.values, annotation.cue)
            : this.#r1.lookupCurrentObservation(state, annotation.publicRoleBindings, annotation.cue);
        if (perception.siteIds.length === 0 || perception.unresolvedRoles.length > 0)
            return undefined;
        return { signalIds: retained?.signalIds
                ?? distributedPublicSignalIdsV1(relativePublicFeatures(state)),
            sourceR2PrefixDrives: this.#r2.lookupR1Pulse(perception.drives
                ?? perception.siteIds.map(siteId => ({ siteId, intensity: 1 }))),
            exactActionIdentity: cueIdentity(annotation.cue), seeds: seeds.map(BigInt) };
    }
    #predictCandidate(candidate, state, goal, evaluation, seeds) {
        const kind = 'hypothetical-prediction';
        const retained = 'version' in state ? this.#retainedReadout(state) : undefined;
        if ('version' in state && !retained)
            return this.#emptyBranch(kind, candidate.evidence, 'hypothetical-physical-readout-missing-or-stale');
        const annotation = this.#annotationFor(candidate);
        if (retained && annotation.publicRoleBindings.some(binding => !retained.context.roles.some(role => role.role === binding.role && role.type === binding.type)))
            return this.#emptyBranch(kind, candidate.evidence, 'hypothetical-subject-binding-unavailable');
        const currentAction = this.#currentActionInput(annotation, state, seeds);
        const evidence = this.#evidence(annotation, retained?.signalIds ?? state, currentAction);
        if (!evidence.r1.active)
            return this.#emptyBranch(kind, evidence, 'distributed-R1-attractor-inactive');
        if (!evidence.r2.active)
            return this.#emptyBranch(kind, evidence, 'distributed-R2-road-inactive');
        // Current applicability is the result of the live physical probe, not a
        // precondition for asking the probe to run.  A zero result is precisely an
        // unresolved/contradicted condition that a read-only rollout can
        // characterize.  Keep the real substrate and evidence-grade requirements;
        // only execution qualification continues to depend on positive progress.
        if (!evidence.r2a.predictionEligible)
            return this.#emptyBranch(kind, evidence, 'current-distributed-R2A-pattern-unsupported');
        const physicalAssemblies = this.#stableR1AssembliesForCue(candidate.actionCue);
        if (physicalAssemblies.length === 0)
            return this.#emptyBranch(kind, evidence, 'candidate-has-no-stable-physical-terminal-attractor');
        if (!currentAction)
            return this.#emptyBranch(kind, evidence, 'current-real-public-perception-afferent-unavailable');
        const actionInput = this.#r1.lookupActionCue(candidate.actionCue);
        if (actionInput.siteIds.length === 0)
            return this.#emptyBranch(kind, evidence, 'candidate-action-afferent-unavailable');
        // R1 alone holds the alternatives; it must not replace the conditional
        // R2A rollout with its unconditional associative result. Current signals
        // are projected through already learned fibres, without a past/future
        // event template or the goal entering the physical query.
        const results = this.#r2a.readCurrentAction(currentAction.signalIds, currentAction.sourceR2PrefixDrives, currentAction.exactActionIdentity, currentAction.seeds);
        const currentValues = retained?.values
            ?? eventLocalCurrentPublicStateV1(state, annotation.publicRoleBindings).values;
        const binding = retained?.binding ?? {
            mediumVersion: this.physicalVersion(), observationSequence: state.sequence,
            observationIdentity: sha({ self: state.self, objects: state.objects,
                targetId: state.targetId }), actionPrefix: []
        };
        let progressSampleCount = 0;
        const nextStates = [];
        const terminalReadouts = results.map((result) => {
            if (result.status !== 'reached')
                return { valid: false, changes: [], decodedValues: [],
                    unknown: [result.reason] };
            const r1Arrival = this.#r2.readR1Pulse(this.#r2a.readR2Pulse(physicalTerminalDrivesV1(result)));
            // A conditional result must also belong to a live R1 result population
            // for this exact cue. This keeps mere R3 excitation from crediting an
            // unrelated command (or observation) with a remembered outcome.
            const supported = physicalAssemblies.some(assembly => physicalResidenceMatchV1(r1Arrival.map(drive => drive.siteId), assembly.coreSiteIds).score >= .75);
            if (!supported)
                return { valid: false, changes: [], decodedValues: [],
                    unknown: ['conditional-arrival-has-no-active-exact-action-R1-population'] };
            return physicalTerminalChangesV1(this.#r1.readPublicState(r1Arrival), currentValues);
        });
        const samples = results.map((value, index) => {
            const reachedAssemblyId = value.status === 'reached' ? value.reachedAssemblyIds[0] : undefined;
            const changes = terminalReadouts[index].valid && reachedAssemblyId
                ? new Map([[reachedAssemblyId, terminalReadouts[index].changes]])
                : new Map();
            return distributedPredictionSampleV1(seeds[index], value, changes);
        });
        const liveRelations = this.#r2a.relations();
        const relationIds = liveRelations.map(relation => relation.relationId);
        const factorUniverse = [...new Set(liveRelations.flatMap(relation => relation.factors.map(factor => factor.factorId)))].sort((left, right) => left.localeCompare(right, 'en'));
        const projectionCache = new Map();
        const projectionUnknown = [];
        for (const [readoutIndex, readout] of terminalReadouts.entries()) {
            if (!readout.valid)
                continue;
            if (goalProgress(readout.changes, goal, evaluation))
                progressSampleCount++;
            const context = retained?.context ?? publicReadoutProjectionContextV1(state, annotation.publicRoleBindings, readout.decodedValues);
            const sparse = decodedPublicFeaturesFromContextV1(context, readout.decodedValues);
            projectionUnknown.push(...sparse.unresolvedChannels.map(value => `terminal-R2A-${value}`));
            const predictedSignalIds = distributedPublicSignalIdsV1(sparse.features);
            const cacheKey = sha(predictedSignalIds);
            let factors = projectionCache.get(cacheKey);
            if (!factors) {
                factors = this.#r2a.projectTransientFactors(relationIds, predictedSignalIds, factorUniverse);
                projectionCache.set(cacheKey, factors);
            }
            const nextBinding = { ...binding, actionPrefix: [...binding.actionPrefix, cueIdentity(candidate.actionCue)] };
            const horizonObservationSteps = (retained?.horizonObservationSteps ?? 0)
                + Math.max(0, annotation.changeWaves.length - 1);
            const retainedValue = { binding: nextBinding, context,
                values: readout.decodedValues, signalIds: predictedSignalIds, horizonObservationSteps };
            const readoutId = sha(retainedValue);
            this.#physicalReadouts.set(readoutId, retainedValue);
            const goalEvaluation = evaluateGroundedReadoutV1(goal, evaluation, binding.observationSequence, predicate => {
                const property = predicate.observable.startsWith('properties.')
                    ? predicate.observable.slice('properties.'.length) : predicate.observable;
                const subject = predicate.subject;
                const role = subject.kind === 'self' ? 'self' : subject.kind === 'crosshair' ? 'crosshair'
                    : context.roles.find(value => value.objectId === subject.id && value.type === subject.expectedType)?.role;
                if (!role)
                    return undefined;
                if (subject.kind === 'public-object' && readout.decodedValues.some(value => value.subjectRole === role && value.property === 'visible' && value.value === false))
                    return undefined;
                // World positions and absolute orientation cannot be reconstructed
                // from a local event displacement without a complete physical frame.
                if (property.startsWith('position.') || property.startsWith('relativePosition.')
                    || property === 'yaw' || property === 'pitch')
                    return undefined;
                return readout.decodedValues.find(value => value.subjectRole === role && value.property === property)?.value;
            });
            nextStates.push({ version: 'HypotheticalPublicStateV1', baseObservationSequence: binding.observationSequence,
                knownChanges: structuredClone(readout.changes),
                knownActiveFactorIds: factors.knownActiveFactorIds,
                knownInactiveFactorIds: factors.knownInactiveFactorIds,
                unknownFactorIds: [...new Set([...factors.unknownFactorIds,
                        ...factorUniverse.filter(factorId => !factors.knownActiveFactorIds.includes(factorId)
                            && !factors.knownInactiveFactorIds.includes(factorId))])].sort(),
                unobserved: 'unknown', goalEvaluation, physicalReadout: { readoutId, mediumVersion: binding.mediumVersion,
                    sourceSeed: seeds[readoutIndex], observationSequence: binding.observationSequence,
                    actionPrefix: nextBinding.actionPrefix, horizonObservationSteps } });
        }
        const validSampleCount = terminalReadouts.filter(value => value.valid).length;
        const unknown = [...new Set([...terminalReadouts.flatMap(value => value.unknown),
                ...projectionUnknown])];
        const prediction = { version: 'DistributedPredictionV3', kind,
            support: evidence.r2a.applicability, calibratedProbability: false, samples, evidence,
            unknown, substrateSha256: this.mapSha256 };
        return { prediction, currentEvidence: evidence, validSampleCount, progressSampleCount,
            progressFraction: validSampleCount === 0 ? 0 : progressSampleCount / validSampleCount,
            nextStates, unknown, binding,
            readoutDiagnostics: retained ? undefined : distributedGoalReadoutDiagnosticsV1(terminalReadouts, goal, state, annotation.publicRoleBindings) };
    }
    #emptyBranch(kind, evidence, reason) {
        return { prediction: emptyDistributedPredictionV1(kind, reason, evidence, this.mapSha256),
            currentEvidence: evidence, validSampleCount: 0, progressSampleCount: 0, progressFraction: 0,
            nextStates: [], unknown: [reason], readoutDiagnostics: { version: 'BranchReadoutDiagnosticsV1',
                roleBindingStatus: 'not-required', goalRelevantReadoutCount: 0,
                maxVisitedOriginalKernelIndex: null, goalRelevantKernelVisited: false } };
    }
    predictContinuation(patternId, exactActionCue, observation) {
        // One exact read-through entry, not a branch-selection or history cache.
        // Recovery, writes, changed parameters or any changed public input miss.
        const inputIdentity = sha({ patternId, exactActionCue, observation });
        const key = `${this.physicalVersion()}:${inputIdentity}`;
        if (this.#continuationQueryCache?.key === key)
            return structuredClone(this.#continuationQueryCache.result);
        const result = this.#predictContinuationUncached(patternId, exactActionCue, observation);
        // A cold read can finish a lazy evidence index and advance its revision;
        // bind the result to that completed version, never the pre-read index.
        this.#continuationQueryCache = { key: `${this.physicalVersion()}:${inputIdentity}`,
            result: structuredClone(result) };
        return result;
    }
    #predictContinuationUncached(patternId, exactActionCue, observation) {
        const pattern = this.#r2a.patterns().find(value => value.patternId === patternId);
        assert(pattern, 'unknown-distributed-continuous-pattern');
        const relations = this.#relationsFor([pattern]);
        const qualification = this.#activePatternQualification(pattern);
        const comparisons = this.#relationComparisons(relations, observation);
        const grade = gradeMaximum([qualification.grade,
            ...relations.map(value => this.#activeRelationGrade(value))]);
        const empty = (reason) => ({ version: 'ContinuationPredictionV2',
            patternId, support: 0, samples: [], evidenceGrade: grade, unknown: [reason] });
        const seedDrives = this.#r2.currentPrefixSeedDrives();
        if (seedDrives.length === 0)
            return empty('current-real-distributed-R2-prefix-unavailable');
        if (qualification.activeMemberR2EventIds.length === 0)
            return empty('lower-R1-or-R2-physical-support-inactive');
        if (qualification.activePhysicalTraceIds.length === 0)
            return empty('distributed-R2A-pattern-footprint-inactive');
        if (!predictiveGrade(grade))
            return empty('distributed-continuous-pattern-not-predictive-stable');
        if (relations.length === 0)
            return empty('current-distributed-R3-relation-unavailable');
        if (!comparisons.some(value => value.predictionEligible))
            return empty('current-distributed-R3-relation-not-applicable');
        const currentSignals = distributedPublicSignalIdsV1(relativePublicFeatures(observation));
        const observedAtomCount = this.#r2.pendingAtomCount;
        const physical = this.#r2a.predictPhysicalContinuation(patternId, currentSignals, seedDrives, observedAtomCount, cueIdentity(exactActionCue), Array.from({ length: 24 }, (_unused, index) => BigInt(index + 1)));
        const samples = physical.results.map((result, index) => distributedPredictionSampleV1(index + 1, result, new Map()));
        const reached = samples.filter(value => value.status === 'reached'
            && value.reaches.some(reach => reach.assemblyId === physical.targetPhysicalBranchId)).length;
        return { version: 'ContinuationPredictionV2', patternId, support: reached / 24,
            samples, evidenceGrade: grade,
            unknown: reached > 0 ? [] : ['distributed-trajectory-did-not-reach-pattern-terminal'] };
    }
    compareProjectedParentRelations(relationIds, observation, states, source) {
        const relations = new Map(this.#r2a.relations().map(value => [value.relationId, value]));
        const current = new Map(relationIds.flatMap(id => {
            const relation = relations.get(id);
            return relation ? [[id, this.#currentRelationApplicability(relation, observation)]] : [];
        }));
        return states.map(state => {
            const results = relationIds.flatMap(id => {
                const relation = relations.get(id);
                if (!relation)
                    return [];
                const present = current.get(id);
                const presentMatched = new Set(present.matchedFactorIds);
                const presentContradicted = new Set(present.contradictedFactorIds);
                const matched = [], contradicted = [], unknown = [];
                relation.factors.forEach(({ factorId }) => {
                    if (state.knownActiveFactorIds.includes(factorId))
                        matched.push(factorId);
                    else if (state.knownInactiveFactorIds.includes(factorId))
                        contradicted.push(factorId);
                    else if (state.unknownFactorIds.includes(factorId))
                        unknown.push(factorId);
                    else if (presentMatched.has(factorId))
                        matched.push(factorId);
                    else if (presentContradicted.has(factorId))
                        contradicted.push(factorId);
                    else
                        unknown.push(factorId);
                });
                const physical = source.r1Active && source.r2Active && present.physicalSupportActive
                    && relation.physicalTraceIds.some(trace => this.#r2a.medium.isFootprintActive(trace));
                const productionEligible = physical && present.evidenceGrade === 'intervention-supported'
                    && contradicted.length === 0 && unknown.length === 0;
                return [{ relationId: id, matchedFactorIds: matched, contradictedFactorIds: contradicted,
                        unknownFactorIds: unknown, applicability: productionEligible ? 1 : 0, productionEligible }];
            });
            const selected = [...results].sort((left, right) => Number(right.productionEligible) - Number(left.productionEligible)
                || right.applicability - left.applicability)[0] ?? null;
            return { version: 'ProjectedParentRelationApplicabilityV1',
                selectedRelationId: selected?.relationId ?? null,
                matchedFactorIds: selected?.matchedFactorIds ?? [],
                contradictedFactorIds: selected?.contradictedFactorIds ?? [],
                unknownFactorIds: selected?.unknownFactorIds ?? [], applicability: selected?.applicability ?? 0,
                productionEligible: selected?.productionEligible ?? false,
                relationResults: results };
        });
    }
    recallFactorTransition(factorIds, state) {
        if ('version' in state || factorIds.length === 0)
            return [];
        const requested = new Set(factorIds), result = [];
        for (const annotation of this.#annotations.values()) {
            const delta = this.#factorDelta(annotation);
            if (![...delta.activated, ...delta.deactivated].some(id => requested.has(id)))
                continue;
            result.push({ version: 'OpaqueFactorTransitionTraceV1',
                transitionId: sha({ eventId: annotation.eventId, activated: delta.activated,
                    deactivated: delta.deactivated }), eventId: annotation.eventId,
                actionCue: structuredClone(annotation.cue), activatedFactorIds: delta.activated,
                deactivatedFactorIds: delta.deactivated, unchangedActiveFactorIds: delta.unchanged,
                evidence: this.#evidence(annotation, state), meaning: 'observed-factor-transition' });
        }
        return result.sort((left, right) => left.transitionId.localeCompare(right.transitionId, 'en'));
    }
    recall(desired, observation, offset = 0) {
        const values = [...this.#annotations.values()].filter(value => value.changeWaves.flat()
            .some(change => publicChangeMatches(change, desired)));
        return { kind: 'historical-atomic-observation', total: values.length, offset,
            nextOffset: offset + 2 < values.length ? offset + 2 : null,
            candidates: values.slice(offset, offset + 2).map(value => ({ eventId: value.eventId,
                action: value.cue, actualObserved: value.changeWaves.flat().filter(change => publicChangeMatches(change, desired)),
                observedBefore: value.observedBefore, evidence: this.#evidence(value, observation),
                unknown: ['historical-observation-is-not-a-causal-claim'] })) };
    }
    predict(cue, observation, options = {}) {
        const annotation = [...this.#annotations.values()].find(value => cueIdentity(value.cue) === cueIdentity(cue)
            && this.#stableR1(value));
        const kind = options.prefix ? 'factual-prediction' : 'hypothetical-prediction';
        if (!annotation)
            return emptyDistributedPredictionV1(kind, 'no-stable-distributed-R1-experience', null, this.mapSha256);
        const evidence = this.#evidence(annotation, observation);
        if (!evidence.r2a.predictionEligible || evidence.r2a.applicability <= 0)
            return emptyDistributedPredictionV1(kind, 'no-current-predictive-distributed-pattern', evidence, this.mapSha256);
        return this.predictCandidate({ candidateId: annotation.eventId, goalPredicateIds: [],
            actionCue: annotation.cue, observedChanges: annotation.changeWaves.flat(),
            observedBefore: annotation.observedBefore, evidence, unknown: [] }, observation, { version: 'GroundedGoalV1', id: 'raw-predict', expression: { kind: 'predicate', predicate: {
                    version: 'GoalPredicateV1', id: 'raw-predict', subject: { kind: 'self' }, observable: 'visible',
                    comparator: 'equals', target: true
                } } }, { goalId: 'raw-predict', status: 'unknown', residual: 1,
            observationSequence: observation.sequence, predicates: [] }).prediction;
    }
    /** New physical intervention API; legacy protocol registration is deliberately not migrated. */
    recordDistributedMatchedIntervention(value) {
        return this.#r2a.recordMatchedIntervention(value);
    }
    /**
     * Batch the read-only physical probes for a set of matched interventions.
     * The underlying learner still records one immutable assessment per pair;
     * this entry point only shares the exact medium snapshot and worker batch.
     */
    recordDistributedMatchedInterventions(values) {
        return this.#r2a.recordMatchedInterventions(values);
    }
    /**
     * Read-only substrate inspection for bounded engineering diagnostics.  This
     * deliberately bypasses R2A index discovery: asking what is physically in
     * the lattice must not launch attractor probes, consolidate a relation, or
     * write anything back to experience.
     */
    r2aRawPhysicalMediumSnapshotForAudit() {
        return this.#r2a.rawPhysicalMediumSnapshotForAudit();
    }
    /**
     * Explicit batch boundary for callers that ingest many complete R2 events.
     * R1/R2 deposits remain immediate; only the expensive R2A derived-index
     * consolidation is coalesced by the underlying learner.
     */
    beginR2AConsolidationBatchV1() {
        this.#r2a.beginDeferredConsolidationBatchV1();
    }
    endR2AConsolidationBatchV1() {
        return this.#r2a.endDeferredConsolidationBatchV1();
    }
    r2AConsolidationBatchStatusV1() {
        return this.#r2a.consolidationBatchStatusV1();
    }
    r2AConsolidationPerformanceAuditV1() {
        return this.#r2a.consolidationPerformanceAuditV1();
    }
    /** Naming is an audit/readout operation over a terminal basin already
     * reached by a trusted event; it never influences physical prediction. */
    recordAttractorPublicObservation(value) {
        assert(this.#seen.has(value.sourceEventId), 'attractor-dictionary-source-event-not-observed');
        const annotation = this.#annotations.get(value.sourceEventId);
        assert(annotation, 'attractor-dictionary-source-annotation-missing');
        assert(annotation.completion === 'complete', 'attractor-dictionary-source-event-incomplete');
        const sourceSites = new Set(annotation.r1Record.footprint.siteIds);
        assert(value.readout.coreSiteIds.some(siteId => sourceSites.has(siteId)), 'attractor-dictionary-readout-not-bound-to-source-footprint');
        this.#attractorDictionary.observe(value);
    }
    resolveAttractorPublicReadout(mediumVersion, readout) {
        return this.#attractorDictionary.resolve(mediumVersion, readout);
    }
    recordPredictionViolation(value) {
        assert(this.#seen.has(value.sourceEventId), 'intervention-violation-source-event-not-observed');
        const annotation = this.#annotations.get(value.sourceEventId);
        assert(annotation?.completion === 'complete', 'intervention-violation-source-event-incomplete');
        return this.#interventionAgenda.recordPredictionViolation(value);
    }
    recordFactorialArm(value) {
        assert(this.#seen.has(value.baselineEventId) && this.#seen.has(value.interventionEventId), 'intervention-arm-source-event-not-observed');
        assert(this.#annotations.get(value.baselineEventId)?.completion === 'complete'
            && this.#annotations.get(value.interventionEventId)?.completion === 'complete', 'intervention-arm-source-event-incomplete');
        assert(this.#interventionPairCollector.hasPair(value.pairId), 'intervention-arm-pair-not-collected');
        return this.#interventionAgenda.recordMatchedArm(value);
    }
    /** Read-only agenda view.  It contains physical prefixes and opaque factor
     * ids only; selecting or executing an arm remains the controller's job. */
    pendingInterventionArmRequests() {
        return this.#interventionAgenda.pendingArmRequests();
    }
    /** Add a completed, trusted real window to the matching agenda.  Pairing is
     * derived from physical prefix/action/factor state; this call does not grade
     * or execute the resulting intervention. */
    recordInterventionWindow(value) {
        assert(this.#seen.has(value.eventId), 'intervention-window-source-event-not-observed');
        assert(this.#annotations.get(value.eventId)?.completion === 'complete', 'intervention-window-source-event-incomplete');
        return this.#interventionPairCollector.add(value);
    }
    snapshot() {
        const metaEvidence = this.#metaEvidence.snapshot();
        const attractorDictionary = this.#attractorDictionary.snapshot();
        const interventionAgenda = this.#interventionAgenda.snapshot();
        const interventionPairCollector = this.#interventionPairCollector.snapshot();
        return { version: DISTRIBUTED_HIERARCHICAL_MEMORY_VERSION_V3,
            hierarchy: DISTRIBUTED_HIERARCHY_SEMANTICS_V2, activeSeconds: this.#activeSeconds,
            r1Medium: this.#r1Medium.snapshot(), r1: this.#r1.snapshot(),
            r2Medium: this.#r2.medium.snapshot(), r2: this.#r2.snapshot(), r2a: this.#r2a.snapshot(),
            annotations: [...this.#annotations.values()].sort((left, right) => left.eventId.localeCompare(right.eventId, 'en'))
                .map(value => structuredClone(value)), processedR2EventIds: [...this.#processedR2].sort(),
            seenEventIds: [...this.#seen].sort(), writes: this.#writes,
            ...(metaEvidence.observations.some(value => value.bands.length > 0)
                ? { metaEvidence } : {}),
            ...(attractorDictionary.entries.length > 0 ? { attractorDictionary } : {}),
            ...(interventionAgenda.violations.length > 0 || interventionAgenda.cells.length > 0
                ? { interventionAgenda } : {}),
            ...(interventionPairCollector.windows.length > 0
                ? { interventionPairCollector } : {}) };
    }
    static restore(snapshot) {
        assert(snapshot.version === DISTRIBUTED_HIERARCHICAL_MEMORY_VERSION_V3
            && snapshot.hierarchy === DISTRIBUTED_HIERARCHY_SEMANTICS_V2
            && snapshot.r2a.version === 'DistributedR2APhysicalStateV3', 'legacy-or-incompatible-distributed-checkpoint-is-audit-only');
        const memory = new DistributedHierarchicalPhysicalMemoryV1();
        memory.#originIdentity = canonicalStreamSha256(snapshot);
        memory.#r1Medium = DistributedPhysicalMedium3DV1.fromSnapshot(snapshot.r1Medium);
        memory.#r1 = DistributedR1ExperienceStoreV1.restore(memory.#r1Medium, snapshot.r1, () => memory.#timescaleEnabled ? memory.#timescaleOwner.encodingGain('r1') : 1);
        memory.#r2 = DistributedR2ContinuityStoreV1.restore(snapshot.r2Medium, snapshot.r2, footprint => memory.#r1Medium.isFootprintActive(footprint), () => memory.#timescaleEnabled ? memory.#timescaleOwner.encodingGain('r2') : 1);
        memory.#r2a = DistributedR2APhysicalPatternLearnerV2.restore(snapshot.r2a, id => memory.#r2.isEventActive(id), () => memory.#timescaleEnabled ? memory.#timescaleOwner.encodingGain('r2a') : 1);
        for (const value of snapshot.annotations)
            memory.#annotations.set(value.eventId, structuredClone(value));
        snapshot.processedR2EventIds.forEach(id => memory.#processedR2.add(id));
        snapshot.seenEventIds.forEach(id => memory.#seen.add(id));
        memory.#activeSeconds = snapshot.activeSeconds;
        memory.#writes = snapshot.writes;
        if (snapshot.metaEvidence) {
            memory.#metaEvidence = MetaEvidenceStoreV1.restore(snapshot.metaEvidence);
            const observations = snapshot.metaEvidence.observations;
            memory.#metaDepositionOrdinal = observations.length === 0 ? 0
                : Math.max(...observations.map(value => value.depositionOrdinal)) + 1;
        }
        if (snapshot.attractorDictionary)
            memory.#attractorDictionary = new AttractorPublicEventDictionaryStoreV1(snapshot.attractorDictionary.mediumVersion, snapshot.attractorDictionary);
        if (snapshot.interventionAgenda)
            memory.#interventionAgenda = InterventionAgendaStoreV1.restore(snapshot.interventionAgenda);
        if (snapshot.interventionPairCollector)
            memory.#interventionPairCollector = InterventionPairCollectorV1.restore(snapshot.interventionPairCollector);
        // Keep the fail-closed byte-identity boundary per physical layer.  A
        // combined boolean hid which independently owned substrate was rebuilt
        // differently and forced an entire hierarchy replay for every diagnosis.
        assert(canonicalStreamSha256(memory.#r1Medium.snapshot()) === canonicalStreamSha256(snapshot.r1Medium), 'distributed-R1-checkpoint-restore-not-byte-equivalent');
        assert(canonicalStreamSha256(memory.#r2.medium.snapshot()) === canonicalStreamSha256(snapshot.r2Medium), 'distributed-R2-checkpoint-restore-not-byte-equivalent');
        const restoredR2A = memory.#r2a.snapshot();
        assert(canonicalStreamSha256(restoredR2A.medium) === canonicalStreamSha256(snapshot.r2a.medium), 'distributed-R2A-medium-checkpoint-restore-not-byte-equivalent');
        if (memory.#r2a.restoreIndexModeForAudit() === 'exact-cache')
            assert(canonicalStreamSha256(restoredR2A) === canonicalStreamSha256(snapshot.r2a), 'distributed-R2A-checkpoint-restore-not-byte-equivalent');
        else
            assert(memory.#r2a.restoreIndexModeForAudit() === 'physical-rediscovery', 'distributed-R2A-checkpoint-restore-mode-invalid');
        return memory;
    }
    enableTimescaleV2() {
        if (this.#timescaleEnabled)
            return;
        this.#timescaleOwner = DistributedHierarchicalTimescaleOwnerV1.fromExisting(this.#r1Medium, this.#r2.medium, this.#r2a.medium, this.#activeSeconds);
        this.#timescaleEnabled = true;
    }
    snapshotV4() {
        this.enableTimescaleV2();
        return { ...this.snapshot(), version: 'KairosV5DistributedPhysicalMemoryV4',
            timescales: this.#timescaleOwner.snapshot() };
    }
    static restoreV4(snapshot) {
        assert(snapshot.version === 'KairosV5DistributedPhysicalMemoryV4', 'unsupported-distributed-timescale-checkpoint');
        const legacy = { ...snapshot,
            version: DISTRIBUTED_HIERARCHICAL_MEMORY_VERSION_V3 };
        const memory = DistributedHierarchicalPhysicalMemoryV1.restore(legacy);
        memory.#timescaleOwner = DistributedHierarchicalTimescaleOwnerV1.restoreInto(memory.#r1Medium, memory.#r2.medium, memory.#r2a.medium, snapshot.timescales);
        memory.#timescaleEnabled = true;
        assert(memory.#timescaleOwner.logicalTime === memory.#activeSeconds, 'distributed-timescale-checkpoint-time-mismatch');
        return memory;
    }
}
//# sourceMappingURL=distributed-hierarchical-memory.js.map