/** Environment-neutral, experience-driven prototype. Legacy lattice APIs remain
 * at their explicit source modules for checkpoint inspection and comparisons. */
export { ExperienceMedium, experienceState } from './experience-medium.js';
export { ExperienceAgent } from './experience-agent.js';
export { ExperienceSession } from './experience-session.js';
export { ExperienceWorld } from './experience-world.js';
export { LearnedAffordances } from './learned-affordances.js';
export { GroundedGoalEvaluatorV1, groundedPublicObservableV1, evaluateGroundedPredicateValueV1, goalPredicates } from './control/goal.js';
//# sourceMappingURL=prototype.js.map