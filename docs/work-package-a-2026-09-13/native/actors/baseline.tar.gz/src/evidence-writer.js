import { assert } from './util.js';
/**
 * Bounded, backpressure-aware JSONL evidence writer (PLAN-005 1.4).
 *
 * Records are enqueued synchronously so hot callers (frames, attention) never
 * await; an internal pump honours `write()` backpressure and awaits `drain`.
 * The in-memory queue is bounded: a write error or queue overflow fails the
 * run explicitly through {@link failure} — evidence is never silently dropped.
 * `write()` itself never throws, so a failed stream cannot corrupt an
 * in-flight observation or the shutdown path; the run loop surfaces the
 * failure at the next watchdog tick and the terminal classification.
 */
export class EvidenceWriterV1 {
    #failure = null;
    #lanes;
    #maxQueuedLines;
    constructor(lanes, options = {}) {
        this.#maxQueuedLines = options.maxQueuedLines ?? 65536;
        assert(Number.isSafeInteger(this.#maxQueuedLines) && this.#maxQueuedLines > 0, 'invalid-evidence-queue-limit');
        this.#lanes = [
            { name: 'events', stream: lanes.events, lines: [], head: 0, draining: false, pumpPromise: null },
            { name: 'frames', stream: lanes.frames, lines: [], head: 0, draining: false, pumpPromise: null },
        ];
        for (const lane of this.#lanes)
            lane.stream.on('error', error => this.#fail(new Error(`evidence-stream-error:${lane.name}:${error.message}`)));
    }
    get failure() { return this.#failure; }
    get queuedLines() {
        return this.#lanes.reduce((sum, lane) => sum + (lane.lines.length - lane.head), 0);
    }
    #fail(error) {
        if (this.#failure !== null)
            return;
        this.#failure = error;
        for (const lane of this.#lanes)
            lane.wake?.();
    }
    #lane(name) {
        const lane = this.#lanes.find(value => value.name === name);
        assert(lane !== undefined, 'unknown-evidence-lane');
        return lane;
    }
    write(laneName, line) {
        if (this.#failure !== null)
            return; // the run is already failing explicitly; never throw mid-stride
        const lane = this.#lane(laneName);
        lane.lines.push(line);
        if (lane.lines.length - lane.head > this.#maxQueuedLines) {
            this.#fail(new Error(`evidence-queue-overflow:${lane.name}`));
            return;
        }
        this.#startPump(lane);
    }
    #startPump(lane) {
        // Set the flag synchronously: the pump body runs synchronously up to its
        // first await, so assigning its promise here would race its own exit.
        if (lane.draining)
            return;
        lane.draining = true;
        lane.pumpPromise = this.#pump(lane);
    }
    async #pump(lane) {
        try {
            while (lane.head < lane.lines.length) {
                if (this.#failure !== null)
                    return;
                let accepted = false;
                try {
                    accepted = lane.stream.write(lane.lines[lane.head]);
                }
                catch (error) {
                    this.#fail(error);
                    return;
                }
                // A false return still accepted the line (it is buffered); it only
                // asks for backpressure.  Advance, then await drain before continuing.
                lane.head++;
                if (!accepted) {
                    // A writer failure (stream error or overflow on the sibling lane)
                    // wakes the wait too, so a dead or silent stream can never hang the
                    // shutdown path.
                    await new Promise(resolve => {
                        lane.wake = resolve;
                        lane.stream.once('drain', () => resolve());
                    });
                    lane.wake = undefined;
                    if (this.#failure !== null)
                        return;
                }
            }
            lane.lines = [];
            lane.head = 0;
        }
        finally {
            // No await between the loop exit and this flag clear, so a concurrent
            // write() either was consumed by the loop above or restarts the pump.
            lane.draining = false;
        }
    }
    /** Await until every accepted line has been handed to the OS. */
    async flush() {
        for (const lane of this.#lanes) {
            while (lane.head < lane.lines.length || lane.draining) {
                if (this.#failure !== null)
                    break;
                if (lane.pumpPromise !== null)
                    await lane.pumpPromise;
                else
                    this.#startPump(lane);
            }
        }
        if (this.#failure !== null)
            throw this.#failure;
    }
    /** Flush what is flushable, then end both streams.  The failure (if any) is
     * reported through {@link failure}; ending is always attempted so file
     * handles never leak into process exit. */
    async end() {
        for (const lane of this.#lanes) {
            while (lane.head < lane.lines.length || lane.draining) {
                if (this.#failure !== null)
                    break;
                if (lane.pumpPromise !== null)
                    await lane.pumpPromise;
                else
                    this.#startPump(lane);
            }
        }
        await Promise.all(this.#lanes.map(lane => new Promise(resolve => {
            try {
                lane.stream.end(() => resolve());
            }
            catch {
                resolve();
            }
        })));
    }
    /** Test/diagnostic helper: lines accepted but not yet flushed, per lane. */
    pendingLines(name) {
        const lane = this.#lane(name);
        return lane.lines.length - lane.head;
    }
}
//# sourceMappingURL=evidence-writer.js.map